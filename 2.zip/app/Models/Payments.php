<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payments extends Model
{
    use HasFactory;
    protected $table = "payments";
    protected $primarykey = "id";


    public function plans(){
        return $this->hasOne(Plans::class,'id','plan_id');
    }
    public function invoices(){
        return $this->hasOne(Invoices::class,'payment_id','id');
    }
    public function agent(){
        return $this->hasOne(Agents::class,'id','agent_id');
    }
}
