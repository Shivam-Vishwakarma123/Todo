<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class qr_logs extends Model
{
    // to disable created_at and updated_at default timestamp
    public $timestamps = false;
    use HasFactory;
    protected $table = "qr_logs";

    protected $fillable = [
        'id',
        'handle',
        'created_at',
    ];
}
