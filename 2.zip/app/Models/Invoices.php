<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoices extends Model
{
    use HasFactory;
    protected $table = "invoices";
    protected $primarykey = "id";


    public function plans(){
        return $this->hasOne(Plans::class,'id','plan_id');
    }
}
