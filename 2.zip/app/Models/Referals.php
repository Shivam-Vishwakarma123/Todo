<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Referals extends Model
{
    use HasFactory;
    protected $table = "referrals";
    protected $primarykey = "id";
    protected $fillable = ['joined'];
    
}
