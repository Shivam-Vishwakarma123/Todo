<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PropertyFloorplans extends Model
{
    use HasFactory;
    protected $table = "property_floorplans";
    protected $primarykey = "id";
    
    public function property_floorplan_images()
    {
        return $this->hasMany(PropertyFloorplanImages::class,'property_floorplan_id','id');
    }
}
