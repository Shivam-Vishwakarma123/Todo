<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Property_visit_logs extends Model
{
    public $timestamps = false;
    use HasFactory;
    protected $table = "property_visit_logs";
    protected $primarykey = "id";
    public function properties()
    {
        return $this->hasMany(Properties::class,'id','property_id');
    }
}
