<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Properties extends Model
{
    use HasFactory,Sortable;
    protected $table = "properties";
    protected $primarykey = "id";
    protected $fillable = [
        'main_section',
    ];

    public function property_amenities()
    {
        return $this->hasMany(PropertyAmenities::class,'property_id','id');
    }
    public function property_images()
    {
        return $this->hasMany(Property_images::class,'property_id','id');
    }
    // to access only one image from property images table 
    public function property_single_image()
    {
        return $this->hasOne(Property_images::class,'property_id','id');
    }
    public function property_floorplans()
    {
        return $this->hasMany(PropertyFloorplans::class,'property_id','id');
    }
    public function state(){
        return $this->hasOne(States::class,'id','state_id');
    }
    public function country(){
        return $this->hasOne(Countries::class,'country_id','country_id');
    }
    public function city(){
        return $this->hasOne(Cities::class,'id','city_id');
    }
    public function agents(){
        return $this->hasOne(Agents::class,'id','agent_id');
    }
}
