<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsLogs extends Model
{
    // to disable created_at and updated_at default timestamp
    public $timestamps = false;
    use HasFactory;
    protected $table = "sms_logs";
}
