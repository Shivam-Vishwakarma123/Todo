<?php

namespace App\View\Components;

use Illuminate\View\Component;

class AgentCard extends Component
{
    public $agent_handle, $agent_profile_photo, $agent_name , $agent_business_name , $agent_phone_number,$agent_property_count,$agent_dummy_record;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($agent)
    {
        $this->agent_handle = $agent->handle;
        $this->agent_profile_photo = ($agent->profile_image != '') ? (url('/files/agents/'.$agent->id.'/'.$agent->profile_image)) : (url('/images/logo1.png')) ;
        $this->agent_name = $agent->first_name." ".$agent->last_name ;
        $this->agent_business_name = ($agent->agent_addresses ) ? $agent->agent_addresses->business_name : '' ;
        $this->agent_phone_number = $agent->phone;
        $this->agent_property_count = $agent->property_count;
        $this->agent_dummy_record = $agent->dummy_record;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.agent-card');
    }
}
