<?php

namespace App\View\Components;

use Illuminate\View\Component;

class AgentBillingMobileView extends Component
{
    public $payment_id, $payment_date, $credits_purchased, $amount_paid, $status, $download_invoice, $payment_invoices_file_name;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($payment)
    {
        $this->payment_id = $payment->id;
        $this->payment_date = $payment->payment_date;
        $this->credits_purchased = $payment->plans->credits;
        $this->amount_paid = $payment->amount;
        $this->status = $payment->status;
        $this->payment_invoices_file_name = $payment->invoices?->file_name;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.agent-billing-mobile-view');
    }
}
