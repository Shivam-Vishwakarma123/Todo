<?php

namespace App\View\Components;

use Illuminate\View\Component;

class PropertyCard extends Component
{
    public $width;
    public $property;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($property, $width)
    {
        //$width variable is set to define the width of card with respect to parent div 
        $this->width = $width;

        // for index page mobile device :first card width is less so that second card visible to user 
        if($this->width == 'index')
        {
            // here , property-card-width variable is used to give manual width to buy and rent tabs property section 
            $this->width = "w-5/6 property-card-width";
        }
        else{
            $this->width = "w-full max-w-[300px]"; 
        }

        //Initialize object with default values.
        $this->property = $property;

        // data passed to show on each card
        $this->property->unique_url = url('/')."/".$property->unique_url;

        $this->property->property_single_image = ($property->property_single_image != null) ? (url('/files/property_thumbs/'.$property->id.'/'.$property->property_single_image->file_name)) : url('/images/default_image.png') ;
        
        if(isset($property->agents)) {
            $this->property->agent_image = ($property->agents->profile_image != null) ? (url('files/agents/'.$property->agents->id.'/'.$property->agents->profile_image)) : url('/images/logo1.png');
            $this->property->agent_name = $property->agents->first_name." ".$property->agents->last_name;
        } else {
            $this->property->agent_image = url('/images/logo1.png');
            $this->property->agent_name = "";
        }
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.property-card');
    }
}
