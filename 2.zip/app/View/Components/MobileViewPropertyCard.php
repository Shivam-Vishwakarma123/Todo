<?php

namespace App\View\Components;

use Illuminate\View\Component;

class MobileViewPropertyCard extends Component
{
    public $property_id, $property_unique_url, $property_published, $property_active, $property_name, $property_city, $property_state, $property_updated_at;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($property)
    {
        $this->property_id = $property->id;
        $this->property_unique_url = $property->unique_url;
        $this->property_published = $property->published;
        $this->property_active = $property->active;
        $this->property_name = $property->name;
        $this->property_city = $property->city;
        $this->property_state = $property->state;
        $this->property_updated_at = $property->updated_at;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.mobile-view-property-card');
    }
}
