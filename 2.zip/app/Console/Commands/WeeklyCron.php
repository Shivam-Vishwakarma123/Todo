<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Spatie\Sitemap\SitemapGenerator;
use Psr\Http\Message\UriInterface;

// for testing this command you can use below command in terminal on your projects root directory
// php artisan weekly_cron:execute

class WeeklyCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'weekly_cron:execute';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate the sitemap';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        SitemapGenerator::create('https://propertyshops.in/')
        ->shouldCrawl(function (UriInterface $url) {
            
            // All pages will be crawled, except the backend pages and files like images.
            $backendSegment = array('/backend/','/files/');
    
            foreach($backendSegment as $segment){
                if(strpos($url->getPath(), $segment) !== false){
                    return false;
                }
            }

            return true;
        })
        ->writeToFile(public_path('sitemap.xml'));
        $this->info('sitemaps created successfully!');
    }
}
