<?php

namespace App\Console\Commands;

use App\Models\Properties;
use App\Models\Agents;
use Illuminate\Console\Command;


class DailyCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily_cron:execute';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update the property publish status';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $current_date = date('Y-m-d H:i:s');
        $properties = Properties::where([
            ['expiry_date','<',$current_date],
            ['published','=',1]
        ])->get();
        
        foreach( $properties as $property ) {
            $property->published = 0;
            $property->save();
        }

        // deactivate all agents who are not logged in from past 4 months
        Agents::where('last_access_date', '<', now()->subMonths(4))->update(['active' => 0]);
    }
}
