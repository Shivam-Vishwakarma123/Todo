<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserDashboardController extends Controller
{
    public function user_index(Request $request)
    {
        return view('user.dashboard');
    }
}
