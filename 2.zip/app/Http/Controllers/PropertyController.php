<?php

namespace App\Http\Controllers;

use App\Models\Properties;
use App\Models\Agents;
use App\Models\Agent_addresses;
use App\Models\Property_visit_logs;
use App\Models\PropertyAmenities;
use App\Models\Property_images;
use App\Models\PropertyGalleries;
use App\Models\PropertyDocuments;
use App\Models\PropertyFloorplans;
use App\Models\PropertyFloorplanImages;
use App\Models\Property_videos;
use App\Models\Property_matterport;
use App\Http\Controllers\Controller;
use App\Models\States;
use App\Models\Cities;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Http\Request;
use App\Models\PropertyGalleryImages;

class PropertyController extends Controller
{
    // to show property description(details) on public site code starts
    public function details($unique_url)
    {
        $propertie = Properties::where("unique_url", '=', $unique_url)->with('country', 'state')->get();
        if ($propertie->count() > 0) {
            foreach ($propertie as $property) {
                $state = States::where('id', '=', $property->state_id)->first();
                $city = Cities::where('id', '=', $property->city_id)->first();
                $agents = Agents::where('id', '=', $property->agent_id)->first();

                // Total numbers of properties that agent have
                $a = Properties::where([
                    ['agent_id', $property->agent_id],
                    ['published', '1'],
                    ['active', '1']
                ])
                    ->count();
                $agents["property_count"] = $a;

                $agent_address = Agent_addresses::where('agent_id', '=', $agents->id)->with('country', 'state')->first();
                $property_amenities = PropertyAmenities::where("property_id", '=', $property->id)->with('amenities')->get();
                $property_images = Property_images::where("property_id", '=', $property->id)->get();

                $property_topbar_images = [];

                if ($property_images->count() > 0) {
                    $property_topbar_images = Property_images::where('id', '=', $property->featured_image)->first();
                }

                // here join the property gallery Table with Property Gallery Images table 
                $property_galleries = PropertyGalleries::where("property_id", '=', $property->id)->with('Property_gallery_images', 'property_images')->get();

                // here in the property_gallery_details array we store the property gallery name and description and
                // store property_images_id , galelry_id from property gallery Images table 

                $property_gallery_details = [];
                if ($property_galleries->count() > 0) {
                    foreach ($property_galleries as $pg) {
                        $Property_Random_Gallery_image = PropertyGalleryImages::where('gallery_id', '=', $pg->id)->inRandomOrder()->take(1)->get();
                        // here we store property galary images data with key "images" in array 
                        $property_gallery_details[$pg->id]["images"] = [];

                        foreach ($pg->property_gallery_images as $pgi) {
                            if (!is_null($pgi->property_images)) {
                                $tmp = [];
                                $tmp['property_image_id'] = $pgi->property_image_id;
                                $tmp['file_name'] = $pgi->property_images['file_name'];
                                if (count($tmp) != 0) {
                                    $property_gallery_details[$pgi->gallery_id]["images"][] = $tmp;
                                }
                            }
                        }
                        $property_gallery_details[$pg->id]['random_file_name'] = $Property_Random_Gallery_image[0]->property_images->file_name;
                        $property_gallery_details[$pg->id]["gallery_name"] = $pg->name;
                        $property_gallery_details[$pg->id]["property_id"] = $pg->property_id;
                        $property_gallery_details[$pg->id]["short_description"] = $pg->short_description;
                    }
                }

                // get random image from property images table
                $Property_Random_Img = Property_images::where('property_id', '=', $property->id)->inRandomOrder()->get()->take(1);

                $property_documents = PropertyDocuments::where("property_id", '=', $property->id)->get();
                $property_floorplans = PropertyFloorplans::where("property_id", '=', $property->id)->get();
                $property_floorplan_images = PropertyFloorplanImages::where("property_id", '=', $property->id)->with('property_images')->get();
                $property_videos = Property_videos::where("property_id", '=', $property->id)->get();
                $property_matterport = Property_matterport::where("property_id", '=', $property->id)->get();

                $property_video_featured_data = [];
                if ($property_videos->count() > 0) {
                    foreach ($property_videos as $property_video) {
                        if ($property_video->featured == 1) {
                            $property_video_featured_data = $property_video->featured;
                        } else {
                            $property_video_featured_data = 0;
                        }
                    }
                } else {
                    $property_video_featured_data = 0;
                }

                $old_property_id = Cookie::get('property_id');
                if($old_property_id != $property->id) {
                    
                    $agent_session_data = session('agent');
                    if(is_null($agent_session_data)){
                        //For public users
                        Cookie::queue('property_id', $property->id, 30);
                        $property->increment('views');
                    }else{
                        //When Agent is vieweing own properties
                        if($property->agent_id != $agent_session_data["id"]){
                            Cookie::queue('property_id', $property->id, 30);
                            $property->increment('views');
                        }
                    }
                }

                // storing view detail in view log table
                $property_view = new Property_visit_logs;
                $property_view->property_id = $property->id;
                $property_view->agent_id = $agents->id;
                $property_view->visit_date = date("Y-m-d");
                $property_view->ip_address = request()->ip();
                $property_view->save();

                $admin_session_data = session('admin');

                // if user tries to open a link of un_published property of other agent then 
                if(!is_null($agent_session_data) && (($property->agent_id != $agent_session_data["id"]) && ($property->published == 0))){
                    $data = (object) [];
                    $data->msg = "This property is not published yet.";
                    return view('errors/404', compact('data'));
                }
               
                if (!is_null($admin_session_data) || !is_null($agent_session_data) || ($property->published == 1 && $property->reviewed == 1)) {
                    $data = '1';
                    return view('property', compact('property', 'state', 'city', 'agents', 'agent_address', 'property_amenities', 'property_images', 'Property_Random_Img', 'property_galleries', 'property_gallery_details', 'property_documents', 'property_floorplans', 'property_floorplan_images', 'property_videos', 'property_matterport', 'data', 'property_topbar_images', 'property_video_featured_data'));

                } else {

                    $data = (object) [];
                    $data->msg = "This property is not published yet.";
                    return view('errors/404', compact('data'));
                }
            }
        } else {
            return abort('404');
        }
    }
    // to show property description(details) on public site code ends

    // to show properties listing on public site
    public function listing(Request $request)
    {
        // getting the order

        // for filter
        $type = $request->type;

        $orderValue = "publish_date";
        $order = "desc";
        if ($request->get('sort') != '') {
            $orderValue = $request->get("sort");
            $order = $request->get('direction');
            if ($orderValue == 'Price') {
                $orderValue = 'price';
            } else if ($orderValue = 'Popularity') {
                $orderValue = 'views';
            } else if ($orderValue == 'Recent') {
                $orderValue = 'publish_date';
            }
        }


        // to show latest properties listing on public site
        $propertie = Properties::where([
            ['published', '1'],
            ['active', '1']
        ])->with('city', 'state');

        if ($type !== "All" && $type !== "Rent" && $type !== "Sale") {
            $type = "All";
        }

        //If property type passed in the URL
        if ($type !== "All")
            $propertie = $propertie->where('sale_rent', '=', $type);

        if(trim($type) == "") $type = "All";

        $count = $propertie->count();
        $propertie = $propertie->orderBy($orderValue, $order)->paginate(16);
        return view('public_site.properties_listing', compact('propertie', 'type','count'));
    }


    // to show property listing on search specific city name with property type on public site index page starts
    public function search(Request $request)
    {
        $type = $request->buy_rent;
        if ($type == 'Buy') {
            $type = 'Sale';
        }
        $cities = Cities::where('id', $request->city_id)->first();
        if ($cities == "") {
            return back()->with('error', "Invalid City Name");
        }
        $propertie = Properties::where([
            ['city_id', $cities->id],
            ['sale_rent', $type],
            ['published', '1'],
            ['active', '1'],
            // 1 is used to fetch published property details only
            ['expiry_date', '>=', date('Y-m-d')]
        ])
            ->with('property_single_image', 'agents')
            ->get();
        //  we can add more filters(now city) to search properties
        $search_data['city'] = $cities->name;
        $search_data['sale_rent'] = $type;
        return view('public_site/search_properties_listing', compact('propertie', "type", 'search_data'));
    }
    // to show property listing on search specific city name with property type on public site index page ends

    // to show properties of a specific city on click a property card on public site
    public function cities(Request $request)
    {
        // getting the order
        $orderBy = $request->get("sort");

        // for filter
        $type = $request->type;
        $order = "";

        $orderValue = "publish_date";

        if ($request->get('sort') != '') {
            $orderValue = $request->get("sort");
            $order = $request->get('direction');
            if ($orderValue == 'Price') {
                $orderValue = 'price';
            } else if ($orderValue = 'Popularity') {
                $orderValue = 'views';
            } else if ($orderValue == 'Recent') {
                $orderValue = 'publish_date';
            }
        }

        //if no order vale passed then set desc
        if ($order == "")
            $order = "desc";

        $city_id = Cities::where('slug', $request->city)->first();
        if ($city_id == "") {
            $data = (object) [];
            return abort('404');
        }
        $city_id = $city_id->id;
        $propertie = Properties::where([
            ['city_id', $city_id],
            ['published', '1'],
            ['active', '1']
        ])
            ->orderBy($orderValue, $order);

        //If property type passed in the URL
        if ($type !== "All")
            $propertie = $propertie->where('sale_rent', '=', $type);

        if ($propertie->count() == 0) {
            $propertie = Properties::where([
                ['published', '1'],
                ['active', '1']
            ])
                ->orderBy('updated_at', 'desc')
                ->get();
            $request->session()->flash('success', "No property found in the location. You are redirected to all property listing.");
            return redirect('/properties/listing/All?sort=Recent&direction=asc');

        }
        $count = $propertie->count();
        $propertie = $propertie->paginate(16);
        return view('public_site.properties_by_city', compact('propertie', 'type','count'));
    }

    public function advance_search()
    {
        $cities = Cities::with("state")->get();
        return view('public_site.advance_search', compact("cities"));
    }

    public function matched_data(Request $request)
    {
        $token = $request->session()->token();
        $csrf_token = $request->_token;
        if ($token !== $csrf_token && $request->via != "link") {
            return back()->with('error', 'Direct access to result page is not allowed.');
        }
        $city_id = $request->city;
        $sale_rent = $request->sale_rent;
        $bedrooms = $request->bedrooms;
        $price_min = $request->price_min;
        $price_max = $request->price_max;
        $property_type = $request->property_type;
        $furnishing_type = $request->furnishing_type;
        $parking = $request->parking;


        // By Default order
        $order = "";

        $orderValue = "publish_date";

        if ($request->get('sort') != '') {
            $orderValue = $request->get("sort");
            $order = $request->get('direction');
            if ($orderValue == 'Price') {
                $orderValue = 'price';
            } else if ($orderValue = 'Popularity') {
                $orderValue = 'views';
            } else if ($orderValue == 'Recent') {
                $orderValue = 'publish_date';
            }
        }
        //if no order vale passed then set desc
        if ($order == "")
            $order = "desc";

        if ($bedrooms != "") {
            $propertie = Properties::where([
                ['bedroom', $bedrooms],
                ['published', '1'],
                ['active', '1']
            ])->orderBy($orderValue, $order);
        } else {
            $propertie = Properties::where([
                ['published', '1'],
                ['active', '1']
            ])->orderBy($orderValue, $order);
        }

        if ($price_max > 0)
            $propertie = $propertie->where('price', '<', $price_max);

        if ($price_min > 0)
            $propertie = $propertie->where('price', '>', $price_min);

        if ($property_type != "Any" && $property_type != "")
            $propertie = $propertie->where('property_type', $property_type);

        if ($sale_rent !== "Any")
            $propertie = $propertie->where('sale_rent', $sale_rent);


        if ($furnishing_type !== null && $furnishing_type !== "Any")
            $propertie = $propertie->whereIn('furnishing_type', $furnishing_type);

        if ($parking != "Ignore" && $parking != "")
            $propertie = $propertie->where('covered_parkings', '+', 'open_parkings', '=', $parking);

        if ($city_id != "")
            $propertie = $propertie->where('city_id', '=', $city_id);

        $count = $propertie->count();

        $propertie = $propertie->paginate(20);
    
        $type = "All";
        return view('public_site.properties_listing', compact('propertie', "type",'count'));
    }
}