<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Agents;
use App\Models\States;
use App\Models\Properties;


class DashboardController extends Controller
{
    public function index(Request $request)
    {
        //Remove old property data from Session if any
        $request->session()->forget('property');

        $agent = $request->session()->get("agent");

        $id = $agent["id"];

        $agent = Agents::where('id', '=', $id)->first();
        
        if(!is_null($agent)){
            $agent->last_access_date = date('Y-m-d H:i:s');
            $agent->save();
        }
        
        $app_token = $request->session()->get('app_token');
        if (isset($app_token) && !empty($app_token)) {
            $agent->fcm_token = $app_token;
            $agent->save();

             // after storing removing the token from session
             $request->session()->forget('app_token');
        }

        $property_descending_order = [];
        $property_update = [];

        if (!is_null($agent)) {
            $property_descending_order = Properties::where('agent_id', '=', $agent->id)->orderBy('id', 'desc')->limit(5)->get();
            $property_update = Properties::where('agent_id', '=', $agent->id)->orderBy('updated_at', 'desc')->limit(5)->get();
        }

        $data = compact('agent', 'property_descending_order', 'property_update');
        $device = new \Jenssegers\Agent\Agent;
        return view(($device->isMobile() ? 'Agent.agents.mobile_dashboard' : 'Agent.agents.dashboard'))->with($data);
    }
}
