<?php

namespace App\Http\Controllers\Agent\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\AgentLoginRequest;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     *
     * @return \Illuminate\View\View
     */
    public function create(Request $request)
    {
        if ($request->session()->has('agent')) {
            return redirect('/agent/dashboard');
        } else if (Cookie::get('agent')) {

            $cookie = Cookie::get('agent');
            $agent = json_decode($cookie, true);

            session(['agent' => $agent]);

            Cookie::queue('agent', $cookie, 43200);
            return redirect('/agent/dashboard');
        } else {
            return view('Agent.agents.SignIn');
        }
    }

    /**
     * Handle an incoming authentication request.
     *
     * @param  \App\Http\Requests\Auth\AgentLoginRequest  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(AgentLoginRequest $request)
    {
        $request->authenticate();

        $request->session()->regenerate();
        return redirect()->intended(RouteServiceProvider::AGENT_HOME)->with('success', 'Login Successfully !');
    }

    /**
     * Destroy an authenticated session.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Request $request)
    {
        Auth::guard('agent')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->route('agent.login')->withCookie(Cookie::forget('agent'));
    }

    public function user_create(Request $request)
    {
        if ($request->session()->has('user')) {
            return redirect('/user/dashboard');
        } else if (Cookie::get('user')) {

            $cookie = Cookie::get('user');
            $user = json_decode($cookie, true);

            session(['user' => $user]);

            Cookie::queue('user', $cookie, 43200);
            return redirect('/user/dashboard');
        } else {
            return view('Agent.agents.SignIn');
        }
    }

    public function user_store(AgentLoginRequest $request)
    {
        return "userstore";
        $request->authenticate();

        $request->session()->regenerate();
        return redirect()->intended(RouteServiceProvider::AGENT_HOME)->with('success', 'Login Successfully !');
    }

    public function user_destroy(Request $request)
    {
        Auth::guard('user')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->route('agent.login')->withCookie(Cookie::forget('user'));
    }
}
