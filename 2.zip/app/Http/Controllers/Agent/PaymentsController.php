<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;
use App\Models\Agent_addresses;
use Illuminate\Http\Request;
use App\Models\Agents;
use App\Models\credit_logs;
use Illuminate\Support\Facades\File;
use App\Models\Plans;
use App\Models\Payments;
use App\Models\Invoices;
use Carbon\Carbon;
use PDF;
use Cashfree\Cashfree;

Cashfree::$XClientId = "5960103cb2590db1a5067c038d010695";
Cashfree::$XClientSecret = "cfsk_ma_prod_e75272f451fc4b2a198e7a0a4e3783ff_2d25b418";
Cashfree::$XEnvironment = Cashfree::$PRODUCTION;


class PaymentsController extends Controller
{    
    public function paymentSuccess(Request $request){
        $order_id = trim($_GET['order_id']);
        $agent = session('agent');
        $id = $agent["id"];
        
        $url = "https://api.cashfree.com/pg/orders/" . $order_id;
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        
        $headers = array(
        "Content-Type: application/json",
        'x-api-version: 2022-09-01',
        'x-client-id: ' . Cashfree::$XClientId,
        'x-client-secret: ' . Cashfree::$XClientSecret
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        $resp = curl_exec($curl);
        curl_close($curl);
        $resp = json_decode($resp, true);
        if ($resp["order_status"]=='ACTIVE') {
            $payment = Payments::where('payment_id' ,'=' ,$order_id)->first();
        return view('Agent.agents.payment_error',compact('payment'));
        }
        
        if(is_array($resp) && count($resp) > 0)
        {
        $payment_request_id = $resp['order_id'];
        $payment_id = $order_id;
        
        $payment = Payments::where('payment_id' ,'=' ,$payment_request_id)->first();
        $agent = Agents::where('id', '=', $id)->first();
        $plan = Plans::where('id' ,'=' ,$payment->plan_id)->first();
        $payment->status =$resp["order_status"];
        $payment->payment_id = $payment_id;
        $payment->amount = $resp['order_amount'];
        $payment->currency = "INR";
        $payment->payment_date = Carbon::parse($resp['created_at'])->format('Y-m-d H:i:s');
        
        if($payment->save()){
        // to store data in Invoices table
        // if payment completed and status is equal to paid
        if($resp['order_status'] == 'PAID')
        {
        $this->setInvoiceData($order_id);
        }
        
        $credit_logs = new credit_logs;
        $credit_logs->agent_id = $agent->id;
        $credit_logs->property_id = 0;
        $credit_logs->credits = $plan->credits;
        $credit_logs->type = 'Bought';
        if($credit_logs->save()){
        
        // here we find agents table data again because when we purchase a subscription plan we need to get credit balance data from agents table
        // if we are using session for update credit logs then we get credit balance from agent table older data
        // we need here updated latest credit balance data from agent table
        
        $agent_data = Agents::find($agent->id);
        $credit_balance = $agent_data->credit_balance + $plan->credits ;
        $agent->credit_balance = $credit_balance;
        
        if($agent->save()){
        $phone = $agent->phone;
        $values= $plan->credits ."|".$plan->price;
        
        // send sms if it's not a dummy record
        if (intval($agent->dummy_record) != 1 && $_SERVER["SERVER_NAME"] != "localhost") {
            $this->smsRequest("154645",$values,$phone);
        }
        
        return redirect('/agent/success-page/' .$credit_logs->id);
        } else {
        return redirect()->back()->with("error", "Failed to update credit logs ! ");
        }
        } else {
        return redirect()->back()->with("error", "Failed to update agent credit balance logs ! ");
        }
        } else {
        return redirect()->back()->with("error", "Payment Failed ! ");
        }
        }
        
        exit();
        }

    public function SuccessPage($id){
        $credit_logs = credit_logs::where('id' ,'=' ,$id)->first();
        if(!is_null($credit_logs)){
            return view('Agent.agents.success_page')->with(["credits" => $credit_logs->credits]);
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return view(($device->isMobile() ? 'Agent.agents.mobile_dashboard' : 'Agent.agents.dashboard'));
        }
    }
    
    public function payment(Request $request){
    
        $agent = session('agent');
        $id = $agent["id"];
        
        $agent = Agents::where('id', '=', $id)->first();

        $plan = Plans::where('id' ,'=' ,$request['id'])->first();
 
            $cashfree = new \Cashfree\Cashfree();
            
            $x_api_version = "2022-09-01";
            
            $create_orders_request = new \Cashfree\Model\CreateOrderRequest();
            $create_orders_request->setOrderAmount($plan->price);
            $create_orders_request->setOrderCurrency("INR");
            $customer_details = new \Cashfree\Model\CustomerDetails();
            $customer_details->setCustomerId('customer_'.rand(111111111,999999999));
            $customer_details->setCustomerPhone($agent->phone);
            $order_meta = new \Cashfree\Model\OrderMeta();
            $order_meta->setReturnUrl(url('agent/payment-success?order_id={order_id}'));
            $order_meta->setNotifyUrl(url(base_path().'/public'.'/test.php'));
            $create_orders_request->setCustomerDetails($customer_details);
            $create_orders_request->setOrderMeta($order_meta);
            try {
                $result = $cashfree->PGCreateOrder($x_api_version, $create_orders_request);
                
                $response = json_decode($result[0],true);
                $payment = new Payments; 
                $payment->agent_id = $agent->id;
                $payment->payment_date = date('y-m-d');
                $payment->plan_id = $plan->id;
                $payment->payment_id = $response['order_id'];
                $payment->amount = $plan->price;
                $payment->currency = "INR";
                $payment->status = "Pending";
                
                if($payment->save()) {
                    $session =$response['payment_session_id'];
                    return view ('Agent.agents.checkout',compact('session'));
                } 
                else {
                            return redirect()->back()->with("error", "Payment Failed ! ");
                        }
            } catch (Exception $e) {
                echo 'Exception when calling PGCreateOrder: ', $e->getMessage(), PHP_EOL;
            }
        
        exit();
    } 
    public function setInvoiceData($payment_id)
    {
        $agent = session('agent');
        $id = $agent["id"];
        
        $agent = Agents::where('id', '=', $id)->first();
        
        $agents = Agents::find($agent->id);
        $agent_address = Agent_addresses::where('agent_id',$agents->id)->with('state')->first();
        // dd($agent_address);
        $payment_details = Payments::where('payment_id', $payment_id)->with('plans')->first(); 
         // code to calculate cgst , sgst , igst on the basis of amount and agent's home state starts
         $net_amount = $payment_details->plans->price;
         $txbl_amnt = round(($net_amount * 100) / 118 , 2);
         $agent_state = $agent_address->state_id;
         $tot_gst = round($net_amount - $txbl_amnt , 2);
         $cgst = 0;
         $sgst = 0;
         $igst = 0;
         $data ="";
         // if agent state is equal to current state i.e; Uttar Pradesh
         if($agent_state == 27)
         {
             $cgst = round($tot_gst / 2 , 2);
             $sgst = $cgst;
         }
         else{
             $igst = $tot_gst;
         }
        // to check whether a invoice is already generated or not
        $invoice_exist = Invoices::where('payment_id', $payment_details->id)->count();
        if($invoice_exist > 0)
        {
            // if invoice already generated
            $invoices = Invoices::where('payment_id', $payment_details->id  )->first();
            $invoices->plan_id = $payment_details->plan_id;
            $invoices->taxable_amount = $txbl_amnt;
            $invoices->igst = $igst;
            $invoices->cgst = $cgst;
            $invoices->sgst = $sgst;
            $invoices->total_gst = $tot_gst;
            $invoices->net_amount = $net_amount;
            $invoices->file_name = 'invoice-'.$invoices->invoice_no.'.pdf';
            
        }
        else
        {
            // if invoice not generated yet
            $invoice_number = Invoices::max('invoice_no');
            if($invoice_number == 0)
            {
                $invoice_number = 1;
            }
            else{
                $invoice_number = $invoice_number + 1;
            }            
            $invoices = new Invoices;
            $invoices->agent_id = $agent->id;
            $invoices->payment_id = $payment_details->id;
            $invoices->plan_id = $payment_details->plan_id;
            $invoices->invoice_no = $invoice_number;
            // code to calculate cgst , sgst , igst on the basis of amount and agent's home state ends
            $invoices->taxable_amount = $txbl_amnt;
            $invoices->igst = $igst;
            $invoices->cgst = $cgst;
            $invoices->sgst = $sgst;
            $invoices->total_gst = $tot_gst;
            $invoices->net_amount = $net_amount;
            $invoices->file_name = 'invoice-'.$invoice_number.'.pdf';
        }

        $data = [
            'agents' => $agents,
            'payment_details' => $payment_details,
            'invoices' => $invoices,
            'agent_address' => $agent_address
        ];
        if($invoices->save()) {
            $pdf = PDF::loadView('Agent/agents/invoicePdf', $data);
            $directory_path = public_path().'/files/invoices/';
            if(!File::exists($directory_path)) {
                File::makeDirectory($directory_path,0755, true);    
             }
            $pdf->save($directory_path. "/".$invoices->file_name);
            return "success";   
        }
        else{
            echo "failed";
        }

    }
}
