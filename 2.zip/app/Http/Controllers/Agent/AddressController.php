<?php

namespace App\Http\Controllers\Agent;

use Illuminate\Http\Request;
use App\Models\Properties;
use App\Models\States;
use App\Http\Controllers\Controller;

class AddressController extends Controller
{

    // Address Map Page Open

   

    // Update the address

    public function updateAddressMap(Request $request){
        $property = session('property');
        if(!is_null($property)) {
            $data = array();
            $state = States::where('name' ,'=' ,$request['state'])->first();
            $status = Properties::where('id', '=', $property['id'])
                ->update(["name" => $request['address_line_1'], 'address_line_1' => $request['address_line_1'],'city' => $request['city'],
                    'state_id' => (isset($state)?$state->state_id : '' ),'zip' => $request['zip'],'country_id' =>  "230"]);
    
            if ($status) {
                $data['success'] = 1;
                $data['message'] = "Address is updated !";
            } else {
                $data['success'] = 0;
                $data['error'] = "Address is Not updated !";
            }
            return response()->json($data);
            die;
        } else 
        {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error','Error on Updating Property Address !');;
        }
    }
}
