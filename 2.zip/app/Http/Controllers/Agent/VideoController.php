<?php

namespace App\Http\Controllers\Agent;

use Illuminate\Http\Request;
use App\Models\Property_videos;
use App\Models\Property_matterport;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Controller;

class VideoController extends Controller
{
    public function video()
    {
        $property = session('property');
        if(!is_null($property)) {
            $property_videos = Property_videos::where('property_id', '=', $property['id'])->get();
            $property_matterports = Property_matterport::where('property_id', '=', $property['id'])->get();
            
            // $data = compact('property_videos', 'property_matterports');
            return view('Agent/video/video',['property'=>$property,'property_videos'=>$property_videos,'property_matterports'=>$property_matterports]);
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access Property Videos directly !');
        }
    }


    // ThreeD_video = 3d_videos 
    public function ThreeD_video()
    {
        $property = session('property');
        if(!is_null($property)) {
            $property_matterports = Property_matterport::where('property_id', '=', $property['id'])->get();
            $data = compact('property_matterports');
            return view('Agent/video/3d-video')->with($data);
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access 3D Matterport Videos directly !');
        }
    }

    // Save Video 


    public function saveVideo(Request $request)
    {
        $data = array();
        $property = session('property');
        if(!is_null($property)) {

            $property_videos = Property_videos::where('property_id', '=', $property['id'])->count();
    
            if($property_videos >= 2){
                $data['success'] = 0;
                $data['message'] = 'You have Exceed your Video Uplaod Limit';
            } else {
    
                $validator = Validator::make($request->all(), [
                    'file.*'  => 'required|mimes:mp4,mov,ogg,wmv',
                ]);
                if ($validator->fails()) {
                    $data['success'] = 0;
                    $data['error'] = $validator->errors()->first('file'); // Error response
                } else {
                    $video = $request->file('file');
                    $video_name = time() . '_' . $video->getClientOriginalName();
    
                    // File upload location
                    $path = public_path() . '/files/property_videos/' . $property['id'];
                    $size = $_FILES["file"]["size"];
                    if ($size >= 1024 && $size < (1024 * 1024)) {
                        $size = round($size / 1024, 2) . 'kb';
                    } elseif ($size >= (1024 * 1024)) {
                        $size = round($size / (1024 * 1024), 2) . 'mb';
                    } else {
                        $size = round($size, 2) . 'byte';
                    }
    
                    // Upload Videos
                    if (!File::isDirectory($path)) {
                        File::makeDirectory($path, 0755, false);
                    }
                    if ($video->move($path, $video_name)) {
                        $property_video = new Property_videos();
                        $property_video->property_id = $property['id'];
                        $property_video->file_name = $video_name;
                        $status = $property_video->save();
                        // Response
                        if($status){
                            $data['success'] = 1;
                            $request->session()->flash('success', 'Uploaded Successfully!');
                        }else{
                            // Response
                            $data['success'] = 0;
                            $data['message'] = 'Error saving data.';
                        }                          
                    }else{
                        $data['success'] = 0;
                        $data['message'] = 'Video not uploaded.';
                    }            
                }
            }
            return back();
        } else {
            return back()->with('error', 'Error on Updating Video !');
        }

    }

    // Cover Video

    public function coverVideo(Request $request)
    {
        $property = session('property');
        if(!is_null($property)) {
            $data = array();
            $video_id = $request['video_id'];
    
            Property_videos::where('property_id', '=', $property['id'])->update(['main_video' => 0]);
    
            $status = Property_videos::where('id', '=', $video_id)->update(['main_video' => 1]);
            if ($status) {
                $data['success'] = 1;
                $data['message'] = 'Cover Video Successfully Saved !';
            } else {
                $data['success'] = 0;
                $data['error'] = 'Cover Video Failed !';
            }
            return response()->json($data);
            die;
        } else {
            return back()->with('error', 'Error on Updating Cover Video !');
        }
    }

    // Feature Video

    public function featureVideo(Request $request)
    {
        $property = session('property');
        if(!is_null($property)) {
            $data = array();
            
            $videos = Property_videos::where('property_id', '=', $property->id)->get();
            foreach ($videos as $video) {
                $video->featured = 0;
                $video->save();
            }
           
            $status = Property_videos::where('id', '=', $request['video_id'])->update(['featured' => 1]);
            if ($status) {
                $data['success'] = 1;
                $data['message'] = 'Feature Video Successfully Saved !';
            } else {
                $data['success'] = 0;
                $data['error'] = 'Feature Video Failed ! !';
            }
            return response()->json($data);
            die;
        } else {
            return back()->with('error', 'Error on Updating Featured Video !');
        }
    }

    // Delete Property video 

    public function deleteVideo($id)
    {
        if(!is_null($id)) {
            $data = array();
            $property_video = Property_videos::find($id);
            $property_id = $property_video->property_id;
            $path = public_path() . '/files/property_videos/' . $property_id . '/';
            if(is_null($property_video->video_url)) {
                if (file_exists($path)) {
                    unlink($path . $property_video->file_name);
                }
                if ($property_video->delete()) {
                    $data['success'] = 1;
                    $data['message'] = "Video is Deleted !";
                } else {
                    $data['success'] = 0;
                    $data['error'] = "Video is Not Deleted !";
                }
            } else if ($property_video->delete()) {
                    $data['success'] = 1;
                    $data['message'] = "Video is Deleted !";
                } else {
                    $data['success'] = 0;
                    $data['error'] = "Video is Not Deleted !";
                }
            return response()->json($data);
            die;
        } else {
            return back()->with('error', 'Error on Deleting Video !');
        }
    }

    // Save save3dmatterport video url

 

    // Delete save3dmatterport video url

  

    // save url video 

    public function Save_Url_Video(Request $request){
        
        $property = session('property');
        if(!is_null($property)) {
            $property_videos = Property_videos::where('property_id', '=', $property['id'])->count();
    
            if($property_videos >= 2){
                return redirect()->back()->with('error', 'You have Exceed your Video Uplaod Limit');
            } else {
                $request->validate([
                    'video_url' => 'required',
                ]);
    
                $property_video = new Property_videos();
                $property_video->property_id = $property['id'];
                $property_video->video_type = $request['video_source'];
                $property_video->video_url = $request['video_url'];
                $status = $property_video->save();
                if($status) {
                    return redirect('/agent/video/video')->with('success', 'Video Url Has been Saved');
                } else {
                    return back()->with('error', 'Video Url not saved');
                }
            }
        } else {
            return back()->with('error', 'Error on Updating Video Detailes !');
        }
    }
}
