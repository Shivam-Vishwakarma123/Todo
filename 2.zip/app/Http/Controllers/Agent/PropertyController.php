<?php

namespace App\Http\Controllers\Agent;

use App\Models\Property_visit_logs;
use Illuminate\Http\Request;
use App\Models\Amenities;
use App\Models\Agents;
use App\Models\AgentContactRequests;
use App\Models\Properties;
use App\Models\Property_videos;
use App\Models\Property_images;
use Illuminate\Support\Facades\File;
use App\Models\States;
use App\Models\Cities;
use App\Models\PropertyAmenities;
use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use App\Models\credit_logs;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Intervention\Image\Response;

class PropertyController extends Controller
{

    public function listing(Request $request)
    {
        $agent = session('agent');
        $request->session()->forget('property');
        $properties = Properties::where('agent_id', '=', $agent["id"])->with('property_images', 'property_floorplans')->orderBy('updated_at', 'desc')->paginate(5);
        if ($properties->count() > 0) {
            foreach ($properties as $propertie) {
                $state_name = States::where('id', '=', $propertie->state_id)->first();
            }
        } else {
            $state_name = '';
        }
        // to check either the agent device is mobile or desktop
        $device = new \Jenssegers\Agent\Agent;
        return view(($device->isMobile() ? 'Agent/Property/mobile_listing' : 'Agent/Property/listing'), compact('properties', 'agent', 'state_name'));
    }

    // Action For View Property Address Page
    public function address($unique_url = null)
    {
        $agent = session('agent');
        $agent = Agents::where('id', $agent["id"])->first();
        $states = States::orderBy('name', 'asc')->get();
        $cities = Cities::orderBy('name', 'asc')->get();

        // Notification::send(null,new SendPushNotification($title,$message,$fcmTokens));

        if (!is_null($unique_url)) {
            $property = Properties::where('unique_url', '=', $unique_url)->with('country', 'state', 'city')->first();
            if (is_null($property)) {
                return abort('404');
            }
            //Add in session for pages in Property editor
            session()->put('property', $property);

            return view('Agent/Property/address', compact('property', 'agent', 'states', 'cities'));
        } else {
            return view('Agent/Property/address', compact('agent', 'states', 'cities'));
        }
    }

    // Action For View Property Listing Type Page
    public function listingType()
    {
        $propertie = session('property');
        if (!is_null($propertie)) {
            if ($propertie['id']) {
                $property = Properties::find($propertie->id);
                return view('Agent/Property/listing_type', compact('property'));
            } else {
                return view('Agent/Property/listing_type');
            }
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access property listing type directly !');
        }
    }

    // Action For View Property Amenities Page
    public function amenities()
    {
        $propertie = session('property');
        if (!is_null($propertie)) {
            if ($propertie->id) {
                $property = Properties::find($propertie->id);
                // check for display all amenities of agent_id = 0 and logged in agent_id
                $amenities = Amenities::where('agent_id', '=', 0)->orWhere('agent_id', '=', $property->agent_id)->get();

                //Add in session for pages in Property editor
                session()->put('property', $property);

                $amenities_array = [];
                if (isset($property->property_amenities)) {
                    foreach ($property->property_amenities as $property_amenities) {
                        $amenities_array[] = $property_amenities->amenity_id;
                    }
                }
                return view('Agent/Property/amenities', compact('amenities', 'property', 'amenities_array'));
            } else {
                return view('Agent/Property/address');
            }
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access Amenities directly !');
        }
    }

    //  Action For View Property Description Page
    public function description()
    {
        $propertie = session('property');
        if (!is_null($propertie)) {
            if ($propertie->id) {
                $property = Properties::find($propertie->id);
                return view('Agent/Property/description', compact('property'));
            } else {
                return view('Agent/Property/address');
            }
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access description directly !');
        }
    }

    // Action For View Property Price Feature Page
    public function priceFeature()
    {
        $propertie = session('property');
        if (!is_null($propertie)) {
            if ($propertie['id']) {
                $property = Properties::find($propertie->id);
                return view('Agent/Property/price_feature', compact('property'));
            } else {
                return view('Agent/Property/address');
            }
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access property price feature directly !');
        }
    }

    public function default()
    {
        $propertie = session('property');
        if (!is_null($propertie)) {
            $property = Properties::find($propertie->id);
            return view('Agent/Property/default', ['property' => $property]);
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access property url page directly !');
        }
    }

    public function publish($unique_url)
    {
        $agent = session('agent');
        $agent = Agents::find($agent['id']);
        if ($agent->credit_balance <= 0) {
            return back()->with('error', 'No credits available to publish a property. Please go to Billing page and add credits to your account.');
        }

        $property = Properties::where('unique_url', $unique_url)->first();
        if (is_null($property)) {
            return abort('404');
        }
        $property_id = $property->id;
        $property_images = Property_images::where('property_id', '=', $property_id)->count();
        $property->published = 1;
        $property->reviewed = 1;
        $property->active = 1;
        $property->publish_date = Carbon::now();

        // if property price is not set throw error
        if ($property->price == "") {
            return back()->with('error', 'Property price is not set.');
        }

        // if property city is not set throw error
        if ($property->city == "") {
            return back()->with("error", "Property city is not set");
        }

        // if Property images are not atleast 3 throw error
        if ($property_images < 3) {
            return back()->with('error', 'Property should have atleast 3 images');
        }

        if (is_null($property->expiry_date)) {
            $property->expiry_date = Carbon::now()->addDays(30);
        }

        if ($property->save()) {
            $credit_log = credit_logs::where('property_id', '=', $property_id)->where('credits', '=', '-1')->where('type', '=', 'Spent')->count();

            // if user publish new property then update credit logs
            if ($credit_log == 0) {
                $agent->credit_balance = $agent->credit_balance - 1;
                if ($agent->save()) {
                    $credit_logs = new credit_logs;
                    $credit_logs->agent_id = $agent->id;
                    $credit_logs->property_id = $property_id;
                    $credit_logs->credits = "-1";
                    $credit_logs->type = 'Spent';

                    if ($credit_logs->save()) {
                        $phone = $agent->phone;
                        $value = $property->name . "";

                        // send sms if it's not a dummy record
                        if (intval($agent->dummy_record) != 1) {
                            $this->smsRequest("154646", $value, $phone);
                        }
                        
                        return redirect('/agent/dashboard')->with('success', 'Property is published');
                    } else {
                        return back()->with('error', 'Failed to update credit log !');
                    }

                } else {
                    return back()->with('error', 'Failed to update agent credit balance !');
                }

            } else {
                return redirect('/agent/dashboard')->with('success', 'Property is published');
            }

        } else {
            return back()->with('error', 'Erorr On submit for property publish');
        }

    }

    // Action For Store Property Amenities in Property Amenities Table
    public function storeAmenities(Request $request)
    {
        $property = session('property');
        if (!is_null($property)) {
            if (is_null($property->id)) {
                $properties = new Properties;
            } else {
                $properties = Properties::where('id', '=', $property->id)->with(['property_amenities'])->first();
            }

            $properties->agent_id = $request['agent_id'];
            $amenities = $request['amenities_array'];
            $PropertyAmenities = PropertyAmenities::where('property_id', '=', $properties['id'])->get();
            foreach ($PropertyAmenities as $pa) {
                $pa->delete();
            }
            if ($amenities) {
                $amenities_array_data = explode(",", $amenities);
                foreach ($amenities_array_data as $amenities_array) {
                    if (!is_numeric($amenities_array)) {
                        $amenitie = new Amenities;
                        $amenitie->agent_id = $property['agent_id'];
                        $amenitie->name = $amenities_array;
                        if ($amenitie->save()) {
                            $property_amenities = new PropertyAmenities;
                            $property_amenities->property_id = $property['id'];
                            $property_amenities->amenity_id = $amenitie->id;
                            $property_amenities->save();
                        }
                    } else {
                        $property_amenities = new PropertyAmenities;
                        $property_amenities->property_id = $property['id'];
                        $property_amenities->amenity_id = $amenities_array;
                        $property_amenities->save();
                    }
                }
            }
            return redirect('/agent/property/price-feature')->with('success', 'Property Amenities Has been Saved');
        } else {
            return back()->with('error', 'Error on Updating Property Amenities !');
        }

    }

    // Action For Store Property Description in Properties Table
    public function storeDescription(Request $request)
    {
        $property = session('property');
        if (!is_null($property)) {
            if (is_null($property->id)) {
                $properties = new Properties;
            } else {
                $properties = Properties::where('id', '=', $property->id)->first();
            }

            $properties->description = $request['description'];
            $properties->save();

            return redirect('/agent/property/amenities')->with('success', 'Property Description Has been Saved');
        } else {
            return back()->with('error', 'Error on Updating Property Desctiption !');
        }

    }

    // Action For Store Property Price And Features in Properties Table
    public function storePriceFeature(Request $request)
    {
        $property = session('property');
        if (!is_null($property)) {
            if (is_null($property->id)) {
                $properties = new Properties;
            } else {
                $properties = Properties::where('id', '=', $property->id)->first();
            }

            $properties->price = $request['price'];
            $properties->bedroom = $request['bedroom'];
            $properties->bathroom = $request['bathroom'];
            $properties->balconies = $request['balconies'];
            $properties->floor_no = $request['floor_no'];
            $properties->total_floors = $request['total_floors'];
            $properties->open_parkings = $request['open_parkings'];
            $properties->covered_parkings = $request['covered_parkings'];
            $properties->carpet_area = $request['carpet_area'];
            $properties->super_area = $request['super_area'];
            $properties->furnishing_type = $request['furnishing_type'];
            $properties->available_from = $request['available_from'];
            $properties->security_deposit = $request['security_deposit'];
            $properties->agreement_period = $request['agreement_period'];

            $properties->save();

            return redirect('/agent/property-images/images')->with('success', 'Property Price And Features Has been Saved');
        } else {
            return back()->with('error', 'Error on Updating Property Price & Features !');
        }

    }

    // Action For Store Property Listing Type in Properties Table
    public function storeListingType(Request $request)
    {
        $property = session('property');
        if (!is_null($property)) {
            if (is_null($property->id)) {
                $properties = new Properties;
            } else {
                $properties = Properties::where('id', '=', $property->id)->first();
            }

            $properties->sale_rent = $request['sale_rent'];
            $properties->property_type = $request['property_type'];
            $properties->property_condition = $request['property_condition'];
            $properties->property_age = $request['property_age'];
            $properties->bank_loan = $request['bank_loan'];
            $properties->rera_approved = $request['rera_approved'];
            $properties->sale_booking_amount = $request['booking_amount'];
           
            $properties->save();

            return redirect('/agent/property/description')->with('success', 'Property Listing Type Has been Saved');
        } else {
            return back()->with('error', 'Error on Updating Property Listing Type !');
        }
    }

    // Action For Store Property Address in Property Amenities Table
    public function storeAddress(Request $request, $id = null)
    {

        $validator = Validator::make($request->all(), [
            'address_line_1' => 'required',
            'city_id' => 'required',
            'state_id' => 'required',
        ]);

        if ($request->all()["state_id"] === "0") {
            return back()->withInput()->with("error", "State is the mandatory field");
        }
        if ($validator->fails()) {
            return back()->withInput()->with('error', 'Property type, Area/Location, City and State are mandatory fields.');
        } else {

            //Get City name to add in slug
            $tmp_city = Cities::where('id', '=', $request['city_id'])->first();
            $unique_url = Str::slug($request['address_line_1'] . " " . $tmp_city->name, '-');

            // to find data if unique url matches with some exiting unique url's
            $propertie = Properties::where('unique_url', $unique_url)->first();
            if ($propertie) {
                // if unique url matches with some existing data then count number of rows matching with this url
                $propertie = Properties::where('unique_url', 'like', $unique_url . '%')->count();
                // generate unique url by adding an (increment 1 to number of rows) after the url's string
                $unique_url = $unique_url . "-" . $propertie;
            }

            if (is_null($id)) {
                $properties = new Properties;
            } else {
                $properties = Properties::where('id', '=', $id)->first();
            }

            $properties->agent_id = $request['agent_id'];
            $properties->name = $request['address_line_1'];
            $properties->unique_url = $unique_url;
            $properties->address_line_1 = $request['address_line_1'];
            $properties->address_line_2 = "";
            $properties->state_id = $request['state_id'];
            $properties->city_id = $request['city_id'];
            $properties->zip = $request['zip'];
            $properties->country_id = "101";
            $properties->matterport_data = $request['address_line_1'];
            $properties->publish_date = date('Y-m-d H:i:s');

            if ($properties->save()) {
                $property = Properties::where('id', '=', $properties->id)->first();
                $request->session()->put('property', $property);
                return redirect('/agent/property/listing-type')->with('success', 'Property Address Has been Saved');
            } else {
                return back()->with('error', 'Property is not saved');
            }

        }
    }

    // to enable or disable a property by agent panel after publish a property
    public function status($unique_url)
    {
        $agent = session('agent');
        $property = Properties::where('unique_url', $unique_url)->first();

        // to check whether the property belongs to logged agent or not
        if ($property->agent_id == $agent['id']) {
            if ($property->active == 1) {
                $property->active = 0;
            } else {
                $property->active = 1;
            }

            if ($property->save()) {
                return back()->with('success', "Property status updated successfully.");
            } else {
                return back()->with('error', 'Error updating the property status. Please try again.');
            }
        } else {
            // show error if property does not belongs to the logged agent
            return back()->with('error', 'You can update status of your own properties only.');
        }
    }

    // to delete a property by agent panel
    public function delete($unique_url)
    {
        // to find agent logged agent details from session
        $agent = session('agent');
        $agent = Agents::find($agent["id"]);
        $property = Properties::where('unique_url', $unique_url)->first();
        if (is_null($property)) {
            return abort('404');
        }
        $property_id = $property->id;

        // to check whether the property belongs to logged agent or not
        if ($property->agent_id == $agent->id) {
            // transaction started to either delete all table data or no one table data delete
            DB::beginTransaction();
            try {
                // to delete property videos data from table property_videos
                Property_videos::where('property_id', $property_id)->delete();

                // to delete property images data from property_images table
                Property_images::where('property_id', $property_id)->delete();

                // to delete property amenities data from property_ammenities table
                PropertyAmenities::where('property_id', $property_id)->delete();

                // to delete property related all data from properties table
                $propertie = Properties::find($property_id)->delete();
                // to check if a property exists or not
                if ($propertie) {
                    DB::commit();

                    // to delete videos folder of current property id
                    File::deleteDirectory(public_path('files/property_videos/' . $property_id));

                    // to delete images folder of current property id
                    File::deleteDirectory(public_path('files/property_images/' . $property_id));


                    // delete all table data and redirect back
                    return redirect()->back()->with('success', 'Property deleted successfully');
                } else {
                    DB::rollback();
                }
            } catch (\Throwable $e) {
                // if some error occurs , rollback and no data will delete from any table
                DB::rollback();
                // return back with error message
                return back()->with('error', 'There is some error in deleting property details');
            }
        } else {
            // show error if property does not belongs to the logged agent  
            return back()->with('error', 'You can not delete this property.');
        }
    }

    public function contactRequest($hash)
    {
        $request_details = AgentContactRequests::where('hash', $hash)->first();

        $properties = Properties::select('name', 'unique_url')->where('id', $request_details->property_id)->first();

        return view('Agent.agents.contact_request_details', compact('request_details', 'properties'));

    }

    public function property_views(Request $request)
    {
        $date = today()->subDays(7);
        $start_date = $request->start;
        $end_date = $request->end;
        if ($start_date != "" && $end_date != "") {
            if ($request->property_id) {
                $data = Property_visit_logs::where(
                    [
                        ['agent_id', $request->id],
                        ['visit_date', '>=', $start_date],
                        ['visit_date', '<=', $end_date],
                        ['property_id', '=', $request->property_id]
                    ]
                )->with('properties');
            } else {
                $data = Property_visit_logs::where(
                    [
                        ['agent_id', $request->id],
                        ['visit_date', '>=', $start_date],
                        ['visit_date', '<=', $end_date],
                    ]
                )->with('properties');
            }
        } else {
            $data = Property_visit_logs::where(
                [
                    ['agent_id', $request->id],
                    ['created_at', '>=', $date]
                ]
            )->with('properties');
        }

        if ($request->property_id) {
            $visit_dates_tmp = $data->select("visit_date")->groupBy("visit_date")->get();
            $visit_dates_arr = [];
            // array of the the visited dates
            foreach ($visit_dates_tmp as $f) {
                array_push($visit_dates_arr, $f->visit_date);
            }

            $data = $data->select('visit_date', DB::raw('count(*) as total_views'))
                ->groupBy('visit_date')
                ->get();

            $current = strtotime($start_date);
            $date2 = strtotime($end_date);
            $stepVal = '+1 day';
            while ($current <= $date2) {
                $tmp = date("Y-m-d", $current);

                if (!in_array($tmp, $visit_dates_arr)) {
                    $pages_array = (object) array('visit_date' => $tmp, 'total_views' => 0);
                    $data[sizeof($data)] = $pages_array;
                }
                $current = strtotime($stepVal, $current);
            }

        } else {
            $data = $data->select('property_id', DB::raw('count(*) as total_views'))
                ->groupBy('property_id')
                ->get();

        }

        return $data;
    }
    public function visit_stats(Request $request)
    {
        $agent = session('agent');
        $agent = Agents::where('id', $agent["id"])->first();
        $properties = Properties::where('agent_id', '=', $agent->id)->get();
        return view('Agent.agents.visit_stats', compact('agent', 'properties'));
    }
}