<?php

namespace App\Http\Controllers\Agent;

use Illuminate\Http\Request;
use App\Models\Properties;
use App\Models\Property_images;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Controller;
use Intervention\Image\ImageManagerStatic as Image;
class PropertyImagesController extends Controller
{
    
    public function images()
    {
        $property = session('property');
        if(!is_null($property)) {
            $property = Properties::find($property->id);
            $property_images = Property_images::where('property_id', '=', $property->id)->get();
            return view('Agent/property-images/images',['property'=>$property,'property_images'=>$property_images]);
        } else {
            $device = new \Jenssegers\Agent\Agent;
            return redirect(($device->isMobile() ? 'agent/property/mobile_listing' : 'agent/property/listing'))->with('error', 'You can not access Property Images directly !');
        }
    }

    public function storeImage(Request $request)
    {
        $data = array();
        $validator = Validator::make($request->all(), [
            'file.*' => 'required|mimes:png,jpg,jpeg',
            'property_id' => 'required'
        ]);

        $property_id = $request['property_id'];
        if ($validator->fails()) {
            $data['success'] = 0;
            $data['error'] = $validator->errors()->first('file'); // Error response
        } else {
            $files = $request->file('file');
            $i=0; // variable to accessing size of multiple upload files
            foreach($files as $file) {

                $filename = time() . '_' . str_replace(" ", "_", $file->getClientOriginalName());

                // sepreate image name and extension 
                $remove_extension = explode('.',$filename);

                // get image name and add extension JPG 
                $image_name = $remove_extension[0].'.jpg';

                // File upload location
                $path = public_path() . '/files/property_images/' . $property_id;
                $thumbnails_path = public_path() . '/files/property_thumbs/' . $property_id;

                // create image with gd extension
                $imgFile = Image::make($file->path());
                $thumbnail = Image::make($file->path());

                // Upload file
                if (!File::exists($path)) {
                    File::makeDirectory($path,0755,false);
                }
                if (!File::exists($thumbnails_path)) {
                    File::makeDirectory($thumbnails_path,0755,false);
                }

                $thumbnail->resize(310, 240, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($thumbnails_path.'/'.$image_name);

                // Resize image resolution and save on given path 
                $imgFile->resize(1138, 500, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.'/'.$image_name);

                $property_image = new Property_images;
                $property_image->property_id = $property_id;
                $property_image->file_name = $image_name;

                if($property_image->save()){
                    $property_image = Property_images::where('file_name', '=', $image_name)->first();
                    $data[$i]['success'] = 1;
                    $data[$i]['message'] = 'Uploaded Successfully!';
                    $data[$i]['image_id'] = $property_image->id;
                    $data[$i]['property_id'] = $property_image->property_id;
                    $data[$i]['file_name'] = $property_image->file_name;
                } else {
                    // Response
                    $data['success'] = 0;
                    $data['error'] = 'File not uploaded.';
                }
                $i++;
            }
        }
        return back();
    }

    // delete property  image 
    public function daleteImage($id)
    {
        if(!is_null($id)) {
            $data = array();
            $property_image = Property_images::find($id);
            $property_id = $property_image->property_id;
            $path = public_path() . '/files/property_images/' . $property_id . '/';
            $thumbnails_path = public_path() . '/files/property_thumbs/' . $property_id . '/';

            if (file_exists($path)) {
                unlink($path . $property_image->file_name);
                if(file_exists($thumbnails_path)){
                    unlink($thumbnails_path . $property_image->file_name); 
                }
                $status=$property_image->delete();
                if ($status) {
                    $data['success'] = 1;
                    $data['message'] = "Image is Deleted !";
                } else {
                    $data['success'] = 0;
                    $data['error'] = "Image is Not Deleted !";
                }
            }else{
                $data['success'] = 0;
                $data['error'] = "Error Deleting Data !";
            }
            return response()->json($data);
            die;
        } else {
            return back()->with('error', 'Error on Deleting Image !');
        }
    }

    //Rotate Image

    public function rotateImage($id, Request $request)
    {
        if(!is_null($id)) {
            $property_image = Property_images::find($id);
            $image_file = $property_image->file_name;
            $image_path = public_path() . '/files/property_images/' . $property_image->property_id . '/';
            $thumbnail_path = public_path() . '/files/property_thumbs/' . $property_image->property_id . '/';
            $degrees = $request->degrees;
            $degrees = $degrees * -1;
    
            // Load
            $ext = strtolower(substr(basename($image_file), strrpos(basename($image_file), ".") + 1));
            $image = $image_path . $image_file;
            $source = "";
            if ($ext == "png") {
                $source = imagecreatefrompng($image);
            } elseif ($ext == "jpg" || $ext == "jpeg") {
                $source = imagecreatefromjpeg($image);
            } elseif ($ext == "gif") {
                $source = imagecreatefromgif($image);
            }
            // Rotate
            $rotate = imagerotate($source, $degrees, 0);

            // Create thumbnail
            $thumbnail = imagecreatetruecolor(310, 240);
            imagecopyresampled($thumbnail, $rotate, 0, 0, 0, 0, 310, 240, imagesx($rotate), imagesy($rotate));

            $oldFilename = $image_file;
            $parts = explode("_", $oldFilename);
            $newFilename = time() . "_" . $parts[1];
            // Output
            if ($ext == "png" || $ext == "PNG") {
                if (imagepng($rotate, $image_path . $newFilename, 0)) {
                    echo $degrees;
                }
            } elseif ($ext == "jpg" || $ext == "jpeg" || $ext == "JPG" || $ext == "JPEG") {
                imagejpeg($rotate, $image_path . $newFilename, 90);
            } elseif ($ext == "gif" || $ext == "GIF") {
                imagegif($rotate, $image_path . $newFilename);
            }

            $property_image ->file_name = $newFilename;
            if($property_image->save()){
                // Removed old file
                if (file_exists($image_path . $oldFilename)) {
                    unlink($image_path . $oldFilename);
                    if(file_exists($thumbnail_path . $oldFilename)){
                        unlink($thumbnail_path . $oldFilename); 
                    }
                }
            }

            // Save thumbnail image
            imagejpeg($thumbnail, $thumbnail_path . $newFilename, 90);
            //     // Free the memory
            imagedestroy($source);
            imagedestroy($rotate);
            $data=array();
            $data['file_name']=$newFilename;
            $data['path']=$image_path;
            $data['property_id']=$property_image->property_id;
            
            return response()->json($data);
        } else {
            return back()->with('error', 'Error on Rotating Image !');
        }
    }


}
