<?php

namespace App\Http\Controllers\Agent;

use Illuminate\Http\Request;
use App\Models\Agents;
use App\Models\AgentContactRequests;
use App\Models\States;
use App\Models\Countries;
use App\Models\Plans;
use App\Models\Agent_addresses;
use App\Models\Payments;
use App\Models\credit_logs;
use App\Models\Referals;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\Properties;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Cookie;
use App\Http\Controllers\Controller;
use PDF;
use Intervention\Image\ImageManagerStatic as Image;

class AgentsController extends Controller
{
    public function agents()
    {
        return redirect('agent/sign-in');
    }

    public function SignUp(Request $request)
    {
        if(!($request->session()->has('phone')))
        {
            return redirect('/agent/sign-in')->with('error', 'Please validate your phone number');
        }
        $phone = session('phone');
        
        if ($request->isMethod('post')) 
        {
            $request->validate([
                'first_name' => 'required',
                'last_name' => 'required',
                'handle' => 'required|unique:agents,handle',
            ]);

            $initial_credits = 10;           //For launch period
            $bonus_credits = 5;

            //Process agent handle string
            $tmp_handle = str_replace(" ", "-", strtolower(trim($request['handle'])));

            $agent = new Agents;
            $agent->first_name = trim($request['first_name']);
            $agent->last_name = trim($request['last_name']);
            $agent->email = trim($request['email']);
            $agent->phone = trim($phone);
            $agent->handle = $tmp_handle;
            $agent->credit_balance = $initial_credits;

            if($agent->save()){

                $agent = Agents::where('phone', '=', $phone)->first();
                $request->session()->forget('phone'); 
                $request->session()->put('agent', $agent);
                Cookie::queue('agent', $agent, 43200);

                
                // Saving credits into credit_logs as the user Bonus
                $credit_logs = new credit_logs; 
                $credit_logs->agent_id = $agent['id'];
                $credit_logs->property_id = 0;
                $credit_logs->credits = $initial_credits;
                $credit_logs->type = 'Bonus';


                // Checking if the new agent is invited or not
                if($request->session()->has('handle'))
                {
                    $handle = session('handle');
                    $agent_handle = Agents::where('handle',$handle)->first();

                    //update referral data
                    $referred = new Referals;
                    $referred->agent_id = $agent_handle->id;
                    $referred->joined = 1;
                    $referred->referred_to = $phone;
                    $referred->save();
                    
                    // updating the credits/ credit balance of the invited person
                    $credit_agent = new credit_logs; 
                    $credit_agent->agent_id = $agent['id'];
                    $credit_agent->property_id = 0;
                    $credit_agent->credits = $bonus_credits;
                    $credit_agent->type = 'Invited';
                    $credit_agent->save();

                    $agent->credit_balance = $agent->credit_balance +5;
                    $agent->save();

                    // 5 more credits to the agent who referred
                    $referred_by = new credit_logs;
                    $referred_by->agent_id = $agent_handle->id;
                    $referred_by->property_id = 0;
                    $referred_by->credits = $bonus_credits;
                    $referred_by->type = 'Invited';

                    if($referred_by->save())
                    {
                        $agent_handle->credit_balance = $agent_handle->credit_balance +5;
                        $agent_handle->save();
                    }
                }
                if($credit_logs->save()){
                    //Auto login agent
                    Auth::login($agent);
                    return redirect('/agent/dashboard');
                }else{
                    $request->session()->flash('error', 'Error creating new agent. Please try again.');
                    return view('Agent/agents/SignUp', compact('phone'));
                }
            }else{
                $request->session()->flash('error', 'Error creating new agent. Please try again.');
                return view('Agent/agents/SignUp', compact('phone'));
            }
        }
        else
        {
            return view('Agent/agents/SignUp', compact('phone'));
        }
    }

    public function agents_address(Request $request){
        $agent = session('agent');
        $countries = Countries::where('country_id' , '=' ,'101')->first();
        $states = States::orderBy('name', 'asc')->get();
        $data = compact('states','countries');
        return view('Agent.agents/agent_addresses')->with($data);
    }

    public function agents_address_add(Request $request)
    {
        $agent = session('agent');
        $request->validate([
            'phone' => 'required|numeric|digits:10',
            'state_id' => 'required',
            'city_id' => 'required',
            'zip' => 'required|numeric',
            'address' => 'required',
        ]);
        $agent_address = new Agent_addresses;
        $country = Countries::where('name' ,'=' ,$request['country_name'])->first();
        if (isset($request['business_name'])) {
            $agent_address->business_name = $request['business_name'];
        }
        $agent_address->agent_id = $agent['id'];
        $agent_address->phone = $request['phone'];
        $agent_address->address = $request['address'];
        $agent_address->city_id = $request['city_id'];
        $agent_address->state_id = $request['state_id'];
        $agent_address->country_id = $country->country_id;
        $agent_address->zip = $request['zip'];

        if($agent_address->save())
        {
            return redirect('/agent/dashboard')->with('success', 'Your address has been saved!');
        }else{
            return redirect('/agent/property/address')->with('error', 'Error Saving Data. Please try again.');
        }
    }   

    //Agent profile 
    public function profile(Request $request){
        $agent = session('agent');
        $request->session()->forget('property');
        $agent_address = Agent_addresses::where('agent_id', '=', $agent["id"])->with('state','country','city');
        ($agent_address->count() > 0) ? $agent_address = $agent_address->first() : $agent_address = false;
        $agent = Agents::find($agent["id"]);
        $states = States::orderBy('name','asc')->get();
        $countries = Countries::orderBy('name','asc')->get();
        $data = compact('agent_address','agent');
        $device = new \Jenssegers\Agent\Agent;
        return view('Agent.agents.profile')->with($data);
    }

    // Update Profile Details

    public function editProfileDetails(Request $request){
        $agent = session('agent');
        $validator = Validator::make($request->all(), [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|regex:/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/',
        ]);
        if ($validator->fails()) {
            $request->session()->flash('error', $validator->errors()->first());
        } else {
            $status = Agents::where('id', '=', $agent["id"])
             ->update(['first_name' => $request['first_name'],'last_name' => $request['last_name'],'email' => $request['email']]);
            if($status){
               $agent = Agents::where('id', '=', $agent['id'])->first();
                $request->session()->put('agent', $agent);
                $request->session()->flash('success', 'Profile details is updated');
            }else{
                $request->session()->flash('error', 'Profile details is Not updated');
            }
        }
        return redirect('/agent/profile');
    }

    //Update Profile Address

    public function editProfileAddress(Request $request){
        $agent = session('agent');
        $validator = Validator::make($request->all(), [
            'phone' => 'required|numeric|digits:10',
            'address' => 'required',
            'city_id' => 'required',
            'zip' => 'required|numeric',
            'state_id' => 'required',
        ]);
        if($request->all()["state_id"] === "0")
        {
            return back()->withInput()->with("error","State is the mandatory field") ;
        }
        if ($validator->fails()) {
            $request->session()->flash('error', $validator->errors()->first());
        } else {
            $country = Countries::where('name' ,'=' ,$request['country'])->first();
            $status = Agent_addresses::where('agent_id', '=', $agent["id"]);
            if($status->count() > 0) {
                
                $status->update(['business_name' => $request['business_name'],'rera_no' => $request['rera_no'], 'gst_no' => $request['gst_no'],
                'address' => $request['address'],'city_id' => $request['city_id'],'state_id' => $request['state_id'],'zip' => $request['zip'],
                'country_id' => $country->country_id,'phone' => $request['phone']]);
            } else {

                $agent_address = new Agent_addresses;
                $agent_address->business_name = $request['business_name'];
                $agent_address->rera_no = $request['rera_no'];  
                $agent_address->gst_no = $request['gst_no'];  
                $agent_address->agent_id = $agent['id'];
                $agent_address->phone = $request['phone'];
                $agent_address->address = $request['address'];
                $agent_address->city_id = $request['city_id'];
                $agent_address->state_id = $request['state_id'];
                $agent_address->country_id = $country->country_id;
                $agent_address->zip = $request['zip'];
                $agent_address->save();

            }
            if($status || $agent_address){
                $request->session()->flash('success', 'Profile address is updated');
            }else{
                $request->session()->flash('error', 'Profile address is Not updated');
            }
        }
        return redirect('/agent/profile');
    }

    // Update Social Media

    public function AddSociaMediaProfile(Request $request){

        $agents = session('agent');
        $status = Agents::where('id', '=', $agents['id'])->update([
                    'facebook_profile' => $request['facebook_profile'],
                    'instagram_profile' => $request['instagram_profile'],
                    'twitter_profile' => $request['twitter_profile'],
                    'linkedin_profile' => $request['linkedin_profile'],
                    'whatsapp_no' => $request['whatsapp_no']
                ]);
        if($status){
            $request->session()->flash('success', 'Profile social media is updated');
        }else{
            $request->session()->flash('error', 'Profile social media is Not updated');
        }
     
        return redirect('/agent/profile');
    }
    

    // Update Profile Image

    public function editProfileImage(Request $request){
        $agent = session('agent');

        $path = public_path() . '/files/agents/' . $agent["id"].'/';
            
        /*for ajax */
        $image_parts = explode(";base64,", $request->image);

        $image_base64 = base64_decode($image_parts[1]);
        $imageName = time() . '_' . '.png';
        $imageFullPath = $path.$imageName;

        if (!File::isDirectory($path)) {
            File::makeDirectory($path, 0755, false, true);
        }
        file_put_contents($imageFullPath, $image_base64);
        $imgFile = Image::make($imageFullPath);
        $imgFile->resize(215,245,function($constraint){
            $constraint->aspectRatio();
        })->save($imageFullPath);
        $status = Agents::where('id', '=', $agent["id"])
            ->update(['profile_image' => $imageName]);
            if($status){
                $request->session()->flash('success', 'Profile Pic is updated');
            }else{
                $request->session()->flash('error', 'Profile Pic is Not updated');
            }
            return redirect('/agent/profile');
    }

    // Delete delete Profile Image

    public function deleteProfileImage(){
        $agent = session('agent');
        $agents = Agents::find($agent["id"]);
        $path = public_path() . '/files/agents/' . $agent["id"] . '/';
        if (file_exists($path)) {
            unlink($path . $agents->profile_image);
            $status = Agents::where('id', '=', $agent["id"])
             ->update(['profile_image' => "",]);
             if($status){
                $data['success'] = 1;
               // $data['message'] = "Profile Image is deleted !";
               return redirect('agent/profile')->with('error', 'Profile Image is deleted !!');
             }else{
                $data['success'] = 0;
                $data['error'] = "Profile Image is Not deleted !";
             }
        }else{
            $data['success'] = 0;
            $data['error'] = "Error saving data.";
        }
        return response()->json($data);
        die;
    }

    // Edit Logo Image

    public function editLogoImage(Request $request){
        $agent = session('agent');
        $validator = Validator::make($request->all(), [
            'logo_image'  => 'required|mimes:png,jpg,jpeg',
        ]);

        if ($validator->fails()) {
            $request->session()->flash('error', $validator->errors()->first('logo_image'));
        } else {
            $logo_image = $request->file('logo_image');
            $logo_image_name = time() . '_' . $logo_image->getClientOriginalName();

            // logo image upload location
            $path = public_path() . '/files/agents/' . $agent["id"];
             // create image with gd extension
             $logo_image = Image::make($logo_image->path());
            // Upload profile image
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0755, false, true);
            }
            $logo_image->resize(240, 240, function ($constraint) {
                $constraint->aspectRatio();
            })->save($path.'/'.$logo_image_name);              
            $status = Agents::where('id', '=', $agent["id"])
            ->update(['logo_image' => $logo_image_name]);
            if ($status) {
                $request->session()->flash('success', "Logo Image Uploaded Successfully!");
            } else {
                $request->session()->flash('error', "Error saving data.");
            }
        }
        return redirect('/agent/profile');
    }

    // Delete delete Profile Image

    public function deleteLogoImage(){
        $agent = session('agent');
        $agents = Agents::find($agent["id"]);
        $path = public_path() . '/files/agents/' . $agent["id"] . '/';
        if (file_exists($path)) {
            unlink($path . $agents->logo_image);
            $status = Agents::where('id', '=', $agent["id"])
             ->update(['logo_image' => "",]);
             if($status){
                $data['success'] = 1;
               //$data['message'] = "Logo Image is deleted !";
              return redirect('agent/profile')->with('error', 'Logo Image is deleted !!');
             }else{
                $data['success'] = 0;
                $data['error'] = "Logo Image is Not deleted !";
             }
        }else{
            $data['success'] = 0;
            $data['error'] = "Error saving data.";
        }
        return response()->json($data);
        die;
    }

    public function credit_plans(){
        $agent = session('agent');
        $agent_addresses = Agent_addresses::where('agent_id', $agent["id"])->count();
        if($agent_addresses == 0)
        {
            return redirect('agent/profile')->with('error', 'Please Update your address first');
        }
        else{
            $plans = Plans::all();
            return view('Agent.agents.credit_plans',[
                'plans' => $plans,
            ]);
        }
    }
    

    // agent Billing section 
    public function billing(Request $request) {
        $agent = session('agent');
        $agents = Agents::find($agent["id"]);
        $payment_details = Payments::where([ ['agent_id', $agent["id"]]])->orderBy('id','desc')->with('plans','invoices')->paginate(5);
        $request->session()->forget('property');
        $device = new \Jenssegers\Agent\Agent;
        return view(($device->isMobile() ? 'Agent.agents.mobile_billing' : 'Agent.agents.billing'), compact('agents','payment_details'));
    }

     // to get unique handle on sign up page using ajax request starts
     public function get_unique_handle(Request $request)
     {
         $inc_value = 0;
         $unique_handle = $request->unique_handle;
         // to find total occurances of unique handle value in database
         $tot_unique_handle = Agents::where('handle', $unique_handle)->count();
         if($tot_unique_handle > 0)
         {
             $inc_value = $tot_unique_handle;
             do{
                 // calculate increment value and check it is unique or not until it becomes unique
                 $inc_value += 1;
                 $tot_unique_handle = Agents::where('handle', $unique_handle.$inc_value)->count();
 
             }while($tot_unique_handle > 0);
 
             // concatenate old value and incremented value to give unique value as response
             $unique_handle = $unique_handle.$inc_value;
         }
         return $unique_handle;
     }
     // to get unique handle on sign up page using ajax request ends

     // to show/download agent qr code pdf
    public function qr_code(Request $request)
    {
        $agent = Agents::where('handle', $request->handle)->with('agent_addresses')->first();
        $pdf = PDF::loadView('Agent/agents/qr_code', compact('agent'));
        return $pdf->download($agent->handle.'.pdf');
    }

    public function contact_request_listing($request_id = null)
    {    
        $agent = session('agent');
        if(!is_null($request_id)){
            $request_details = AgentContactRequests::where('id', $request_id)->first(); 
            $properties = Properties::where('id',$request_details->property_id)->first();
            return view(('Agent.agents.contact_request_details'), compact('request_details','properties'));
        }
        else{
            $contact_request = AgentContactRequests::where('agent_id' , '=' ,$agent["id"])->paginate(10);
            return view(('Agent.agents.contact_request_listing'), compact('contact_request'));
        }       
    }
    public function brokerageFee(Request $request)
    {
        // echo $request;
        $agent = session('agent');
        if($request['sale_fee_type'] != "Variable" && $request['sale_fee_amount'] =="")
        {
            return back()->with('error', 'Sale Fee Amount is mandatory.'); 
        }
        if($request['rent_fee_type'] != "Variable" && $request['rent_fee_amount'] == "")
        {
            return back()->with('error', 'Rent Fee Amount is mandatory.');
        }
        $status = Agents::where('id', '=', $agent["id"])
        ->update(['sale_fee_type' => $request['sale_fee_type'],'sale_fee_amount' => $request['sale_fee_amount'],'rent_fee_type' => $request['rent_fee_type'],'rent_fee_amount'=>$request['rent_fee_amount']]);
        if($status) return back()->with('success', 'Brokerage fee saved.');
        else return back()->with('error','Brokerage fee not saved.');
        
    }

    public function sendInvitations(Request $request)
    {
        if(isset($request->handle)) {
            $agent = Agents::where("handle",$request->handle)->first();
            if($agent != "")
            {
                $request->session()->put('handle', $request->handle);
                return redirect('agent/sign-in');
            }
        }
        return redirect('/')->with('error','The URL is invalid. Redirected to Home');
    }
    }