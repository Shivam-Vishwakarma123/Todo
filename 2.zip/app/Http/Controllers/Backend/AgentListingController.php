<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Properties;
use App\Models\Agent_addresses;
use App\Models\Agents;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;


class AgentListingController extends Controller
{
    public function index(Request $request)
    {
        $agents = Agents::all();
        $agents = $agents->sortByDesc('created_at');
        return view('backend.agent-listing',compact('agents'));
    }

    public function status(Request $request)
    {
        $data = array();
        $agents = Agents::find($request['id']);
        if($agents->active == 1){
            $agents->active = 0;
        }else{
            $agents->active = 1;
        }
        $data['status'] = $agents->active;
        if($agents->save()){
            $data['messege'] = "1";
        }else{
            $data['messege'] = "0";
        }
        return response()->json($data);
        die;
    }
    public function delete(Request $request){
        $data = array();
        $property = Properties::where('agent_id' , '=' ,$request['Id'])->get();
        if(count($property) == 0){
            $agents = Agents::find($request['Id']);
            $agent_address = Agent_addresses::where('agent_id' , '=' , $request['Id'])->first();
            if($agent_address){
                $agent_address->delete();
            }
            $agents->delete();
            $data['success'] = 1;
            $data['message'] = "Agent is Deleted !";
        }else{
            $data['success'] = 0;
            $data['message'] = "Erorr deleting Agent. Agent have Properties";
        }
        return response()->json($data);
        die;

    }
    
}
