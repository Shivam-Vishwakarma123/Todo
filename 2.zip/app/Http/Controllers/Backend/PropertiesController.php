<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Agents;
use App\Models\credit_logs;
use App\Models\Properties;

class PropertiesController extends Controller
{
    public function index(Request $request)
    {
        $properties = Properties::all();
        $properties = $properties->sortByDesc('created_at');

        return view('backend.properties',compact('properties'));
    }

    public function ExpiryDue(Request $request,$id){

       
        $properties = Properties::find($id);
        $properties->expiry_date = $request['new_expiry_date'];
        $agent = Agents::find($properties->agent_id);
        
        // $phone = $agent->phone;
        // $value = $properties->properties->expiry_date."";
        // $this->smsRequest("154644",$value,$phone);

        if($properties->save()){
            return redirect('/backend/properties')->with("success", "Extend Property Publish Date successfully.");
        } else {
            return redirect()->back()->with("error", "Error Saving Data ! ");
        }
    }

    public function Property_Status(Request $request)
    {    
        $data = array();
        $properties = Properties::find($request['id']);

        if($properties->published == 1)
        {
            $properties->published = 0;
            $properties->active = 0;
        } else {
            $properties->published = 1;
            $properties->active = 1;
        }

        $data['status'] = $properties->published;

        if ($properties->save()) {
            $data['message'] = "1";
        } else {
            $data['message'] = "0";
        }
        
        return response()->json($data);
        die;
    }

}
