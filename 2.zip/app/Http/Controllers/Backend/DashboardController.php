<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Payments;
use Illuminate\Http\Request;
use App\Models\Backend\Admin;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use App\Models\Agents;
use App\Models\Properties;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $id = $request->session()->get('login_admin_59ba36addc2b2f9401580f014c7f58ea4e30989d');
        $admin = Admin::where('id', '=', $id)->first();
        $request->session()->put('admin', $admin);

        $agents = Agents::all()->sortByDesc('created_at')->take(7);
        $properties = Properties::all()->sortByDesc('created_at')->take(7);
        $payments = Payments::where('status','=','Paid')->orderBy('created_at','desc')->take(7)->get();
        $data = compact('agents','properties','payments');
        return view('backend.dashboard')->with($data);
    }
}
