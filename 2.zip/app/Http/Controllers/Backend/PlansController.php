<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Plans;
use Illuminate\Support\Facades\Validator;

class PlansController extends Controller
{
    public function index($id = null)
    {
        $plan_details = "";
        if(!is_null($id))
        {
            $plan_details = Plans::find($id);
        }
        $plans = Plans::all();
        return view('backend.plans.index',compact('plan_details', 'plans'));
    }

    public function status(Request $request){
        $data = array();
        $plans = Plans::find($request['id']);
        if($plans->active == 1){
            $plans->active = 0;
        }else{
            $plans->active = 1;
        }
        $data['status'] = $plans->active;
        if($plans->save()){
            $data['messege'] = "1";
        }else{
            $data['messege'] = "0";
        }
        return response()->json($data);
        die;
    }

    // Here Add code for adding New membership plan and edit Existing plans
    public function add(Request $request, $id = null){
        $validator = Validator::make($request->all(), [
            'plan_name' => 'required',
            'price' => 'required|numeric',
            'credits' => 'required|numeric',
            'duration' => 'required|numeric'
        ]);
        if ($validator->fails()) 
        {
            return redirect()->back()->withInput()->with('error', $validator->errors()->first());
        }else 
        {
            if (is_null($id)) {
                $plan = new Plans;
            } else {
                $plan = Plans::where('id', '=', $id)->first();
            }

            $plan->name = $request['plan_name'];
            $plan->price = $request['price'];
            $plan->credits = $request['credits'];
            $plan->duration = $request['duration'];
            
            if($plan->save()){
                return redirect('/backend/plans/index')->with("success", "Added New Membership Plan successfully.");
            } else {
                return redirect()->back()->with("error", "Error Saving Data ! ");
            }
        }
    }

    // Here Add code for deleting existing membership plan
    
    public function delete($id){

        $data = array();
        $plan = Plans::where('id', '=', $id)->first();

        if($plan->delete()){
            $data['success'] = 1;
            $data['message'] = 'Deleted Membership Plan successfully.';
        } else {
            $data['success'] = 0;
            $data['message'] = 'Error Deleting Data !';
        }
        return response()->json($data);
        die;

    }
}

