<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Intervention\Image\ImageManagerStatic as Image;
use App\Models\Blogs;

class BlogsController extends Controller
{
    public function index()
    {
        $blogs = Blogs::all()->sortByDesc('updated_at');
        return view("backend.blogs", compact('blogs'));
    }
    public function delete($slug)
    {

        $data = array();
        $blog = Blogs::where('slug', '=', $slug)->first();

        if ($blog->delete()) {
            $data['success'] = 1;
            $data['message'] = 'Blog Deleted.';
        } else {
            $data['success'] = 0;
            $data['message'] = 'Error Deleting Blog !';
        }
        return response()->json($data);
        die;
    }
    public function edit($slug = null)
    {
        if (is_null($slug)) {
            return view('backend.blogs_edit');
        }
        $blog = Blogs::where('slug', '=', $slug)->first();
        return view('backend.blogs_edit', compact('blog'));

    }
    public function status(Request $request)
    {
        $data = array();
        $blog = Blogs::where('slug', '=', $request['slug'])->first();
        if ($blog->published == 1) {
            $blog->published = 0;
        } else {
            $blog->published = 1;
            $blog->published_at = now();
        }
        $data['status'] = $blog->published;
        if ($blog->save()) {
            $data['message'] = "1";
        } else {
            $data['message'] = "0";
        }
        return response()->json($data);
    }
    public function add(Request $request, $slug = null)
    {
        $blog = Blogs::where('slug', $slug)->first();
        $validator = Validator::make($request->all(), [
            'blog_title' => 'required',
            'blog_desc' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withInput()->with('error', $validator->errors()->first());
        } else {
            if (is_null($slug)) {
                $blog = new Blogs;
            } else {
                $blog = Blogs::where('slug', '=', $slug)->first();
            }
            $blog->title = $request['blog_title'];

            // If title is changed
            if ($request['blog_title']) {
                // creating slug
                $blog->slug = Str::slug($request['blog_title'], '-');
                $tot_unique_slug = Blogs::where('slug', $blog->slug)->count();
                if (($tot_unique_slug) > 0) {
                    $inc = $tot_unique_slug;
                    do {
                        // calculate increment value and check it is unique or not until it becomes unique
                        $inc += 1;
                        $tot_unique_slug = Blogs::where('slug', ($blog->slug . '-' . $inc))->count();

                    } while ($tot_unique_slug > 0);
                    $blog->slug = $blog->slug . '-' . $inc;
                }
            }

            $blog->description = $request['blog_desc'];
            if ($request['blog_image'] != "") {
                $validator = Validator::make($request->all(), [
                    'blog_image' => 'mimes:png,jpg,jpeg',
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->withInput()->with('error', $validator->errors()->first());
                } else {
                    $blog_image = $request->file('blog_image');
                    $fileName = str_replace(' ', '', $blog_image->getClientOriginalName()); // removing spaces
                    $blog_image_name = time() . '_' . $fileName;

                    // blog image
                    $path = public_path() . '/files/blogs/' . $blog->slug;
                    $blog_image = Image::make($blog_image->path());

                    if (!File::isDirectory($path)) {
                        File::makeDirectory($path, 0755, false, true);
                    }
                    $blog_image->resize(500, 500, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($path . '/' . $blog_image_name);

                    $blog->image = $blog_image_name;
                }
            }

        }
        if ($blog->save()) {
            return redirect('/backend/blogs')->with('success', 'Blog added successfully!');
        } else {
            return redirect()->back()->with("error", "Error Saving Data ! ");
        }

    }
}