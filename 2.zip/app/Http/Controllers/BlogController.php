<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Blogs;

class BlogController extends Controller
{
    public function index()
    {
        $blogs = Blogs::where('published',1)->orderBy('published_at','desc')->paginate(10);
        return view("public_site.blogs",compact('blogs'));
    }
    public function blog_details(Request $request)
    {
        $slug = $request->blog_slug;
        $blog  = Blogs::where('slug',$slug)->first();
        $blog->update(['views' => ($blog->views+1)]);
        $previous =null;
        $next = null;
        if($blog->published_at)
        {
            $previous = Blogs::where('published_at','>',$blog->published_at)->orderBy('published_at','asc')->first(); // recent
            $next = Blogs::where('published_at','<',$blog->published_at)->orderBy('published_at','desc')->first();    // older
        }
        return view("public_site.blog_details",compact('blog','next','previous'));
    }
}