<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Properties;
use App\Models\Agents;
use App\Models\Cities;
use App\Models\States;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use App\Models\Plans;
use Kutia\Larafirebase\Facades\Larafirebase;
use Psy\Readline\Hoa\Console;
use App\Models\Blogs;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{

    public function index(Request $request)
    {
        $agents = Agents::where('active', '1')->orderBy('id', 'desc')->limit(4)->with('agent_addresses')->get();
        $properties_sale = Properties::where([
            ['sale_rent', 'Sale'],
            ['published', '1'],
            ['active', '1']
        ])
            ->with('property_single_image', 'agents')
            ->orderBy('updated_at', 'desc')
            ->limit(10)
            ->get();
        $properties_rent = Properties::where([
            ['sale_rent', 'Rent'],
            ['published', '1'],
            ['active', '1']
        ])
            ->with('property_single_image', 'agents')
            ->orderBy('updated_at', 'desc')
            ->limit(10)
            ->get();
        $city_names = Cities::all();


        foreach ($agents as $agent) {
            // Total numbers of properties that agent have
            $a = Properties::where([
                ['agent_id', $agent->id],
                ['published', '1'],
                ['active', '1']
            ])
                ->count();
            $agent["property_count"] = $a;
        }

        // checking if user is not logged in
        if (isset($_GET['app_token'])) {
            $agent_session = session('agent');
            if (!(isset($agent_session) && !empty($agent_session))) {
                // storing token in session if user is not logged in
                $request->session()->put('app_token', $_GET['app_token']);
            }
        }
        $popular_cities = Properties::where(
            [['published', '1'], ['active', '1']]
        )->select('city_id', 'state_id', DB::raw('count(*) as total_properties'))
            ->groupBy('state_id',"city_id")->with('city', 'state')
            ->orderBy("total_properties", 'desc')
            ->take(5)
            ->get();

        $popular_types = Properties::where([['published', '1'], ['active', '1']])
            ->select('city_id', 'state_id', 'property_type', DB::raw('count(*) as total_properties'))
            ->groupBy('state_id',"city_id",  'property_type')
            ->with('city', 'state')
            ->orderBy("total_properties", 'desc')
            ->take(5)
            ->get();

        $propular_sale_rent = Properties::where([['published', '1'], ['active', '1']])
            ->select('city_id', 'state_id', 'sale_rent', DB::raw('count(*) as total_properties'))
            ->groupBy('state_id', "city_id", 'sale_rent')
            ->with('city', 'state')
            ->orderBy("total_properties", 'desc')
            ->take(5)
            ->get();

        $blogs = Blogs::where('published', 1)->orderBy('published_at', 'desc')->take(4)->get();
        return view('public_site.index', compact('agents', 'properties_sale', 'properties_rent', 'blogs', 'popular_cities', 'popular_types', 'propular_sale_rent'));
    }
    public function get_city_suggestions(Request $request)
    {
        $location = $request->location;
        $data = [];
        $cities = Cities::select('id', 'name', 'state_id')->distinct()->where('name', 'LIKE', '%' . $location . '%')->orderBy('name', 'asc')->get();
        foreach ($cities as $city) {
            $state_name = $city->state->name;
            array_push($data, ['label' => $city->name . ", " . $state_name, 'value' => $city->id]);
        }
        if ($data == "") {
            $data = "NONE";
        }

        return $data;
    }
    // contact us form on public site
    public function contact_us(Request $request)
    {
        $form_message = "";
        $status = "";
        // to check either the request is post or get
        $method = $request->method();
        if ($request->isMethod('post')) {
            $validator = Validator::make($request->all(), [
                'contact_name' => 'required',
                'contact_phone' => 'required|numeric|digits:10',
                'contact_message' => 'required',
            ]);
            if ($validator->fails()) {
                return back()->withInput()->with('error', $validator->errors()->first());
            } else {
                $user['name'] = $request->contact_name;
                $user['phone'] = $request->contact_phone;
                $user['message'] = $request->contact_message;
                $user['email'] = $request->contact_email;
                $user['agent_email'] = 'nandini.b@nirvaat.com';
                $user['agent_name'] = "Nandini";

                Mail::send(
                    'public_site/send_contact_us_mail',
                    ['user' => $user],
                    function ($m) use ($user) {
                        $m->from('feedback@orderly.in', 'Property Shops');
                        $m->to($user['agent_email'], $user['agent_name']);
                        $m->subject('Contact Requested On Property Shops');
                    }
                );
                // return response as success after sending mail
                $form_message = "From Submitted Successfully. We will contact you soon ";
                $status = "success";
            }
            return view('public_site.contact_us', compact('form_message', 'status'));
        } else {
            return view('public_site.contact_us');
        }
    }
    // privacy policy page on public site
    public function privacy_policy()
    {
        return view("public_site.privacy_policy");
    }
    // terms and conditions page on public site
    public function terms_conditions()
    {
        return view("public_site.terms_conditions");
    }
    // about us page on public site
    public function about_us()
    {
        return view("public_site.about_us");
    }
    // overview page on public site
    public function how_it_works_agents()
    {
        return view("public_site.how_it_works_agents");
    }
    public function how_it_works_buyers()
    {
        return view("public_site.how_it_works_buyers");
    }
    public function plan_details()
    {
        $plans = Plans::all();
        return view('public_site.pricing', [
            'plans' => $plans,
        ]);
    }
    // terms and conditions page on public site
    public function refund_terms()
    {
        return view("public_site.refund_terms");
    }
    public function usage_terms()
    {
        return view("public_site.usage_terms");
    }

    public function update_token(Request $request)
    {
        $agent = session('agent');
        if (isset($agent) && !empty($agent)) {
            $agent = Agents::where('id', $agent['id'])->first();
            try {
                $agent->fcm_token = $request->token;
                $agent->save();
                return response()->json([
                    'success' => true,
                ]);
            } catch (\Exception $e) {
                report($e);
                return response()->json([
                    'success' => false
                ], 500);
            }
        }
    }

    public function notification(Request $request)
    {
        $firebaseToken = Agents::whereNotNull('fcm_token')->pluck('fcm_token')->first();
        $SERVER_API_KEY = env("FIREBASE_SERVER_KEY");

        $data = [
            "to" => $firebaseToken,
            "notification" => [
                "title" => $request->title,
                "body" => $request->body,
                "icon" => $request->icon,
            ]
        ];
        $dataString = json_encode($data);

        $headers = [
            'Authorization: key=' . $SERVER_API_KEY,
            'Content-Type: application/json',
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

        $response = curl_exec($ch);

        return ($response);
    }
}