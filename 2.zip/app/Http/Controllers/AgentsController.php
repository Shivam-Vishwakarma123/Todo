<?php

namespace App\Http\Controllers;

use App\Models\Agents;
use App\Models\Cities;
use App\Models\qr_logs;
use App\Models\Properties;
use App\Models\AgentContactRequests;
use App\Models\Otp_logs;
use App\Models\Agent_addresses;
use App\Models\States;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use App\Http\Controllers\Controller;

class AgentsController extends Controller
{
    // to show agents listing on public site
    public function listing(Request $request)
    {
        $order = $request->get('direction');
        if ($order == "")
            $order = "desc";

        $agents = Agents::where('active', '1')->orderBy('created_at', $order)->paginate(20);
        foreach ($agents as $agent) {
            $a = Properties::where([
                ['agent_id', $agent->id],
                ['published', '1'],
                ['active', '1']
            ])
                ->count();
            $agent["property_count"] = $a;
        }
        return view('public_site.agents_listing', compact('agents'));
    }

    // to show properties of a specific agent on click a agent card on public site
    public function properties(Request $request)
    {
        // request id is equal to agent id
        $agent_handle = $request->handle;

        // filter type
        if (isset($request->type) && !is_null($request->type)) {
            $type = $request->type;
        } else {
            $type = "All";
        }

        // getting the order
        $orderBy = $request->get("sort");

        $agent = Agents::where('handle', $agent_handle)->first();
        if ($agent == "") {
            return abort("404");
        }
        // to check either the link opened by scanning qr code or not
        if (isset($request->t) && trim($request->t) != "") {
            $qr_logs = new qr_logs;
            $qr_logs['agent_id'] = $agent->id;
            $qr_logs->save();
        }

        $orderValue = "publish_date";
        $order = "desc";
        if ($request->get('sort') != '') {
            $orderValue = $request->get("sort");
            $order = $request->get('direction');
            if ($orderValue == 'Price') {
                $orderValue = 'price';
            } else if ($orderValue = 'Popularity') {
                $orderValue = 'views';
            } else if ($orderValue == 'Recent') {
                $orderValue = 'publish_date';
            }
        }

        $propertie = Properties::where([
            ['agent_id', $agent->id],
            ['published', '1'],
            ['active', '1']
        ])
            ->with('city', 'state')
            ->orderBy($orderValue, $order);
        if ($type !== "All")
            $propertie = $propertie->where('sale_rent', '=', $type);

        $agent["city_name"] = "";
        $agent["address"] = "";
        $agent["state_name"] = "";

        $agent_address = Agent_addresses::where('agent_id', '=', $agent->id);
        if ($agent_address->count() > 0) {
            $agent_address = $agent_address->first();
            $agent["address"] = $agent_address->address;
            $agent["state_name"] = States::where("id", $agent_address->state_id)->first()->name;
            $city_name = Cities::where("id", $agent_address->city_id);
            if ($city_name->count() > 0) {
                $city_name = $city_name->first();
                $agent["city_name"] = $city_name->name;
            }
        }

        $count = $propertie->count();
        $propertie = $propertie->paginate(16);
        return view('public_site.agent_properties', compact('propertie', 'agent', 'type', 'count'));
    }

    // to send email to agents  when a user fill contact form on property description page code starts
    public function send_contact_mail(Request $request)
    {
        $property = $request->property;
        // fetch property details from unique url1
        $propertie = Properties::select("agent_id", "id")->where("unique_url", '=', $property)->get()->first();
        if (!is_null($propertie)) {
            // get agents details if agent id recieved from properties table
            $agent = Agents::find($propertie->agent_id);


            // saving data in agent_contact_request table for showing contact requests to the agent
            $agent_contact_request = new AgentContactRequests;
            $agent_contact_request->property_id = $propertie->id;
            $agent_contact_request->agent_id = $propertie->agent_id;
            $agent_contact_request->user_name = $request->name;
            $agent_contact_request->user_email = $request->userEmail;
            $agent_contact_request->user_phone = $request->phone;
            $agent_contact_request->user_message = $request->message;

            //Process to generate rare almost unique string
            $str = strtolower(date("His") . substr($request->name, 0, 1) . substr($request->phone, 0, 1) . substr($request->phone, -2) . substr($request->name, -1));
            $agent_contact_request->hash = $str;

            if ($agent_contact_request->save()) {

                // send email if it's not a dummy record
                if (intval($agent->dummy_record) != 1) {
                    // sending email and sms to the agent if agent email exists

                    if ($agent->email != "") {
                        $user['name'] = $request->name;
                        $user['phone'] = $request->phone;
                        $user['message'] = $request->message;
                        $user['email'] = $request->userEmail;
                        $user['agent_email'] = $agent->email;
                        $user['agent_name'] = $agent->first_name . " " . $agent->last_name;
                        $user['property_url'] = $property;

                        Mail::send(
                            'Agent/agents/sendContactMail',
                            ['user' => $user],
                            function ($m) use ($user) {
                                $m->from('feedback@orderly.in', 'Property Shops');
                                $m->to($user['agent_email'], $user['agent_name']);
                                $m->subject('Contact Requested On Property Shops');
                            }
                        );
                    }

                    // sending sms to the agent when user submits the contact form
                    $phone = $agent->phone;
                    $value = $agent_contact_request->hash . "";
                    $this->smsRequest("157142", $value, $phone);
                }

                // sending email even if the agent email doesn't exist
                Mail::send(
                    'Agent/agents/sendContactMail',
                    ['user' => $user],
                    function ($m) {
                        $m->from('feedback@orderly.in', 'Property Shops');
                        $m->to("cs@propertyshops.in", "propertyshops.in");
                        $m->subject('Contact Requested On Property Shops');
                    }
                );
                echo "success";
            } else {
                echo "failed";
            }


        } else {
            // return failed response if no such property url found in properties table
            echo "failed";
        }

    }
    // to send email to agents  when a user fill contact form on property description page code ends

    // to send otp on agent mobile number using ajax request
    public function send_otp(Request $request)
    {
        $phone = trim($request->phone);
        $otp_sent = false;

        if ($phone != "") {
            $value = rand(1000, 9999);

            // For dummy records
            $dummy_agent = Agents::where("phone", "=", $phone)->get();
            if($dummy_agent->count() == 0) {
                $dummy_agent_flag = 0;
            } else {
                $dummy_agent_flag = $dummy_agent->first()->dummy_record;
            }

            //Send SMS to User
            if ($_SERVER["SERVER_NAME"] != "localhost" && strpos($_SERVER["SERVER_NAME"], "192.168") === false && $dummy_agent_flag != 1) {

                $status = $this->smsRequest("154647", $value, $phone);

                if ($status == true) {
                    $otp_sent = true;
                }
            } else {
                if ($dummy_agent_flag == 1) {
                    $value = "6789";
                } else {
                    $value = "1234";
                }
                $otp_sent = true;
            }

            // Storing otp value in database
            $otp = new Otp_logs;
            $otp->mobile = $request->phone;
            $otp->otp = $value;
        }

        if ($otp_sent == true && $otp->save()) {
            return "success";
        } else {
            return "error";
        }
    }




    //Verify OTP number and mobile number combination
    public function verify_otp(Request $request)
    {
        // agents entered otp
        $otp = $request->otp;
        $phone = $request->phone;

        $data['agent_status'] = "0";
        $data["agent_active"] = 1;
        $data['message'] = "failed";

        $newTime = date('Y-m-d H:i:s', strtotime('-10 minutes'));

        $otp_values = Otp_logs::where([
            ['mobile', $phone],
            ['otp', $otp],
            ['created_at', '>', $newTime]
        ])->get();

        if ($otp_values->count() > 0) {

            $agent = Agents::where('phone', $phone);

            if ($agent->count() == 0) {
                $request->session()->put('phone', $phone);
            } else {
                // if agents already registered
                $data['agent_status'] = 1;

                $agent = $agent->first();

                if($agent->active == 0){
                   $data["agent_active"] = 0; 
                   return $data;
                }

                //Prepare data to save in array
                $tmp = [];
                $tmp["id"] = $agent->id;
                $tmp["first_name"] = $agent->first_name;
                $tmp["last_name"] = $agent->last_name;
                $tmp["phone"] = $agent->phone;
                $tmp["handle"] = $agent->handle;
                $tmp["credit_balance"] = $agent->credit_balance;

                Cookie::queue('agent', json_encode($tmp), 43200);
                session(['agent' => $tmp]);
            }

            // delete the otps of that number
            Otp_logs::where('mobile', $phone)->delete();
            $data['message'] = "success";
        }
        return $data;
    }


    public function verify_contact_otp(Request $request)
    {
        // agents entered otp
        $otp = $request->otp;
        $phone = $request->phone;
        $data['message'] = "failed";

        $newTime = date('Y-m-d H:i:s', strtotime('-10 minutes'));
        $otp_values = Otp_logs::where([
            ['mobile', $phone],
            ['otp', $otp],
            ['created_at', '>', $newTime]
        ])->get();

        if ($otp_values->count() > 0) {
            // delete the otps of that number
            Otp_logs::where('mobile', $phone)->delete();
            $data['message'] = "success";
        }
        return $data;
    }

}
