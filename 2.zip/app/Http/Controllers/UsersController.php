<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Otp_logs;
use App\Models\Agents;
use App\Models\User;
use Illuminate\Support\Facades\Cookie;

class UsersController extends Controller
{
    // to send otp on user mobile number using ajax request
    public function user_send_otp(Request $request)
    {
        $phone = trim($request->user_phone);
        // return $phone;
        $otp_sent = false;

        if ($phone != "") {
            $value = rand(1000, 9999);

            // For dummy records
            $dummy_user = User::where("phone", "=", $phone)->get();
            if ($dummy_user->count() == 0) {
                $dummy_user_flag = 0;
            } else {
                $dummy_user_flag = $dummy_user->first()->dummy_record;
            }

            //Send SMS to User
            if ($_SERVER["SERVER_NAME"] != "localhost" && strpos($_SERVER["SERVER_NAME"], "192.168") === false && $dummy_user_flag != 1) {

                $status = $this->smsRequest("154647", $value, $phone);

                if ($status == true) {
                    $otp_sent = true;
                }
            } else {
                if ($dummy_user_flag == 1) {
                    $value = "6789";
                } else {
                    $value = "1234";
                }
                $otp_sent = true;
            }

            // Storing otp value in database
            $otp = new Otp_logs;
            $otp->mobile = $request->user_phone;
            $otp->otp = $value;
        }

        if ($otp_sent == true && $otp->save()) {
            return "success";
        } else {
            return "error";
        }
    }

    //Verify OTP number and mobile number combination
    public function verify_otp(Request $request)
    {
        // users entered otp
        $otp = $request->user_otp;
        $phone = $request->user_phone;

        $data['user_status'] = "0";
        $data["user_active"] = 1;
        $data['message'] = "failed";

        $newTime = date('Y-m-d H:i:s', strtotime('-10 minutes'));

        $otp_values = Otp_logs::where([
            ['mobile', $phone],
            ['otp', $otp],
            ['created_at', '>', $newTime]
        ])->get();

        if ($otp_values->count() > 0) {

            $user = User::where('phone', $phone);

            if ($user->count() == 0) {
                $request->session()->put('phone', $phone);
            } else {
                // if users already registered
                $data['user_status'] = 1;

                $user = $user->first();

                if ($user->active == 0) {
                    $data["user_active"] = 0;
                    return $data;
                }
            }

            //Prepare data to save in array
            $tmp = [];
            $tmp["id"] = $user->id;
            $tmp["name"] = $user->name;
            $tmp["phone"] = $user->phone;

            Cookie::queue('user', json_encode($tmp), 43200);
            session(['user' => $tmp]);
            // delete the otps of that number
            Otp_logs::where('mobile', $phone)->delete();
            $data['message'] = "success";
        }
        return $data;
    }

    public function user_sign_up(Request $request)
    {
        $phone = session('phone');

        if ($request->isMethod('post')) {
            $request->validate([
                'user_name' => 'required',
            ]);

            $user = new User;
            $user->name = trim($request['user_name']);
            $user->phone = $phone;
            if ($user->save()) {
                $request->session()->forget('phone');
                return redirect('/');
            } else {
                return view('user/user_sign_up', compact('phone'));
            }
        } else {
            return view('user/user_sign_up', compact('phone'));
        }
    }
}
