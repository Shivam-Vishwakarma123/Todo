<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\SmsLogs;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    // to convert numeric digits to words code starts
    public static function convertToWords($num) {
        $result = "";
        $numbers10 = array('ten','twenty','thirty','fourty','fifty','sixty','seventy','eighty','ninety');
        $numbers01 = array('one','two','three','four','five','six','seven','eight','nine','ten',
            'eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen');
        if($num == 0) {
            $result = "zero";
        }
        if($num >= 20000) {
            $thousands = floor($num/10000);
            if($thousands != 0) {
                $result .= $numbers10[$thousands-1] . " ";
                $num -= $thousands*10000;
            }
        }       
        $thousands = floor($num/1000);
        if($thousands != 0) {
            $result .= $numbers01[$thousands-1] . " thousand ";
            $num -= $thousands*1000;
        } else {
            if($result != "" ) $result .= " thousand ";
        }
        $hundreds = floor($num/100);
        if($hundreds != 0) {
            $result .=  $numbers01[$hundreds-1] . " hundred ";
            $num -= $hundreds*100;
        }
        if($num < 20) {
            if($num != 0) {
                $result .= $numbers01[$num-1];
            }
        } else {
            $tens = floor($num/10);
            $result .= $numbers10[$tens-1] . " ";
            $num -= $tens*10;

            if($num != 0) {
                $result .=  $numbers01[$num-1];
                $num -= floor($num);
            }
        }
        if($num > 0) {
            $num = round($num,2);

            //now process decimals
            $result .= " and ";

            $num = floor($num * 100);
            if($num < 20) {
                if($num != 0) {
                    $result .= $numbers01[$num-1];
                }
            } else {
                $tens = floor($num/10);
                $result .= $numbers10[$tens-1] . " ";
                $num -= $tens*10;

                if($num != 0) {
                    $result .=  $numbers01[$num-1];
                    $num -= floor($num);
                }
            }
            $result .= " paise";
        }
        $result = strtoupper($result);
        return $result . " ONLY";
        // to convert numeric digits to words code ends
    }

    function smsRequest($message_id, $values, $mobile)
    {
        $fastsms_key = "COLA1SZWUIbvMPHtFEYfgB7G5jol3QmcK06V2Dh8paTx4euwkXH6eKFaOZEyMWbnrTIJXu3oxv0PLzig";

        $url = "https://www.fast2sms.com/dev/bulkV2?authorization=" . $fastsms_key . "&route=dlt&sender_id=NRVTPS&message=" . $message_id . "&variables_values=" . urlencode($values) . "&flash=0&numbers=" . urlencode($mobile);
        $response = file_get_contents($url);
        $status = json_decode($response);
        
        $return_status = false;
        
        if ($status->return === true || $status->return === "true") {
            $return_status = true;
        } else {
            $return_status = false;
        }

        $smsLog = new SmsLogs();
        $smsLog->sender_id = "NRVTPS";
        $smsLog->message_id = $message_id;
        $smsLog->variables = $values;
        $smsLog->mobile = $mobile;
        $smsLog->status = ($return_status == true) ? 1 : 0;
        $smsLog->save();

        return $return_status;

    }
}
