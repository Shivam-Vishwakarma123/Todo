<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Cities;
use App\Models\States;

class Statecitydropdown extends Component
{
    public $states, $cities,$unique_url;
    public $is_state = false;
    public $is_city = false;
    public $state_id = 0;
    public $city_id = 0;
    public function mount(){
        $propertie = session('property');
        if(isset($propertie))
        {
            $this->is_state = States::where('id','=',$propertie->state_id)->first();
            $this->unique_url = $propertie->unique_url;
            if($propertie->city_id != 0)
            {
                $this->is_city = Cities::where('id','=',$propertie->city_id)->first();
                $this->cities = Cities::orderby('name','asc')->select('*')->where('state_id',$propertie->state_id)->get();
            }
        }
        $this->states = States::orderby('name','asc')->select("*")->get();  

    }

    protected $listeners = [
        'getStateCities'
     ];
    // Fetch cities of a state
    public function render()
    {
        return view('livewire.statecitydropdown');
    }
    public function getStateCities($value){

        $this->cities = Cities::orderby('name','asc')->select('*')->where('state_id',$value)->get();
        // Reset value 
        $this->city_id = 0;
    }
}