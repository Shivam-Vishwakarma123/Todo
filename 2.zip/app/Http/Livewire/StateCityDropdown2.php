<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Cities;
use App\Models\States;
use App\Models\Agent_addresses;

class Statecitydropdown2 extends Component
{
    public $states, $cities,$unique_url;
    public $is_state = false;
    public $is_city = false;
    public $state_id = 0;
    public $city_id = 0;
    public function mount(){
        $agent = session('agent');
        $agent = Agent_addresses::where('agent_id', '=', $agent["id"])->first();
        if(isset($agent))
        {
            $this->is_state = States::where('id','=',$agent->state_id)->first();
            $this->unique_url = $agent->unique_url;
            if($agent->city_id != 0)
            {
                $this->is_city = Cities::where('id','=',$agent->city_id)->first();
                $this->cities = Cities::orderby('name','asc')->select('*')->where('state_id',$agent->state_id)->get();
            }
        }
        $this->states = States::orderby('name','asc')->select("*")->get();  

    }

    protected $listeners = [
        'getStateCities'
     ];
    // Fetch cities of a state
    public function render()
    {
        return view('livewire.state-city-dropdown2');
    }
    public function getStateCities($value){

        $this->cities = Cities::orderby('name','asc')->select('*')->where('state_id',$value)->get();
        // Reset value 
        $this->city_id = 0;
    }
}