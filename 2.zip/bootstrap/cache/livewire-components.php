<?php return array (
  'statecitydropdown2' => 'App\\Http\\Livewire\\StateCityDropdown2',
  'statecitydropdown' => 'App\\Http\\Livewire\\Statecitydropdown',
);