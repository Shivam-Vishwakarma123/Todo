<?php

return [
    'api_keys' => [
        'secret_key' => env('sk_test_51LqEz4SBGGnAQThwHAjoda7sdD2Csu4HKMzNyluBMwgIiWQf7sb9E2HckxpxE0ab06le91OfSqBdLIE7u4LjM1tZ002ei6xEAp', null)
    ]
];

?>