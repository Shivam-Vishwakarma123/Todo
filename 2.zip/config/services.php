<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'instamojo' => [
        'client_id'       => env('IM_CLIENT_ID'),
        'client_secret'    => env('IM_CLIENT_SECRET'),
        'username'         => env('IM_USERNAME'), /** In case of user based authentication**/
        'password'         => env('IM_PASSWORD'), /** In case of user based authentication**/ 
        'auth_type'        => env('IM_AUTH_TYPE'), /** app or user**/ 
    ],

    // 'instamojo' => [
    //     'client_id'       => env('0566b93f2a01e6a16405a53e65585cdb'),
    //     'client_secret'    => env('58fe81b6eb2643058bed5e58d223c559'),
    //     'auth_type'        => env('app'), /** app or user**/ 
    // ],

];
