<?php

return [

    'authentication_key' => env("FIREBASE_SERVER_KEY")

];
