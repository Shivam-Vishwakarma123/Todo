<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePropertiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('properties', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('agent_id')->nullable();
            $table->foreign('agent_id')->references('id')->on('agents');
            $table->text('description')->nullable();
            $table->string('unique_url', 50);
            $table->string('address_line_1', 100);
            $table->integer('price',false,11);
            $table->string('address_line_2', 255);
            $table->string('city', 50);
            $table->string('state', 50);
            $table->string('zip', 50);
            $table->tinyInteger('levels',false,5);
            $table->string('matterport_data', 100);
            $table->date('publish_date')->nullable();
            $table->boolean('published')->default(0);
            $table->boolean('reviewed');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('properties');
    }
}
