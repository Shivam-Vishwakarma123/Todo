<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->integer('agent_id');
            $table->integer('plan_id');
            $table->date('payment_date');
            $table->integer('payment_id');
            $table->decimal('amount', 5, 2);
            $table->decimal('gateway_fees', 5, 2);
            $table->string('currency', 10);
            $table->text('other');
            $table->enum('status', array('Pending', 'Paid','Failed'));
            $table->boolean('active')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
