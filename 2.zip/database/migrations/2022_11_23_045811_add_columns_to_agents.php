<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsToAgents extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('agents', function (Blueprint $table) {
            // $table->bigInteger('featured_image',false)->default(0)->after('logo_image');
            $table->string('facebook_profile', 255)->default(0)->after('logo_image');
            $table->string('instagram_profile', 255)->default(0)->after('facebook_profile');
            $table->string('twitter_profile', 255)->default(0)->after('instagram_profile');
            $table->string('linkedin_profile', 255)->default(0)->after('twitter_profile');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('agents', function (Blueprint $table) {
            //
        });
    }
}
