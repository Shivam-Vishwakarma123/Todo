
// delete backend agent data
$(document).on("click", '.delete_agent', function (event)
{
    if(confirm("Do you really want to delete this agent details ? "))
    {
        var id = this.id;
        $.ajax({
            type: 'GET',
            url: web_url + "/backend/delete",
            data:{Id:id},
            success: function (data) {
                if(data.success==0){
                    showPopUp('error' , data.message);
                } else {
                    $('#agent_data'+id).remove();
                    showPopUp('success' , data.message);
                }      
            }
        })
    }
    else{
        return false;
    }
});
// enable or disable property from admin panel
$(document).on("click", '.save_publish', function (event) {
    var request = null;
    event.preventDefault();
    $var = $(this);
    var id = this.id;

    if(confirm("Do you really want to change status ?"))
    {
        $request = $.ajax({
            type: 'GET',
            url: web_url  + "/backend/property-status",
            data:{id:id},
            success: function (data) {
                var stat_us;
                if (data['message'] == "1") {
                    if (data['status'] == 1) {
                        stat_us = 'ENABLE';
                        showPopUp('success' , 'Property Enabled');
                    } else {
                        stat_us = 'DISABLE';
                        showPopUp('success' , 'Property Disabled');
                    }
                } else {
                    showPopUp('error' , 'Error');
                }
                $var.text(stat_us);
            },
            // kill old request before initiating new requests
            beforeSend: function () {
            if (request !== null) {
                request.abort();
            }
        }
        })
    }
    else{
        return false;
    }
});
// Here Admin can Update all agent active/inactive status 
$(document).on("click", '.save_status', function (event) {
    if(confirm('Do you really want to update this record?'))
    {
        event.preventDefault();
        $var = $(this);
        var id = event.target.id;
        var value = event.target.innerText;
        $.ajax({
            type: 'GET',
            url: web_url + "/backend/status",
            data:{id:id,value:value},

            success: function (data) {
                var stat_us;
                if (data['messege'] == "1") {
                    if (data['status'] == 1) {
                        stat_us = 'ENABLE';
                        showPopUp('success' , 'USER Enabled');
                    } else {
                        stat_us = 'DISABLE';
                        showPopUp('success' , 'USER Disabled');
                    }
                } else {
                    showPopUp('error' , 'Error');
                }
                $var.text(stat_us);
            }
        })
    }
    else{
        return false;
    }
});       


// Here Add Code For Member Ship Status Enable Or Disable
$(document).on("click",'.plan_status', function (event) {
    event.preventDefault();
    $var = $(this);
    var id = this.id;
    var value = event.target.innerText;
    if(confirm("Do you really want to update recoord ?"))
    {
        $.ajax({
            type: 'GET',
            url: web_url + "/backend/plans/status",
            data:{id:id,value:value},

            success: function (data) {
                var stat_us;
                if (data['messege'] == "1") {
                    if (data['status'] == 1) {
                        stat_us = 'ENABLE';
                        showPopUp('success' , 'PLAN ENABLE');
                    } else {
                        stat_us = 'DISABLE';
                        showPopUp('success' , 'PLAN DISABLE');
                    }
                } else {
                    showPopUp('error' , 'Error');
                }
                $var.text(stat_us);
            }
        })
    }
    else{
        return false;
    }
});

// Here Add Code For deleting Existing Membership Plans
$(document).on("click",'.delete-plan', function (event) {
    event.preventDefault();
    $var = $(this);
    var id = this.id;
    if(confirm("Do You really want to delet plan ?"))
    {
        $.ajax({
            type: 'GET',
            url: web_url + "/backend/plans/delete/"+id,

            success: function (data) {
                console.log(data)
                if (data['success'] == "1") {
                    $('#tab_row'+id).remove();
                    showPopUp('success' , data.message);
                } else {
                    showPopUp('error' , data.message);
                }
            }
        })
    }
    else
    {
        return false;
    }
});

// Here Add Code For deleting Blogs
$(document).on("click",'.delete-blog', function (event) {
    event.preventDefault();
    $var = $(this);
    var slug = this.id;
    if(confirm("Do You really want to delete Blog ?"))
    {
        $.ajax({
            type: 'GET',
            url: web_url + "/backend/blogs/delete/"+slug,

            success: function (data) {
                console.log(data)
                if (data['success'] == "1") {
                    $('#tab_row'+slug).remove();
                    showPopUp('success' , data.message);
                } else {
                    showPopUp('error' , data.message);
                }
            }
        })
    }
    else
    {
        return false;
    }
});

// Publishing blog
$(document).on("click", '.publish_blog', function (event) {
    var request = null;
    event.preventDefault();
    $var = $(this);
    var slug = this.id;

    if(confirm("Do you really want to change status ?"))
    {
        $request = $.ajax({
            type: 'GET',
            url: web_url  + "/backend/blogs/publish",
            data:{slug:slug},
            success: function (data) {
                var stat_us;
                if (data['message'] == "1") {
                    if (data['status'] == 1) {
                        stat_us = 'Published';
                        showPopUp('success' , 'Blog Published');
                        $var.css("color", "Blue");
                    } else {
                        stat_us = 'Not Published';
                        showPopUp('success' , 'Blog Not Published');
                        $var.css("color", "red");
                    }
                } else {
                    showPopUp('error' , 'Error');
                }
                $var.text(stat_us);
            },
            // kill old request before initiating new requests
            beforeSend: function () {
            if (request !== null) {
                request.abort();
            }
        }
        })
    }
    else{
        return false;
    }
});
// DataTables
new DataTable('#backend-table');