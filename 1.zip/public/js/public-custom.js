$(document).ready(function (e) {
    // live handler
    if (typeof lc_lightbox !== "undefined") {
        lc_lightbox(".elem", {
            wrap_class: "lcl_fade_oc",
            gallery: true,
            thumb_attr: "data-lcl-thumb",

            skin: "minimal",
            radius: 0,
            padding: 0,
            border_w: 0,
        });
    }
});

$(document).on("keypress", "#phone", function (event) {
    if (event.keyCode == 13) {
        $("#validateMobile").trigger("click");
    }
});

// js to validate agents phone number by sending otp starts
$(document).on("click", "#validateMobile, #resendOtp", function () {
    // hide countdown and resend otp button and change otp input box value to blank
    $("#otp").val("");
    $(".countdown").html("03:01");
    $(".countdown").hide();
    $("#resendOtp").hide();
    var phone = $("#phone").val().trim();

    if (phone.length == 10 && !isNaN(phone)) {
        $("#validateMobile").hide();
        $(".form_loader").show();
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            type: "get",
            url: web_url + "/agent/send-otp",
            data: { phone: phone },
            success: function (data) {
                if (data == "success") {
                    $(".form_loader").hide();
                    $("#otp_section").show();
                    $(".countdown").show();

                    showPopUp("success", "Otp send successfully");

                    // countdown time1 set to enable resend otp button after 3 minutes countdown ends
                    var time2 = "2:00";
                    var interval = setInterval(function () {
                        var time1 = time2.split(":");

                        //by parsing integer, I avoid all extra string processing
                        var minutes = parseInt(time1[0], 10);
                        var seconds = parseInt(time1[1], 10);

                        --seconds;

                        minutes = seconds < 0 ? --minutes : minutes;
                        if (minutes < 0) clearInterval(interval);
                        seconds = seconds < 0 ? 59 : seconds;
                        seconds = seconds < 10 ? "0" + seconds : seconds;
                        //minutes = (minutes < 10) ?  minutes : minutes;
                        $(".countdown").html(minutes + ":" + seconds);
                        time2 = minutes + ":" + seconds;
                        // when countdown ends
                        if (minutes == "0" && seconds == "00") {
                            // show resend otp button and hide countdown
                            $(".countdown").hide();
                            $("#resendOtp").show();
                        }
                    }, 1000);

                    $("#otp_section input").focus();
                } else {
                    // if otp not sent
                    $(".form_loader").hide();
                    $("#validateMobile").show();

                    showPopUp("error", "Erorr sending OTP. Please try again.");
                }
            },
        });
    } else {
        // if phone number length is not equal to 10
        showPopUp(
            "error",
            "Phone number should have 10 digits and only numeric characters allowed."
        );
        return false;
    }
});
// js to validate agents phone number by sending otp ends

// js to validate user phone number by sending otp starts
$(document).on("click", "#user_validateMobile, #user_resendOtp", function () {
    // hide countdown and resend otp button and change otp input box value to blank
    $("#user_otp").val("");
    $(".user_countdown").html("03:01");
    $(".user_countdown").hide();
    $("#user_resendOtp").hide();
    var user_phone = $("#user_phone").val().trim();

    if (user_phone.length == 10 && !isNaN(user_phone)) {
        $("#user_validateMobile").hide();
        $(".user_form_loader").show();
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            type: "get",
            url: web_url + "/user/user-send-otp",
            data: { user_phone: user_phone },
            success: function (data) {
                if (data == "success") {
                    $(".user_form_loader").hide();
                    $("#user_otp_section").show();
                    $(".user_countdown").show();

                    showPopUp("success", "Otp send successfully");

                    // countdown time1 set to enable resend otp button after 3 minutes countdown ends
                    var time2 = "2:00";
                    var interval = setInterval(function () {
                        var time1 = time2.split(":");

                        //by parsing integer, I avoid all extra string processing
                        var minutes = parseInt(time1[0], 10);
                        var seconds = parseInt(time1[1], 10);

                        --seconds;

                        minutes = seconds < 0 ? --minutes : minutes;
                        if (minutes < 0) clearInterval(interval);
                        seconds = seconds < 0 ? 59 : seconds;
                        seconds = seconds < 10 ? "0" + seconds : seconds;
                        //minutes = (minutes < 10) ?  minutes : minutes;
                        $(".user_countdown").html(minutes + ":" + seconds);
                        time2 = minutes + ":" + seconds;
                        // when countdown ends
                        if (minutes == "0" && seconds == "00") {
                            // show resend otp button and hide countdown
                            $(".user_countdown").hide();
                            $("#user_resendOtp").show();
                        }
                    }, 1000);

                    $("#user_otp_section input").focus();
                } else {
                    // if otp not sent
                    $(".user_form_loader").hide();
                    $("#user_validateMobile").show();

                    showPopUp("error", "Erorr sending OTP. Please try again.");
                }
            },
        });
    } else {
        // if phone number length is not equal to 10
        showPopUp(
            "error",
            "User Phone number should have 10 digits and only numeric characters allowed."
        );
        return false;
    }
});
// js to validate user phone number by sending otp ends

// js to validate agents otp
$(document).on("keyup", "#otp", function () {
    var otp = $("#otp").val().trim();
    if (isNaN(otp)) {
        showPopUp("error", "Only numeric characters allowed!!!");
        return false;
    }
    if (otp.length == 4) {
        var phone = $("#phone").val().trim();
        // to redirect agent after successfull validate phone number
        redirect = web_url + "/agent/sign-up";
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            type: "get",
            url: web_url + "/agent/verify-otp",
            data: { otp: otp, phone: phone },
            success: function (data) {
                // if agent is not active
                if (data["agent_active"] == 0) {
                    showPopUp(
                        "error",
                        "You are Disbaled By admin Please Contact cs@propertyshops.in"
                    );
                } else if (data["message"] == "success") {
                    if (data["agent_status"] == 1) {
                        // if agent already sign up then redirect to agent dashboard
                        redirect = web_url + "/agent/dashboard";
                    }
                    // else redirect to sign up page
                    window.location.href = redirect;
                } else {
                    showPopUp("error", "OTP not matched");
                }
            },
        });
    }
});

// js to validate users otp
$(document).on("keyup", "#user_otp", function () {
    var user_otp = $("#user_otp").val().trim();
    if (isNaN(user_otp)) {
        showPopUp("error", "Only numeric characters allowed!!!");
        return false;
    }
    if (user_otp.length == 4) {
        var user_phone = $("#user_phone").val().trim();
        // to redirect user after successfull validate phone number
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            type: "get",
            url: web_url + "/user/verify-otp",
            data: { user_otp: user_otp, user_phone: user_phone },
            success: function (data) {
                // if user is not active
                if (data["user_active"] == 0) {
                    showPopUp(
                        "error",
                        "You are Disbaled By admin Please Contact cs@propertyshops.in"
                    );
                } else if (data["message"] == "success") {
                    if (data["user_status"] == 1) {
                        // if user already sign up then redirect to Home Page
                        window.location.href = web_url + "/";
                    } else {
                        // else redirect to sign up page
                        window.location.href = web_url + "/user/user-sign-up";
                    }
                } else {
                    showPopUp("error", "OTP not matched");
                }
            },
        });
    }
});

// js to set unique handles to agents on sign up page starts
$(document).on("change", "#first_name , #last_name", function () {
    var first_name = $("#first_name").val().trim();
    var last_name = $("#last_name").val().trim();
    unique_handle = first_name.substring(0, 2) + last_name.substring(0, 2);
    if (unique_handle.length > 0) {
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            type: "get",
            url: "get-unique-handle",
            data: { unique_handle: unique_handle },
            success: function (data) {
                $("#unique_handle").val(data);
                $("#isUnique").val("1");
            },
        });
    }
});

// js to send mail through ajax and change contact form layout on property description page starts
function contactFormSubmit() {
    var property_url = $("#property_url").val().trim();
    var user_email = $("#contact_email").val().trim();
    var user_name = $("#contact_name").val().trim();
    var user_phone = $("#contact_phone").val().trim();
    var user_message = $("#contact_message").val().trim();
    var is_varified = $(".status").val().trim();

    // checks to validate data starts
    if (user_name == "" || user_phone == "" || user_message == "") {
        $(".form-message").html(
            '<span class="text-red-600">All fields required except email address.</span>'
        );
        $(".form-message").show();
        return false;
    }
    if (isNaN(user_phone) || user_phone.length != 10) {
        $(".form-message").html(
            '<span class="text-red-600">Mobile number format not correct.</span>'
        );
        $(".form-message").show();
        return false;
    }
    if (is_varified == 0) {
        $(".form-message").html(
            '<span class="text-red-600">Please verify phone number to send the request. It will only be used by the Agent to contact you.</span>'
        );
        $(".form-message").show();
        return false;
    }
    // checks to validate data ends
    // send ajax request code starts
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
        },
    });
    $(".contactFormSubmit").hide();
    $(".form_loader").show();

    $.ajax({
        type: "POST",
        url: "agents/send-contact-mail",
        data: {
            name: user_name,
            phone: user_phone,
            message: user_message,
            property: property_url,
            userEmail: user_email,
        },
        success: function (data) {
            if (data == "success") {
                // if mail sent then hide form and show a success message only
                $("#myform").hide();
                $(".form-message").html(
                    '<span class="text-green-600">Form Submitted Successfully. Agent Will Contact You Soon</span>'
                );
                $(".form-message").show();
                $(".form_loader").hide();
            } else {
                // if mail not sent then show form and show error message also
                $(".contactFormSubmit").show();
                $(".form_loader").hide();
                $(".form-message").html(
                    '<span class="text-red-600">Error sending request. Please try again.</span>'
                );
                $(".form-message").show();
            }
            $.ajax({
                //Seconds Request
                url: "send-notification",
                type: "Post",
                data: {
                    title: "PropertyShops",
                    body: "User is interested in your property. Check your contact requests.",
                    icon: "https://stage.nirvaat.com/PropertyShops/public/images/ps-logo.png",
                },
                cache: false,
                success: function (returnhtml) {
                    // $("#duplicate").html(returnhtml);
                    // $("#loadingimg").hide();
                    alert("b");
                },
            });
        },
    });
    // send ajax request code ends
}
// js to send mail through ajax and change contact form layout on property description page ends

// navbar js
const burgerMenu = document.getElementById("burger");
const navbarMenu = document.getElementById("menu");

// Show and Hide Navbar Menu
$("#burger").click(() => {
    burgerMenu.classList.toggle("is-active");
    navbarMenu.classList.toggle("is-active");

    if (navbarMenu.classList.contains("is-active")) {
        navbarMenu.style.maxHeight = 100 + "vh";
    } else {
        navbarMenu.removeAttribute("style");
    }
});
