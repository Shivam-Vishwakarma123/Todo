<?php
    header("Access-Control-Allow-Origin: *");
    $inputJSON = file_get_contents('php://input');
    $inputJSON = json_decode($inputJSON,true);
    $file = fopen('data.txt', 'a+');
    if ($inputJSON['data']['payment']['payment_status']=='SUCCESS') {
        $status  = 'Paid';
    }
    if ($inputJSON['data']['payment']['payment_status']=='FAILED') {
        $status  = 'Pending';
    }
    $amount = $inputJSON['data']['payment']['payment_amount'];
    $payment_id =$inputJSON['data']['order']['order_id'];
    $currency = $inputJSON['data']['payment']['payment_currency'];
    $servername = "localhost";
    $username = "stagedbu";
    $password = "QM)@kYGRN2Sq!4f8";
    $dbname = "propertyshops_dev";

    
    $conn = new mysqli($servername, $username, $password, $dbname);
    

    $sql = "UPDATE payments SET status=$status,amount=$amount,currency=$currency WHERE payment_id= $payment_id";
    // if ($conn->query($sql) === TRUE) {
    //     echo "Record updated successfully";
    //   } else {
    //     echo "Error updating record";
    //   }
    fwrite($file, print_r($sql, true));
    fclose($file);
    $conn->close();
    die;
     
?>

