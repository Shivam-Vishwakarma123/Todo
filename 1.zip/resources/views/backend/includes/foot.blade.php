<script src="{{ url('js/tailwind.min.js') }}"></script>

<!-- DropDown Css -->
<script src="{{url('js/fontawesome.min.js')}}"></script>

<!-- material-tailwind.js -->
<script src="{{url('js/flowbite.min.js')}}"></script>

<!-- function js -->
<script src="{{url('js/functions.js')}}?t=123"></script>

<!-- CUSTOM JS -->
<script src="{{url('js/custom.js')}}?t=123"></script>

<script src="{{url('js/backend/custom.js')}}?t=123"></script>