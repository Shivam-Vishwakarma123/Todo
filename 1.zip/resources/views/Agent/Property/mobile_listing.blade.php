@extends('layouts.agents.agent')
@section('title', 'Manage Properties')

@section('content')
<div class="mt-6">

    @if (count($properties) > 0)
    @foreach($properties as $property)
    <x-mobile-view-property-card :property="$property"  ></x-mobile-view-property-card>
    @endforeach
    <div class="m-4 text-center">
        {!! $properties->render() !!}
    </div>
    @endif
</div>
@stop
