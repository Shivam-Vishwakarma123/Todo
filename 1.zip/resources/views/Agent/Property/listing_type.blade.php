@extends('layouts.agents.agent')
@section('title', 'ListingType')

@section('content')
@php
if(isset($property)){
$property_listing_type = $property->sale_rent;
$property_type = $property->property_type;
$property_condition = $property->property_condition;
$property_age = $property->property_age;
$rera_approved = $property->rera_approved;
$bank_loan = $property->bank_loan;
$booking_amount = $property->sale_booking_amount;
}
else{
$id = '';
$property_listing_type = old('property_listing_type');
$property_type = old('property_type');
$property_condition = old('property_condition');
$property_age = old('property_age');
$rera_approved =old('rera_approved');
$bank_loan = old('bank_loan');
$booking_amount = old('booking_amount');
}
@endphp

<div class="w-full rounded overflow-hidden">
    <form action="{{url('/agent/property/store-listingType')}}" id="amenitesForm" method="post">

        <div class="grid gap-2 mb-6 ">
            <h2 class="text-3xl font-bold  my-4">Listing Type</h2>
            <br>
            <div class="w-full">
                <div class="flex gap-4">
                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded w-full">
                        <input {{($property_listing_type == "Sale")?"checked":''}} id="sale" type="radio" value="Sale" name="sale_rent" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 cursor-pointer">
                        <label for="sale" class="cursor-pointer w-full py-4 ml-2 text-sm font-medium text-gray-900 ">For Sale</label>
                    </div>
                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded  w-full">
                        <input {{($property_listing_type == "Rent")?"checked":''}} id="rent" type="radio" value="Rent" name="sale_rent" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 cursor-pointer">
                        <label for="rent" class="w-full py-4 ml-2 text-sm font-medium text-gray-900  cursor-pointer">For Rent</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="mb-6">
            @csrf
            <div class="w-full">
                <h2 class="text-3xl font-bold ">Property Status</h2>
                <div class="grid grid-gap-6 grid-cols-3 price-feature-grid">
                    <div class="p-5 bg-grey-100">
                        <div class="input-group input-group-outline">
                            <span>Property Type :</span>
                            <br>
                            <div class="w-full mt-4">
                                <div class="flex flex-wrap gap-4">
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded w-full">
                                        <input {{($property_type == "Independent House")?"checked":''}} id="property_type_i" type="radio" value="Independent House" name="property_type" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer">
                                        <label for="property_type_i" class="cursor-pointer w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Independent House</label>
                                    </div>
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded  w-full">
                                        <input {{($property_type == "Apartment")?"checked":''}} id="property_type_a" type="radio" value="Apartment" name="property_type" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer">
                                        <label for="property_type_a" class="w-full py-4 ml-2 text-sm font-medium text-gray-900 cursor-pointer">Apartment</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 bg-grey-100">
                        <div class="input-group input-group-outline">
                            <span>Property Condition :</span>
                            <div class="w-full mt-4">
                                <div class="flex flex-wrap gap-4">
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded  w-full">
                                        <input id="property_condition_n" type="radio" value="New" name="property_condition" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer"
                                         {{($property_condition == "New")?"checked":''}} >
                                        <label for="property_condition_n" class="cursor-pointer w-full py-4 ml-2 text-sm font-medium text-gray-900 ">New</label>
                                    </div>
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded  w-full">
                                        <input id="property_condition_r" type="radio" value="Old" name="property_condition" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer" 
                                        {{($property_condition == "Old")?"checked":''}}>
                                        <label for="property_condition_r" class="w-full py-4 ml-2 text-sm font-medium text-gray-900 cursor-pointer">Old</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 bg-grey-100">
                        <div class="input-group input-group-outline">
                            <span>Age of Property (in Years):</span>
                            <input type="number" id="property_age" style="border:2px solid lightgrey;"
                                placeholder="Enter here -----" name="property_age" value="{{ $property_age }}" max="100"
                                class="mt-4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                        </div>
                    </div>
                </div>
                <div class="grid grid-gap-6 grid-cols-3 price-feature-grid">
                    <div class="p-5 bg-grey-100">
                        <div class="input-group input-group-outline">
                            <span>Rera Approved :</span>
                            <br>
                            <div class="w-full mt-4">
                                <div class="flex flex-wrap gap-4">
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded w-full">
                                        <input {{($rera_approved == 1)?"checked":''}} id="rera_yes" type="radio" value="1" name="rera_approved" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer">
                                        <label for="rera_yes" class="cursor-pointer w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Yes</label>
                                    </div>
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded  w-full">
                                        <input {{($rera_approved == 0)?"checked":''}} id="rera_no" type="radio" value="0" name="rera_approved" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer">
                                        <label for="rera_no" class="w-full py-4 ml-2 text-sm font-medium text-gray-900 cursor-pointer">No</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 bg-grey-100">
                        <div class="input-group input-group-outline">
                            <span>Bank Loan Available :</span>
                            <div class="w-full mt-4">
                                <div class="flex flex-wrap gap-4">
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded  w-full">
                                        <input id="bank_loan_yes" type="radio" value="1" name="bank_loan" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer"
                                         {{($bank_loan == 1)?"checked":''}} >
                                        <label for="bank_loan_yes" class="cursor-pointer w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Yes</label>
                                    </div>
                                    <div class="flex items-center cursor-pointer px-4 border border-gray-200 rounded  w-full">
                                        <input id="bank_loan_no" type="radio" value="0" name="bank_loan" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer" 
                                        {{($bank_loan == 0)?"checked":''}}>
                                        <label for="bank_loan_no" class="w-full py-4 ml-2 text-sm font-medium text-gray-900 cursor-pointer">No</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 bg-grey-100">
                        <div class="input-group input-group-outline">
                            <span>Booking Amount:</span>
                            <input type="number" id="booking_amount" style="border:2px solid lightgrey;"
                                placeholder="Enter here -----" name="booking_amount" value="{{ $booking_amount }}"
                                class="mt-4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="{{url('/agent/property/address/' . $property->unique_url)}}"
            class="text-white bg-neutral-600 hover:bg-neutral-700 focus:ring-4 focus:outline-none focus:ring-neutral-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Prev</a>
        <button type="submit" id="amenitiesForm"
            class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">
            Save & Next
        </button>
    </form>
</div>
@stop