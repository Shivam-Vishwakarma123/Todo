@extends('layouts.agents.agent')
@section('title', 'Description')

@section('content')
    @php 
        if(isset($property)){ 
                $description = $property->description; 
            }
            else{
                $description = old('description');
            }
    @endphp

<div class="w-full rounded overflow-hidden">
    <form action="{{url('/agent/property/store-description')}}"  id="amenitesForm"  method="post">
        @csrf
        <div class="mb-6">
        <div class="w-full">
           <h2 class="text-3xl font-bold">Property Details</h2>
           <div class="pb-10 p-5 bg-grey-100">
                <div class="mt-3">
                    <div class=" mt-4">
                        <textarea id="description" name="description" class="summernote block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 " rows="4" placeholder="Add short description about the property...">{{ $description }}</textarea>
                    </div>
                </div>
            </div>
        </div>

        </div>
        <a href="{{url('/agent/property/listing-type')}}" class="text-white bg-neutral-600 hover:bg-neutral-700 focus:ring-4 focus:outline-none focus:ring-neutral-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Prev</a>
        <!--<button type="submit" class="button button-green m-5 float-right" data-ripple-light="true">Save & Next</button>-->
        <button type="submit" class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">
        Save & Next
        </button>
    </form>
</div>
@stop