@extends('layouts.agents.agent')
@section('title', 'Billing')

@section('content')

<div class="mb-6">
<h2 class="text-4xl font-bold ">Package Details</h2>
</div>
<div class="mb-6">
    <span class="font-bold text-lg bg-yellow-800 text-white">Total credit Balance : {!! $agents->credit_balance !!}</span>
    @foreach($payment_details as $payment)
        <x-agent-billing-mobile-view :payment="$payment"  ></x-agent-billing-mobile-view>
    @endforeach
    <div class="m-12">
        {{ $payment_details->render()}}
    </div>
</div>
    <a href="{{url('agent/credit-plans')}}">
        <button class="text-gray-900 bg-lime-300 font-medium rounded-lg text-sm px-5 py-2.5">Buy More Credits <i class="fa-solid fa-arrow-right ml-2"></i></button>
    </a>
@stop