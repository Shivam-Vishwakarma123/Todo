@extends('layouts.agents.agent')
@section('title', 'Contact Request')

@section('content')
<div class="mb-6">
<h2 class="text-4xl font-bold ">Contact Request Details</h2>
</div>
<div class="mb-6">
    <table class="ps-table">
        <thead>
            <tr>
                <th>ID:</th>
                <th>Property_id</th>
                <th>User Name</th>
                <th>Request Date</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
        @foreach($contact_request as $cnt_request)
            <tr class="text-center">
                <td>{{ $cnt_request->id }}</td>
                <td>{{ $cnt_request->property_id }}</td>
                <td>{{ $cnt_request->user_name }}</td>
                <td>{{ ($cnt_request->created_at == "") ? "" : \Carbon\Carbon::parse($cnt_request->created_at)->format('d-m-Y') }}</td>
                <td class="text-blue-600"><a href='{{url('/agent/contact-request-listing/' . $cnt_request['id'])}}' target="_blank">View Details</a></td>
                
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@stop