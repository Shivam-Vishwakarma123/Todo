@extends('layouts.agents.agent')
@section('content')
Redirecting to payment gateway...

<script type="text/javascript">
    window.addEventListener('load', function() {
        let session = '<?php echo $session; ?>';
		const cashfree = Cashfree({
			 mode:"production" //or sandbox
		});
		let checkoutOptions = {
				paymentSessionId: session,
				redirectTarget: "_self" //optional (_self or _blank)
			}

		cashfree.checkout(checkoutOptions)
    })
</script>
@stop