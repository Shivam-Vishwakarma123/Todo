@extends('layouts.agents.agent')
@section('title', 'Contact Request')

@section('content')

<div class="mb-6">
<h2 class="text-4xl font-bold text-left">Contact Request Details</h2>
</div>
<div class="mb-6">
    <table class="ps-table border-2 ">
        <tbody> 
            <tr>
            <th class="text-left">User name</th>
            <td>{{ $request_details->user_name }}</td>
            </tr>

            <tr>
            <th class="text-left">User phone</th>
            <td class="text-blue-600"><a href='tel:{{ $request_details->user_phone }}'>{{ $request_details->user_phone }}</a></td>
            </tr>

            @if($request_details->user_email != '')
            <tr>
            <th class="text-left">User email</th>
            <td class="text-blue-600"><a href='mailto:{{ $request_details->user_email }}'>{{ $request_details->user_email }}</a></td>
            </tr>
             @endif

            <tr>
            <th class="text-left">User message</th>
            <td>{{ $request_details->user_message }}</td>
            </tr>

            <tr>
            <th class="text-left">Property name</th>
            <td class="text-blue-600"><a href='{{url('/'. $properties['unique_url'])}}'>{{ $properties->name }}</a></td>
            </tr>

            <tr>
            <th class="text-left">Request Date</th>
            <td>{{ ($request_details->created_at == "") ? "" : \Carbon\Carbon::parse($request_details->created_at)->format('d-m-Y') }}</td>
            </tr>
        </tbody>
    </table>
</div>
@stop