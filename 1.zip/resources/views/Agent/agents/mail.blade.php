<h3>Hello,</h3>
<p>Please use the verification code below on the Realtyinterface website agent forget password :</p>
<h2>{{$data}}</h2>
<p>If you don't request this. you can ignore this email or let us know.</p>
<p>Thanks!</p>
<p>Realtyinterface team</p>