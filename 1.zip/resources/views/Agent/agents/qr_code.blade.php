
<!DOCTYPE html>

<html>

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

  </head>

  <body>

    <div style="text-align:center;">

      {!! ($agent->agent_addresses != "") ? "<h1>".$agent->agent_addresses->business_name."</h1>" : ""  !!}
      <h2>{{ $agent->first_name." ".$agent->last_name  }}</h2>
      <h2>Phone: {{ $agent->phone  }}</h2>
      <h3>Scan the QR to see all properties available with us.</h3>
      <div style="margin:100px 40px 100px 40px;">

        @php $svg = QrCode::size(500)->generate( url('/agents/'.$agent->handle. "/All?t=" . base64_encode($agent->handle)) );
        echo "<img src='data:image/svg+xml;base64,".base64_encode($svg)."  style='float:center' />";
        @endphp

        </div>
        <div style="position: absolute; bottom:0px;left:33%">
          <p> Powered by PropertyShops.in </p>
        </div>
    </div>

  </body>
  
</html>