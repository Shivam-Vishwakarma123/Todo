@extends('layouts.agents.agent')
@section('title', 'Billing')
@section('content')
<div class="mb-6">
    <h2 class="text-4xl font-bold ">Package Details</h2>
</div>
<div class="mb-6">
    <span class="font-bold text-lg bg-yellow-800 text-white">Total credit Balance : {!! $agents->credit_balance
        !!}</span>
    <table class="ps-table">
        <thead>
            <tr>
                <th>ID:</th>
                <th>Date</th>
                <th>Credits Purchased</th>
                <th>Amount Due</th>
                <th>Status</th>
                <th>Invoice</th>
            </tr>
        </thead>
        <tbody>
            @foreach($payment_details as $payment)
            <tr class="text-center">
                <td>{{ $payment->id }}</td>
                <td>{{ ($payment->payment_date == "") ? "" : \Carbon\Carbon::parse($payment->payment_date)->format('d-m-Y') }}
                </td>
                <td>{{ $payment->plans->credits }}</td>
                <td><span style="font-family: DejaVu Sans; sans-serif;">&#8377; {{ $payment->amount }}</span></td>
                <td>{{ ($payment->status == "Pending")?"Failed":$payment->status }}</td>

                <td class="text-blue-600">
                    @if($payment->status == "Paid")
                    <a href='{{url('/files/invoices/'.$payment->invoices?->file_name)}}'
                        target="_blank">Download
                    </a>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="m-12">
        {{ $payment_details->render()}}
    </div>
</div>
<form style="display: inline" action="{{url('agent/credit-plans')}}" method="get">
    <button class="text-gray-900 bg-lime-300 font-medium rounded-lg text-sm px-5 py-2.5">Buy More Credits <i
            class="fa-solid fa-arrow-right ml-2"></i></button>
</form>
@stop
