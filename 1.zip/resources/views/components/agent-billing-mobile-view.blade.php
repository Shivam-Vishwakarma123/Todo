<div class="mt-2 p-5 bg-gray-300 my-1 rounded-lg w-full overflow-hidden justify-center mx-auto"> 
    <div class="flex justify-between">
        <p>ID: {{ $payment_id }}</p>
        <p>Date: {{ \Carbon\Carbon::parse($payment_date)->format('d-m-Y') }}</p>
    </div>
    <div class="my-4">
        <p>Credits Purchased: {{ $credits_purchased }}</p>
    </div>
    <div class="my-4">
        <p>Amount Paid: <span style="font-family: DejaVu Sans; sans-serif;">&#8377; {{ $amount_paid }}</span></p>
    </div>
    <div class="flex my-4 justify-between">
        <p>Status: {{ $status }}</p>
        <a  class="bg-gray-600 p-2 text-white rounded" href='{{url('/files/invoices/'.$payment_invoices_file_name)}}' target="_blank">Download Invoice</a>
    </div>
</div>