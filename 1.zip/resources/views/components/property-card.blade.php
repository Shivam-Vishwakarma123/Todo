<div class="bg-white border border-gray-200 rounded-lg shadow  mx-1 w-80 mb-8">
    <div class="relative p-3">
        <div class="flex h-60 justify-center items-center overflow-hidden">
            <img src="{{ $property->property_single_image }}" alt="{{ $property->name }}" decoding="async" loading="lazy"
                title="" class="pc-grow h-full w-full object-cover object-center">
        </div>
    </div>
    <div class="mt-2 px-3">
        <div class="left-5 z-10 bottom-2 text-black">
            <div class="flex-wrap"><span class=""><bdi class="text-xl font-semibold"><span
                            class="mr-1.5">&#8377;</span>{{ $property->price }}</bdi></span></div>
        </div>
        <div class="bg-white pt-1.5 text-sm left-5" style="bottom:-4px;border-radius:5px 5px 0 0">
            {{ $property->property_type }}
        </div>
        <div class="text-black-700 text-lg">
            <span>{{ $property->name }}</span>
        </div>
        <div class="text-gray-400">
            <span>
                <i class="fas fa-map-marker-alt"></i>
                <a href= "{{url('properties/city/')}}/{{$property->city?->slug}}/All?sort=Recent&direction=asc" title="View all properties at {{ $property->city?->name }},{{$property->state?->name}}">{{ $property->city?->name }},{{$property->state?->name}}</a>
            </span>
        </div>
        <div class="my-3">
            <div class="grid grid-cols-3 grid-gap-4">
                <div class="flex">
                    <i class="rtcl-icon rtcl-icon- flaticon-bed"><svg xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 512 512" height="20px" width="20px" style="enable-background:new 0 0 512 512"
                            xml:space="preserve">
                            <style>
                            .st10 {
                                fill: #1f3049
                            }
                            </style>
                            <path
                                d="M.4 255.4C.4 114 115-.6 256.4-.6s256 114.6 256 256-114.6 256-256 256S.4 396.8.4 255.4z"
                                style="fill:#5082a9" />
                            <g>
                                <path style="fill:#e09c6f" d="M123.2 246h282v40h-282z" />
                                <path class="st10" d="M123.2 286.9h282v40.2h-282z" />
                                <path class="st10"
                                    d="M131.5 356V153.4c0-4.3-3.5-7.9-7.9-7.9h-8.8c-4.3 0-7.9 3.5-7.9 7.9V356h24.6zM418.9 356V210.4c0-4.3-3.5-7.9-7.9-7.9h-8.8c-4.3 0-7.9 3.5-7.9 7.9V356h24.6z" />
                                <path d="M394.9 311v-79.7c0-5.4-4.3-9.7-9.7-9.7H214.6c-5.4 0-9.7 4.3-9.7 9.7V311h190z"
                                    style="fill:#c93a3a" />
                                <path style="fill:#d5872a" d="M227.9 221.6h20V311h-20z" />
                                <ellipse cx="168.9" cy="224.5" rx="36" ry="21.5" style="fill:#fff" />
                            </g>
                        </svg></i>
                    <span class="listable-value pl-2">
                        <span class="prefix text-xs font-semibold">Beds</span>
                        <span class="value text-xs font-semibold">{{ $property->bedroom }}</span>
                    </span>
                </div>
                <div class="flex">
                    <i class="rtcl-icon rtcl-icon- flaticon-shower"><svg data-name="Layer 1"
                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" height="20px" width="20px">
                            <defs>
                                <style>
                                .cls-2 {
                                    fill: #db
                                }

                                .cls-3 {
                                    fill: #b6d9df
                                }
                                </style>
                            </defs>
                            <path
                                d="M256 7.92C119 7.92 7.92 119 7.92 256S119 504.08 256 504.08 504.08 393 504.08 256 393 7.92 256 7.92z"
                                style="fill:#48a1af" />
                            <path class="cls-2"
                                d="M355.24 231.38 247 126a13.14 13.14 0 0 0-18.58.25l-4.59 4.75a13.14 13.14 0 0 0 .25 18.58l108.26 105.33a13.14 13.14 0 0 0 18.57-.25l4.58-4.71a13.13 13.13 0 0 0-.25-18.57z" />
                            <path class="cls-2"
                                d="M346 132.46c-31.46-30.84-82.19-30.11-113.32 1.64l113.9 111.68c31.13-31.78 30.86-82.48-.58-113.32z" />
                            <path class="cls-3"
                                d="M167.51 178.39a16.78 16.78 0 0 0 23 24.48c6.76-6.34 17.81-39.74 17.81-39.74s-25.23.64-40.81 15.26zM220.71 233.81a16.78 16.78 0 0 0 23 24.48c6.76-6.34 17.81-39.74 17.81-39.74s-25.24.64-40.81 15.26zM107.78 346.86a16.78 16.78 0 1 0 23 24.47c6.76-6.34 17.81-39.74 17.81-39.74s-25.24.65-40.81 15.27zM272.58 285.82a16.78 16.78 0 0 0 23 24.48c6.76-6.34 17.81-39.74 17.81-39.74s-25.24.64-40.81 15.26zM137.66 259.69a16.78 16.78 0 0 0 23 24.48c6.76-6.34 17.81-39.74 17.81-39.74s-25.24.64-40.81 15.26zM190.85 315.1a16.78 16.78 0 1 0 23 24.48c6.76-6.34 17.81-39.74 17.81-39.74s-25.24.64-40.81 15.26z" />
                            <path class="cls-2"
                                d="M396.64 108.81c-13.73-3.56-29.82-1.14-45.29 6.8-13.26 6.81-24.53 16.9-30.13 27a13 13 0 0 0 22.73 12.63c5.67-10.2 28.52-25.83 46.17-21.25 20.84 5.4 24 39.87 24 59.94V447.2a249.53 249.53 0 0 0 26-24.89V193.92c-.05-61.04-23.67-79.98-43.48-85.11z" />
                        </svg></i>
                    <span class="listable-value pl-2">
                        <span class="prefix text-xs font-semibold">Baths</span>
                        <span class="value text-xs font-semibold">{{ $property->bathroom }}</span>
                    </span>
                </div>
                <div class="flex">
                    <i class="rtcl-icon rtcl-icon- flaticon-resize"><svg version="1.1"
                            xmlns="http://www.w3.org/2000/svg" x="0" y="0" viewBox="0 0 256 256"
                            style="enable-background:new 0 0 256 256" height="20px" width="20px" xml:space="preserve">
                            <style>
                            .st0 {
                                fill: #382b73
                            }

                            .st7 {
                                fill: #fff
                            }

                            .st8 {
                                fill: #e6e7e8
                            }

                            .st9 {
                                fill: #fede3a
                            }

                            .st10 {
                                fill: #f7cb15
                            }
                            </style>
                            <switch>
                                <g>
                                    <circle class="st0" cx="128" cy="128" r="120" />
                                    <circle cx="128" cy="128" r="102.5" style="fill:#473080" />
                                    <path class="st0"
                                        d="M191.243 86.32c.049-.113.082-.23.123-.347a5.04 5.04 0 0 0 .164-.533c.029-.126.045-.253.064-.381a4.94 4.94 0 0 0 .056-.529 4.758 4.758 0 0 0-.003-.396 4.78 4.78 0 0 0-.262-1.418 4.987 4.987 0 0 0-.142-.38 5.035 5.035 0 0 0-.246-.479c-.067-.117-.131-.235-.208-.348-.028-.041-.046-.086-.075-.126l-.013.015c-.144-.199-.286-.398-.463-.578a4.998 4.998 0 0 0-7.071-.069l-35.242 34.559-28.836-27.052a5 5 0 0 0-6.395-.373L77 114.291V79a4.998 4.998 0 0 0-5-4.997V74c-.017 0-.033.005-.05.005a4.71 4.71 0 0 0-.442.019c-.092.009-.175.039-.265.053a4.382 4.382 0 0 0-.881.221 3.892 3.892 0 0 0-.725.322C68.074 75.464 67 77.098 67 79v112a5 5 0 0 0 5 5h112c.329 0 .649-.036.961-.097.022-.004.044-.006.066-.011.296-.062.581-.154.856-.266l.096-.037a5.02 5.02 0 0 0 .753-.409c.035-.023.07-.044.104-.068.231-.159.445-.338.646-.533l.094-.093a5.03 5.03 0 0 0 .53-.643l.074-.111c.154-.235.289-.481.402-.741.017-.038.031-.077.047-.116.109-.267.197-.544.258-.832.007-.034.012-.069.018-.104.057-.298.091-.605.093-.919l.002-.021h-.003c0-.161-.005-.324-.021-.489l.022-101.475 1.169-1.146a5 5 0 0 0 .621-.745c.06-.088.103-.183.157-.273.108-.18.215-.361.298-.551z" />
                                    <g>
                                        <path
                                            d="m115.288 85.529 29.291 27.479a5 5 0 0 0 6.922-.077L189 75.015 188.976 184H72v-66.43l43.288-32.041z"
                                            style="fill:#a72973" />
                                        <path
                                            d="M74.671 120.237a4.999 4.999 0 0 1-2.977-9.02l41-30.333a5 5 0 0 1 6.395.373l28.836 27.052 35.242-34.559a5 5 0 0 1 7.002 7.139l-38.667 37.917a5 5 0 0 1-6.922.077l-29.291-27.479-37.649 27.852a4.973 4.973 0 0 1-2.969.981z"
                                            style="fill:#ef5a9d" />
                                        <path
                                            d="m190.168 75.015-38.667 37.917a5 5 0 0 1-6.922.077L115.288 85.53 77.64 113.381a4.978 4.978 0 0 1-2.97.981 4.99 4.99 0 0 1-4.023-2.027l-.027-.037a5 5 0 0 0 4.05 7.939 4.978 4.978 0 0 0 2.97-.981l37.647-27.853 29.291 27.479a5 5 0 0 0 6.922-.077l38.667-37.917a5.002 5.002 0 0 0 .546-6.507 4.859 4.859 0 0 1-.545.634z"
                                            style="fill:#e43d91" />
                                        <g>
                                            <path
                                                d="M184 189H72a5 5 0 0 1-5-5V72.215c0-2.611 1.909-4.944 4.508-5.192A5.002 5.002 0 0 1 77 72v105a2 2 0 0 0 2 2h104.785c2.611 0 4.944 1.909 5.192 4.508A5.002 5.002 0 0 1 184 189z"
                                                style="fill:#1caee4" />
                                            <path
                                                d="M72 67a5 5 0 0 0-5 5v112a5 5 0 0 0 5 5h112a5 5 0 0 0 5-5H76a4 4 0 0 1-4-4V67z"
                                                style="fill:#009a" />
                                        </g>
                                        <g>
                                            <path class="st7"
                                                d="M105.56 117.498H89a2 2 0 0 0-2 2v59.5h20.56v-59.5a2 2 0 0 0-2-2z" />
                                            <path class="st8" d="M97.28 117.498H89a2 2 0 0 0-2 2v59.5h10.28v-61.5z" />
                                            <path class="st9"
                                                d="M126.121 108.498H109.56a2 2 0 0 0-2 2v68.5h20.561v-68.5a2 2 0 0 0-2-2z" />
                                            <path class="st10"
                                                d="M117.841 108.498h-8.28a2 2 0 0 0-2 2v68.5h10.28v-70.5z" />
                                            <g>
                                                <path class="st7"
                                                    d="M155.773 128h-16.56a2 2 0 0 0-2 2v48.998h20.56V130a2 2 0 0 0-2-2z" />
                                                <path class="st8"
                                                    d="M147.493 128h-8.28a2 2 0 0 0-2 2v48.998h10.28V128z" />
                                            </g>
                                            <g>
                                                <path class="st9"
                                                    d="M176.333 120.237h-16.561a2 2 0 0 0-2 2v56.761h20.561v-56.761a2 2 0 0 0-2-2z" />
                                                <path class="st10"
                                                    d="M168.053 120.237h-8.28a2 2 0 0 0-2 2v56.761h10.28v-58.761z" />
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </switch>
                        </svg></i>
                    <span class="listable-value pl-2">
                        <span class="value text-xs font-semibold">{{ $property->super_area }}</span>
                        <span class="suffix text-xs font-semibold">Sqft</span>
                    </span>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="grid grid-cols-3 mt-2 p-3">
        <div class="col-start-1 col-end-3">
            <div class="flex">
                <img class="w-8 h-8 object-contain object-center attachment-40x40 size-40x40 rounded-full"
                    src="{{ $property->agent_image }}" alt="" decoding="async" loading="lazy" title="">
                <div class="ml-2 pt-2 text-gray-500 text-sm">
                    <span class="author-link">
                        <a class="text-sm capitalize" onMouseOver="this.style.color='black'"
                            onMouseOut="this.style.color='#808080'"
                            href="{{ url('/')."/agents/".$property->agents->handle }}/All?sort=Recent&direction=asc" 
                            title="Show all properties posted by {{ $property->agent_name }}">{{ $property->agent_name }}</a>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-start-3 col-end-4 justify-self-center bg-lime-500 rounded-sm hover:bg-lime-600 relative px-4">
            <a href="{{ $property->unique_url }}" title="See property details">
                <span
                    class="inline-flex relative items-center px-3 py-2 text-sm font-medium text-center text-white  rounded-md focus:ring-4 focus:outline-none focus:ring-lime-700">
                    Details
                </span>
            </a>
        </div>
    </div>
</div>