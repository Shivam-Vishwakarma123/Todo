
@if ($message = Session::get('success'))
<script>
    $(document).ready(function(){
        var message = "{{ $message }}";
        showPopUp('success' , message);
    });
</script>
@endif

@if ($message = Session::get('error'))
<script>
    $(document).ready(function(){
        var message = "{{ $message }}";
        showPopUp('error' , message);
    });
</script>
@endif

@if ($message = Session::get('warning'))
<script>
    $(document).ready(function(){
        var message = "{{ $message }}";
        showPopUp('warning' , message);
    });
</script>
@endif

@if ($message = Session::get('info'))
<script>
    $(document).ready(function(){
        var message = "{{ $message }}";
        showPopUp('info' , message);
    });
</script>
@endif

@if ($errors->any())
<script>
    $(document).ready(function(){
        showPopUp('error' , 'Please check the Username and Password and try Again.');
    });
</script>
@endif



