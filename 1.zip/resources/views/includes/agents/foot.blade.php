<!-- Jquery script -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<!-- tailwind js -->
<script src="{{ url('js/tailwind.min.js') }}"></script>

<!-- flowbite js -->
<script src="{{ url('js/flowbite.min.js') }}"></script>

<!-- Fontawesome link -->
<script src="{{url('js/fontawesome.min.js')}}"></script>

<!-- function js -->
<script src="{{url('js/functions.js')}}"></script>

<!-- CUSTOM JS -->
<script src="{{url('js/custom.js')}}?t=123"></script>

<script src="{{ url('js/public-custom.js') }}?t=123"></script>
