<aside class="md:block md:w-auto" aria-label="Sidebar">
      <ul>
      <li>
          <a href="{{url('/agent/dashboard')}}" class="py-2">
            <img src="{{ url('/images/realtyinterface_logo.png') }}" alt="">
          </a>
        </li>

        <li>
          <a href="{{url('/agent/dashboard')}}"><i class="fas fa-th-large"></i>
            <span>Dashboard</span>
          </a>
        </li>

        <li>
          <a href="{{url('/agent/property/listing')}}"><i class="fas fa-home"></i>
            <div>Manage Properties</div>
          </a>
        </li>

        <li>
          <a href="{{url('/agent/billing')}}"><i class="far fa-credit-card"></i>
            <div>Billing</div>
          </a>
        </li>

        <li>
          <a href="{{url('/agent/profile')}}"><i class="fas fa-user"></i>
            <div>Profile</div>
          </a>
        </li>

        <li>
          <a href="{{url('/agent/sign-out')}}"><i class="fas fa-door-open"></i>
            <div>Sign Out</div>
          </a>
        </li>
      </ul>
</aside>


<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('states', function (Blueprint $table) {
            $table->id('id');
            $table->string('name',50);
            $table->boolean('is_home')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('states');
    }
}

//custom.css -previous/backup

/*
green shade - #008a8f
Blue Shade - #0069a6
purple shade - #6f4693
button blue - #1F7FBC
*/

/* Overriding the styles from material-tailwind - START */

.input-group.focused.input-group-outline .form-label+.form-control,.input-group.is-filled.input-group-outline .form-label+.form-control { 
  /* border-color:#0000 #6f4693 #6f4693;
  box-shadow:inset 1px 0 #6f4693,inset -1px 0 #6f4693,inset 0 -1px #6f4693; */
  border-color: #0000 #cfd8dc #cfd8dc;
  box-shadow: inset 1px 0 #cfd8dc, inset -1px 0 #cfd8dc, inset 0 -1px #cfd8dc;
}
.input-group.focused .form-label, .input-group.is-filled .form-label { z-index: 1; }
h1, h2, h3, h4, h5, h6 { color: #0069a6; }
.input-group.focused .form-label:after, .input-group.focused .form-label:before, .input-group.is-filled .form-label:after, .input-group.is-filled .form-label:before {
  /* border-top-color: #6f4693;
  box-shadow: inset 0 1px #6f4693; */
  border-top-color: #cfd8dc;
  box-shadow: inset 0 1px #cfd8dc;
}
.input-group.focused .form-label, .input-group.is-filled .form-label { color: inherit}
b, strong { font-weight: 600;}

/* Overriding the styles from material-tailwind - END */

.ri-bg-blue {
  background-color: #0069a6;
}
.ri-bg-green {
  background-color: #008a8f;
}
.ri-bg-purple {
  background-color: #6f4693;
}
.text-color-p{
  color: #6f4693;
}
h4 {
  font-size: 175%;
  margin: 2% 0;
  border-bottom: 2px dotted #dddddd;
  padding-bottom: 10px;
}
.card-header h4 {
  border-bottom: 0px;
}

/* Table Styles - START */
table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
table td {
  border: 1px solid #ddd;
  padding: 5px 10px;
}
table th {
  border: 1px solid #ddd;
  padding: 15px 10px;
}
table tr:nth-child(odd) {
  background-color: #f2f2f2;
}
table tr:hover {
  background-color: #ddd;
}
table th {
  text-align: left;
  background-color: #009390;
  color: white;
}
.p-1
{
  padding:.625rem 1rem !important ;
}

.h-100 {
  height:100%;
}

.btn-purple{
  float: right;
  margin-top:-6vh;
  background-color: #6f4693;
  font-weight: bold;
  font-size: 15px;
  color: white;
}
.btn-blue{
  float: right;
  margin-top: -10vh;
  background-color: rgb(0, 100, 131);
  font-weight: bold;
  font-size: 15px;
  color: white;
  padding: 10px 20px;
  margin-bottom: 20px;
}
table td .button {
  margin-right: 10px;
}
/* end of Table Styles - END */

.gallery-image {
  border: 1px solid #dddddd;
  border-radius: 5px;
  overflow: hidden;
}
.property-next {
  margin-top: 5%;
  padding: 10px; 
  border-top: 2px dotted #dddddd;
  text-align: right;
  display: block;
}
.nbbar{
  display:none;
}
#agents_sidebar {
  width:13%;
  position:fixed; 
  height: 100%;
  right: 100px;
  background-color: #3d464e;
}
.agent_menu {
  width: 100px;
  height: 100%;
  position:fixed; 
  right: 0px;
  background-color: #333c44;
}
.agent_menu li {
  text-align: center;
}
.agent_menu a {
  padding: 30px 0px;
  display: block;
  font-size: 14px;
  color: #f0f0f0;
}
.agent_menu i, .agent_menu svg {
  display: block;
  margin: 0px auto 5px;
  font-size: 26px;
}
/* set width here for agent sign-in , forget-agent-password , reset-agent-password form section */
.agentsign,.forgetAgentPassword,.resetPassword{
  width: 70%;
  margin: 0px auto;
}

.agentsign .agnet_logo img {
  width:30% ; margin:0px auto;
}
.dialog .dialog-box {
   max-width: 60%; 
}
.sidebar li a{
  font-weight: 600;
  text-transform: uppercase;
  color:#f0f0f0;
  font-size: 14px;
}
.sidebar li:hover{
  background-color: rgba(3, 3, 3, 0.152);
}
.sidebar li a:hover{
  color: rgba(255, 255, 255, 0.822);
}
.flash-div{
  width: 30%;
  margin: 1% 35%;
  z-index: 1000;
  position: absolute;
  padding: 10px 20px;
}
.amenities {
  background: lightgray;
  border-radius: 5px;
  padding: 2px 14px;
  margin: 0px 3px 6px 3px;
  display: inline-block;
}
.amenities:hover{
  color: white;
  cursor: pointer;
  background-color: black;
}
.amenitiesbutton{
  float: left;
  background: transparent;
  border-radius: 3px;
  padding-left: 3px;
  padding-right: 3px;
}
.amenitiesbutton{
  cursor: pointer;
  outline: none;
}
.amenitiesbutton1{
  background: transparent;
  padding: 0px 7px 0px 3px;
  margin-top: 0px;
}
.amenitie {
  display: inline-block;
  background: lightgrey;
  border-radius: 5px;
  padding: 2px 0px 2px 5px;
  margin: 0px 3px 6px 3px;
}

.amenitiesbutton1:hover{
  color: red;
}
.dropzone {
  border: 1px dashed rgba(0,0,0,.8);
}
.hide-gallery{  
  position: relative;
  top: -188px;
}
.grid-count{
  margin-top: -22px;
}
@media (max-width:992px){
  .nbbar{
      display: block;
  }
}

/* add css for address form country field */
.address_field{
  border:1px solid #cfd8dc; padding: .5rem .75rem; border-radius: .375rem; border-top-left-radius: .375rem; border-bottom-left-radius: .375rem;
}

.active {
  background-color: rgb(162, 160, 160);
}
.bg-transparent-color{
  background-color: transparent !important;
}






// sidebar previous contents
<aside class="md:block md:w-auto" aria-label="Sidebar">
    <ul class="space-y-2 sidebar my-3">
        <li class="{{ (request()->is('agent/property/address/'.$property->id)) ? 'active' : '' }}">
            <a href="{{url('/agent/property/address/'.$property->id)}}" class="flex items-center p-3 pl-5 text-base">
                <i class="fas fa-calendar-day pr-2"></i>
                <span>Details </span> 
            </a>
        </li>
        <li class="{{ (request()->is('agent/property/description')) ? 'active' : '' }}">
            <a href="{{url('/agent/property/description')}}" class="flex items-center p-3 pl-5 text-base">
            <i class="fa-solid fa-file pr-2"></i>
                <span>Description</span> 
            </a>
        </li>
        <li class="{{ (request()->is('agent/property/amenities')) ? 'active' : '' }}">
            <a href="{{url('/agent/property/amenities')}}" class="flex items-center p-3 pl-5 text-base">
                <i class="fas fa-calendar-day pr-2"></i>
                <span>Amenities</span> 
            </a>
        </li>
        <li class="{{ (request()->is('agent/property/price-feature')) ? 'active' : '' }}">
            <a href="{{url('/agent/property/price-feature')}}" class="flex items-center p-3 pl-5 text-base">
            <i class="fa-solid fa-sack-dollar pr-2"></i>
                <span>Price & Features</span> 
            </a>
        </li>
        <li class="{{ (request()->is('agent/property-images/images')) ? 'active' : '' }}">
            <a href="{{url('/agent/property-images/images')}}" class="flex items-center p-3 pl-5 text-base">
                <i class="fa-regular fa-image pr-2"></i>
                <span>Photo Library</span>
            </a>
        </li>

   
        <li class="{{ (request()->is('agent/video/video')) ? 'active' : '' }}">
            <a href="{{url('/agent/video/video')}}" class="flex items-center p-3 pl-5 text-base">
                <i class="fa-solid fa-video pr-2"></i>
                <span>Videos</span>
            </a>
        </li>
    
        <li class="{{ (request()->is('agent/property-topbar/choose')) ? 'active' : '' }}">
            <a href="{{url('/agent/property-topbar/choose' )}}" class="flex items-center p-3 pl-5 text-base">
                <i class="fa-solid fa-hand-pointer pr-2"></i>
                <span>Choose Topbar</span>
            </a>
        </li>
        <li class="{{ (request()->is('agent/address/address-map')) ? 'active' : '' }}">
        <a href="{{url('/agent/address/address-map')}}" class="flex items-center p-3 pl-5 text-base">
                <i class="fa-solid fa-map-location pr-2"></i>
                <span>Address & Map</span>
            </a>
        </li>
        <li class="{{ (request()->is('agent/property/default')) ? 'active' : '' }}">
        <a href="{{url('/agent/property/default')}}" class="flex items-center p-3 pl-5 text-base">
                <i class="fas fa-map-marker-alt pr-2"></i>
                <span>Default Url</span>
            </a>
        </li>
    </ul>
</aside>


//custom.css
/*
green shade - #008a8f
Blue Shade - #0069a6
purple shade - #6f4693
button blue - #1F7FBC
*/

/* Overriding the styles from material-tailwind - START */

.input-group.focused.input-group-outline .form-label+.form-control,.input-group.is-filled.input-group-outline .form-label+.form-control { 
  /* border-color:#0000 #6f4693 #6f4693;
  box-shadow:inset 1px 0 #6f4693,inset -1px 0 #6f4693,inset 0 -1px #6f4693; */
  border-color: #0000 #cfd8dc #cfd8dc;
  box-shadow: inset 1px 0 #cfd8dc, inset -1px 0 #cfd8dc, inset 0 -1px #cfd8dc;
  }
  .input-group.focused .form-label, .input-group.is-filled .form-label { z-index: 1; }
  h1, h2, h3, h4, h5, h6 { color: #0069a6; }
  .input-group.focused .form-label:after, .input-group.focused .form-label:before, .input-group.is-filled .form-label:after, .input-group.is-filled .form-label:before {
  /* border-top-color: #6f4693;
  box-shadow: inset 0 1px #6f4693; */
  border-top-color: #cfd8dc;
  box-shadow: inset 0 1px #cfd8dc;
  }
  .input-group.focused .form-label, .input-group.is-filled .form-label { color: inherit}
  b, strong { font-weight: 600;}
  
  /* Overriding the styles from material-tailwind - END */
  
  .ri-bg-blue {
  background-color: #0069a6;
  }
  .ri-bg-green {
  background-color: #008a8f;
  }
  .ri-bg-purple {
  background-color: #6f4693;
  }
  .text-color-p{
  color: #6f4693;
  }
  h4 {
  font-size: 175%;
  margin: 2% 0;
  border-bottom: 2px dotted #dddddd;
  padding-bottom: 10px;
  }
  .card-header h4 {
  border-bottom: 0px;
  }
  
  /* Table Styles - START */
  table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  }
  table td {
  border: 1px solid #ddd;
  padding: 5px 10px;
  }
  table th {
  border: 1px solid #ddd;
  padding: 15px 10px;
  }
  table tr:nth-child(odd) {
  background-color: #f2f2f2;
  }
  table tr:hover {
  background-color: #ddd;
  }
  table th {
  text-align: left;
  background-color: #009390;
  color: white;
  }
  .p-1
  {
  padding:.625rem 1rem !important ;
  }
  
  .h-100 {
  height:100%;
  }
  
  .btn-purple{
  float: right;
  margin-top:-6vh;
  background-color: #6f4693;
  font-weight: bold;
  font-size: 15px;
  color: white;
  }
  .btn-blue{
  float: right;
  margin-top: -10vh;
  background-color: rgb(0, 100, 131);
  font-weight: bold;
  font-size: 15px;
  color: white;
  padding: 10px 20px;
  margin-bottom: 20px;
  }
  table td .button {
  margin-right: 10px;
  }
  /* end of Table Styles - END */
  
  .gallery-image {
  border: 1px solid #dddddd;
  border-radius: 5px;
  overflow: hidden;
  }
  .property-next {
  margin-top: 5%;
  padding: 10px; 
  border-top: 2px dotted #dddddd;
  text-align: right;
  display: block;
  }
  .nbbar{
  display:none;
  }
  #agents_sidebar {
  width:13%;
  position:fixed; 
  height: 100%;
  right: 100px;
  left: 0px;
  
  }
  
  .agent_menu {
  width: 1800px;
 
  }
  
  .agent_menu a {
  margin-right: 100px;
  display: block;
  font-size: 14px;
  color: #f0f0f0;
  }
  
  /* set width here for agent sign-in , forget-agent-password , reset-agent-password form section */
  .agentsign,.forgetAgentPassword,.resetPassword{
  width: 70%;
  margin: 0px auto;
  }
  
  .agentsign .agnet_logo img {
  width:30% ; margin:0px auto;
  }
  .dialog .dialog-box {
  max-width: 60%; 
  }
  .sidebar li a{
  font-weight: 600;
  text-transform: uppercase;
  color:#f0f0f0;
  font-size: 14px;
  }
  .sidebar li:hover{
  background-color: rgba(3, 3, 3, 0.152);
  }
  .sidebar li a:hover{
  color: rgba(255, 255, 255, 0.822);
  }
  .flash-div{
  width: 30%;
  margin: 1% 35%;
  z-index: 1000;
  position: absolute;
  padding: 10px 20px;
  }
  .amenities {
  background: lightgray;
  border-radius: 5px;
  padding: 2px 14px;
  margin: 0px 3px 6px 3px;
  display: inline-block;
  }
  .amenities:hover{
  color: white;
  cursor: pointer;
  background-color: black;
  }
  .amenitiesbutton{
  float: left;
  background: transparent;
  border-radius: 3px;
  padding-left: 3px;
  padding-right: 3px;
  }
  .amenitiesbutton{
  cursor: pointer;
  outline: none;
  }
  .amenitiesbutton1{
  background: transparent;
  padding: 0px 7px 0px 3px;
  margin-top: 0px;
  }
  .amenitie {
  display: inline-block;
  background: lightgrey;
  border-radius: 5px;
  padding: 2px 0px 2px 5px;
  margin: 0px 3px 6px 3px;
  }
  
  .amenitiesbutton1:hover{
  color: red;
  }
  .dropzone {
  border: 1px dashed rgba(0,0,0,.8);
  }
  .hide-gallery{ 
  position: relative;
  top: -188px;
  }
  .grid-count{
  margin-top: -22px;
  }
  @media (max-width:992px){
  .nbbar{
  display: block;
  }
  }
  
  /* add css for address form country field */
  .address_field{
  border:1px solid #cfd8dc; padding: .5rem .75rem; border-radius: .375rem; border-top-left-radius: .375rem; border-bottom-left-radius: .375rem;
  }
  
  .active {
  background-color: rgb(162, 160, 160);
  }
  .bg-transparent-color{
  background-color: transparent !important;
  }
  