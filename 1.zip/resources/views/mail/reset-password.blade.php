<div>
    <h2>Hii, {{ $name }}</h2>
    <h3>We received a request to reset your password</h3>
    <p>After received your query we forget your password.<br>
        Your Username :- <strong>{{ $email }}</strong> <br>
        and Your New password :- <strong>{{ $password }}</strong>
    </p>
    <br>
    <p>Thanku For Contacting...!</p>
</div>