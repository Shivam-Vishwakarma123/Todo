@extends('layouts.public')
@section('title', 'Terms & Conditions')

@section('content')
<div class="flex bg-gray-50 h-full py-24 bg-lime-100 justify-center">
    <div class="w-5/6 bg-white rounded-lg shadow p-4 static-page">
        <h1 class="text-center text-2xl">Terms & Conditions of Use</h1>
        <p>
            Please read the following terms and conditions of use carefully before using this website (PropertyShops.in).
            By continuing using this website will be treated as your acceptance and conset to these terms and conditions of use.
            If you do not agree to these terms and conditions, please do not use this site.
        </p>
        <b>Copyright</b>
        <p>
            The entire content included in this site, including but not limited to text, graphics or code is copyright of Nirvaat Internet Private Limited under the
            copyright laws of India, and is the property of Nirvaat Internet Private Limited for designing and managing Websites.
        </p>
        <p>
            All rights are reserved with Nirvaat Internet Private Limited. Permission is granted to electronically copy and print hard copy portions of this site for
            the sole purpose of placing an order or purchasing of products on PropertyShops.in. You may display and, subject to any expressly stated restrictions or
            limitations relating to specific material, download or print portions of the material from the different areas of the site solely for your
            own non-commercial use, or to place an order on PropertyShops.in.
        </p>
        <p>
            Any other use, including but not limited to the reproduction, distribution, display or transmission of the content of this site is strictly prohibited,
            unless authorized by Nirvaat Internet Private Limited. You further agree not to change or delete any proprietary notices from materials downloaded from the site.
        </p>

        <b>Trademarks</b>
        <p>
            All trademarks, service marks and trade names of any third party products or brands are only for promotion of the products on this website.
            We do not claim any ownership or copyright over these. Their use and reproduction is restricted by copyright of their respective owners.
        </p>


        <b>Warranty Disclaimer</b>
        <p>
            This site and the materials and products on this site are provided "as is" and without warranties of any kind, whether express or implied.
            To the fullest extent permissible pursuant to applicable law, PropertyShops.in or Nirvaat Internet Private Limited disclaims all warranties, express or implied,
            including, but not limited to, implied warranties of merchantability and fitness for a particular purpose and non-infringement.
        </p>
        <p>
            Nirvaat Internet Private Limited does not represent or warrant that the functions contained in the site will be uninterrupted or error-free, that the defects
            will be corrected, or that this site or the server that makes the site available are free of viruses or other harmful components. Nirvaat Internet Private Limited
            does not make any warrantees or representations regarding the use of the materials in this site in terms of their correctness, accuracy, adequacy,
            usefulness, timeliness, reliability or otherwise.
        </p>

        <b>Limitation of Liability</b>
        <p>
            Nirvaat Internet Private Limited shall not be liable for any special or consequential damages that result from the use of, or the inability to use, the materials
            on this site or the performance of the products, even if Nirvaat Internet Private Limited has been advised of the possibility of such damages. Applicable law may
            not allow the limitation of exclusion of liability or incidental or consequential damages, so the above limitation or exclusion may not apply to you.
        </p>

        <b>Typographical Errors</b>
        <p>
            In the event that a PropertyShops.in plan/service is mistakenly listed at an incorrect price, Nirvaat Internet Private Limited reserves the right to refuse or cancel
            any orders placed for product/services listed at the incorrect price. Nirvaat Internet Private Limited reserves the right to refuse or cancel any such orders whether or not
            the order has been confirmed and you are charged. If your credit card/debit card/netbaking/etc has already been charged for the purchase and your order
            is cancelled, Nirvaat Internet Private Limited shall issue a refund to your respective account in the amount of the incorrect price.
        </p>

        <b>Term Termination</b>
        <p>
            These terms and conditions are applicable to you upon your accessing the site and/or completing the registration or shopping process. These terms and conditions,
            or any part of them, may be terminated by Nirvaat Internet Private Limited without notice at any time, for any reason. The provisions relating to Copyrights, Trademark,
            Disclaimer, Limitation of Liability, Indemnification and Miscellaneous, shall survive any termination.
        </p>

        <b>Notice</b>
        <p>
            Nirvaat Internet Private Limited may deliver notice to you by means of e-mail, Phone, a general notice on the site, or by other reliable method to the address you have provided to
            Nirvaat Internet Private Limited.
        </p>

        <b>Miscellaneous</b>
        <p>
            Your use of this site shall be governed in all respects by the laws of the Government of India. You agree that jurisdiction over and venue in any legal proceeding
            directly or indirectly arising out of or relating to this site (including but not limited to the purchase of Nirvaat Internet Private Limited products) shall be in India.
            Any cause of action or claim you may have with respect to the site (including but not limited to the purchase of Nirvaat Internet Private Limited products) must be commenced
            within one (1) month after the claim or cause of action arises. Nirvaat Internet Private Limited failure to insist upon or enforce strict performance of any provision of
            these terms and conditions shall not be construed as a waiver of any provision or right. Neither the course of conduct between the parties nor trade practice
            shall act to modify any of these terms and conditions. Nirvaat Internet Private Limited may assign its rights and duties under this Agreement to any party at any time
            without notice to you.
        </p>

        <b>Use of Site</b>
        <p>
            Harassment in any manner or form on the site, including via e-mail, chat, or by use of obscene or abusive language, is strictly forbidden. Impersonation of others,
            including a Nirvaat Internet Private Limited or other licensed employee, host, or representative, as well as other members or visitors on the site is prohibited.
            You may not upload to, distribute, or otherwise publish through the site any content which is libelous, defamatory, obscene, threatening, invasive of privacy
            or publicity rights, abusive, illegal, or otherwise objectionable which may constitute or encourage a criminal offense, violate the rights of any party or
            which may otherwise give rise to liability or violate any law. You may not upload commercial content on the site or use the site to solicit others to join
            or become members of any other commercial online service or other organization.
        </p>

        <b>Participation Disclaimer</b>
        <p>
            Nirvaat Internet Private Limited does not and cannot review all communications and materials posted to or created by users accessing the site, and is not in any manner
            responsible for the content of these communications and materials. You acknowledge that by providing you with the ability to view and distribute user-generated
            content on the site, Nirvaat Internet Private Limited is merely acting as a passive conduit for such distribution and is not undertaking any obligation or liability
            relating to any contents or activities on the site. However, Nirvaat Internet Private Limited reserves the right to block or remove communications or materials that it
            determines to be (a) abusive, defamatory, or obscene, (b) fraudulent, deceptive, or misleading, (c) in violation of a copyright, trademark or;
            other intellectual property right of another or (d) offensive or otherwise unacceptable to Nirvaat Internet Private Limited in its sole discretion.
        </p>

        <b>Indemnification</b>
        <p>
            You agree to indemnify, defend, and hold harmless Nirvaat Internet Private Limited, its officers, directors, employees, agents, licensors and suppliers
            (collectively the "Service Providers") from and against all losses, expenses, damages and costs, including reasonable attorneys' fees, resulting from any
            violation of these terms and conditions or any activity related to your account (including negligent or wrongful conduct) by you or any other person accessing
            the site using your Internet account.
        </p>

        <b>Third-Party Links</b>
        <p>
            In an attempt to provide increased value to our visitors, PropertyShops.in may link to sites operated by third parties. However, even if the third party is affiliated
            with Nirvaat Internet Private Limited, Nirvaat Internet Private Limited has no control over these linked sites, all of which have separate privacy and data collection practices,
            independent of Nirvaat Internet Private Limited. These linked sites are only for your convenience and therefore you access them at your own risk. Nonetheless,
            Nirvaat Internet Private Limited seeks to protect the integrity of its website and the links placed upon it and therefore requests any feedback on not only its own site,
            but for sites it links to as well (including if a specific link does not work).
        </p>

        <b>Governing Law and Jurisdiction</b>
        <p>
            Country of merchant domicile: Uttar Pradesh, India<br>
            Any dispute or claim arising out of or in connection with this website shall be governed and construed in accordance with the laws of Government of India.
        </p>
        <p>
            Nirvaat Internet Private Limited and/or their affiliates ("PropertyShops.in") provide website features, payments solutions, Intellectual property, and other products
            and services to you when you visit or shop at Nirvaat Internet Private Limited websites (the "website"). Nirvaat Internet Private Limited provides logistics solutions.
            All sales/invoices on the PropertyShops.in websites are provided by Nirvaat Internet Private Limited.
        </p>
    </div>
</div>
@stop