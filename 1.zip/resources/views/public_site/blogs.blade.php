@extends('layouts.public')
@section('title', 'Blogs')

@section('content')
    <div class="flex bg-gray-50 h-full py-24 bg-lime-100 justify-center">
        <div class="w-5/6 bg-white rounded-lg shadow p-4 static-page">
            <h1
                class="mb-4 text-center pt-3 text-3xl font-extrabold leading-none tracking-tight text-gray-900 md:text-5xl lg:text-4xl">
                Recent <mark class="px-2 text-white rounded" style="background: #84cc16">Blogs</mark></h1>
            <div class="p-10 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-2 gap-10">
                {{-- card --}}
                @if (count($blogs) > 0)
                    @foreach ($blogs as $blog)
                        <div class="w-full lg:max-w-full lg:flex border border-gray-400">
                            @if ($blog->image ?? '')
                                <div class="h-48 bg-center lg:h-auto lg:w-48 flex-none bg-cover rounded-t lg:rounded-t-none lg:rounded-l text-center overflow-hidden blog-image"
                                    style="background-image: url({{ url('/files/blogs/') }}/{{ $blog->slug }}/{{ $blog->image }});background-repeat: no-repeat; 
                            ">
                                </div>
                            @endif
                            <div class="w-full lg:max-w-full bg-white rounded-b p-4 flex flex-col justify-between leading-normal"
                                style="min-height: 230px;">
                                <div>
                                    <div class="text-gray-900 font-bold text-xl mb-2"><a
                                            href="{{ url('/blog' . '/' . $blog->slug) }}">{{ $blog->title }}</a></div>
                                    <p class="text-gray-700 text-base"style="
                                        overflow: hidden;
                                        text-overflow: ellipsis;
                                        display: -webkit-box;
                                        -webkit-line-clamp: 4;
                                        -webkit-box-orient: vertical;
                                        ">
                                        {{ strip_tags($blog->description) }}</p>
                                </div>
                                <div class="flex flex-col items-start gap-2">
                                    <a href='{{ url('/blog' . '/' . $blog->slug) }}'
                                        class="inline-flex items-center font-medium text-gray-700 hover:underline">Read
                                        More<svg class="ml-2 w-4 h-4" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg></a>
                                    <div class="px-0 text-xs flex mt-2">
                                        <p class="text-gray-500 mr-24">
                                            <b>Published:</b> {{ date('j M, Y h:m', strtotime($blog->published_at)) }} IST,
                                            <b>Views:</b> {{ $blog->views }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @endif
            </div>
            <div class="row">
                <div class="col-md-12">
                    {{ $blogs->appends(request()->query())->links() }}
                </div>
            </div>
        </div>
    </div>
@stop
