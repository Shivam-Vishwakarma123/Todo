@extends('layouts.public')
@section('title', 'Agents')

@section('content')
<section class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
    <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto justify-center">
        {{-- adding sorting --}}
        <p class="ap-pricesort mb-4">
            @sortablelink('Recent')
        </p>
        <br><br>
        <h1 class="text-xl md:text-3xl">
            Listing of All Agents
        </h1>
        <h2 class="my-3">
            {{-- to display total number of agents --}}
            Total {{ count($agents) }} Agents Found
                </h2>
        <div class="grid md:max-xl:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-4 gap-2 mx-auto">
            @foreach($agents as $agent)
            {{-- component called to show property details cards --}}
            <x-agent-card :agent="$agent"></x-agent-card>
            @endforeach
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                {{ $agents->appends(request()->query())->links() }}
            </div>
        </div>

    </div>
</section>
@stop