@extends('layouts.public')
@section('title', 'Privacy Policy')

@section('content')
<div class="flex bg-gray-50 h-full py-24 bg-lime-100 justify-center">
    <div class="w-5/6 bg-white rounded-lg shadow p-4 static-page">
        <h1 class="text-center text-2xl">Privacy Policy</h1>
        <p>
            Nirvaat Internet Private Limited the owner and operator of website "PropertyShops.in" care about you and your private information shared with us.
            We appreciate your trust in us for this. This page describes the Privacy Policy of PropertyShops.in ('Website').
            By using this Website, you accept and agree to the practices described in this Privacy Policy.
        </p>
        <p>
            By use of the Website, you expressly consent to our use and disclosure of your personal information in accordance with this Privacy Policy.
            This Privacy Policy is incorporated into and subject to the <a href="/pages/terms-and-conditions">Terms of Use</a>.
        </p>
        <ol>
            <li>
                <b>Collection of Personally Identifiable Information</b>
                <p>
                    While you use our Website, at times we collect and store personal information that is provided by you.
                    We use this information to create for you a safe, efficient, smooth and customized experience.
                    We collect personal information from you which is minimum to make this website work to service you and make it easier for you to place order.
                </p>
                <p>
                    In general, you can browse the Website without telling us who you are or revealing any personal information about yourself.
                    Where possible, we indicate which fields are required and which fields are optional.
                    You always have the option to not provide information by choosing not to use a particular service or feature on the Website.
                </p>
                <p>
                    For certain features to work, we may automatically track certain annonymous information about your behaviour on our Website.
                    This information may include the URL you just came from (whether this URL is on our Website or not), which URL you go to next
                    (whether this URL is on our Website or not), your computer browser information and your IP address.
                    This information is compiled and analysed on an aggregated basis, and we use it for internal research on our users' demographics, interests and behaviour to better understand, protect and serve our users.
                </p>
                <p>
                    We use data collection technologies such as ‘cookies’ on certain pages of the Website to help analyse our web page flow and
                    measure promotional effectiveness.
                    Cookies are small files placed on your hard drive that help us provide our services when you use our Website.
                    We offer certain features that are only available through the use of cookies.
                </p>
                <p>
                    Although we try to minimize third party integrations except payment gateways to process payment for your orders.
                    But sometimes, you may encounter cookies or other similar devices on certain pages of the Website that are placed by these third party sites.
                    We do not control the use of cookies by third parties.
                </p>
                <p>
                    If you want to place an order with us, then some additional information such as a billing address, shipping address are stored on our website.
                    Some other information about your credit/debit card number and expiration date, and/ or other payment instrument details may be collected by our
                    service provider that performs the function of a payment gateway.
                </p>
                <p>
                    If you choose to post messages on our message boards, chat rooms or other message areas or leave feedback, we will collect that information
                    you provide to us. We retain this information as necessary to resolve disputes, provide customer support and troubleshoot problems as permitted by law.
                </p>
                <p>
                    If you send us personal correspondence, such as emails or letters, or if other users or third parties send us correspondence about your activities or
                    postings on the Website, we may collect such information into a file specific to you.
                </p>
            </li>

            <li>
                <b>Use of Demographic Data, Profile Data and Your Information</b>
                <p>
                    In our efforts to continually improve our product and service offerings, we collect and analyse demographic and profile data about our users' activity on our Website.
                </p>
                <p>
                    We identify and use your IP address to help diagnose problems with our server and to administer our Website. Your IP address is also used to help identify
                    you and to gather broad demographic information.
                </p>
            </li>
            <li>
                <b>Sharing of Personal Information</b>
                <p>
                    We may share personal information with our shipping partners to enable them to deliver your ordered items.
                    These entities and affiliates may market to you as a result of such sharing unless you explicitly opt out.
                </p>
                <p>
                    We may disclose personal information if required to do so by law or in the good faith belief that such disclosure is reasonably necessary to respond
                    to court orders or other legal process. We may disclose personal information to law enforcement offices, third-party-rights owners or others in the good
                    faith belief that such disclosure is reasonably necessary to: enforce our Terms &amp; Conditions or Privacy Policy; respond to claims that an advertisement,
                    posting or other content violates the rights of a third party; protect the rights, property or personal safety of our users or the general public.
                </p>
                <p>
                    We and our affiliates will share/provide some or all of your personal information with another business entity should we (or our assets) plan to merge
                    with, or be acquired by that business entity, or in the case of re-organization, amalgamation or restructuring of business. Should such a transaction occur,
                    that other business entity (or the new combined entity) will be required to follow this Privacy Policy with respect to your personal information.
                </p>
            </li>
            <li>
                <b>Links to Other Sites</b>
                <p>
                    If you visit any other website links provided on our webiste, which are not owned and operated by us then these websites may collect personally identifiable
                    information about you, based on their privacy policy and terms of use. Our Website is not responsible for the privacy practices or the content of those linked websites.
                </p>
            </li>
            <li>
                <b>Security Precautions</b>
                <p>Our Website has stringent security measures in place to protect the loss, misuse and alteration of the information under our control.
                    Whenever you change or access your account information, we offer the use of a secure server. Once your information is in our possession we adhere
                    to strict security guidelines, protecting it against unauthorized access.
                </p>
            </li>
            <li>
                <b>Opt-Out Choices</b>
                <p>
                    Although we send minimum communications for marketing and promotions, we provide you with the opportunity to opt out of receiving non-essential
                    (promotional, marketing-related) communications from us.
                </p>
            </li>
            <li>
                <b>Your Consent</b>
                <p>By using the Website and/or providing your information, you consent to the collection and use of the information you disclose on the Website in
                    accordance with this Privacy Policy, including but not limited to your consent for sharing your information according to this Privacy Policy.
                </p>
                <p>
                    If we decide to change our Privacy Policy, we will post those changes on this page so that you are always aware of what information we collect,
                    how we use it, and under what circumstances we disclose it.
                </p>
            </li>
            <li>
                <b>Inquiries, Concerns and Grievances</b>
                <p>Should you have any concerns, grievances or issues with the use of the Website, the products sold, any related services, or this Privacy Policy,
                    you can write to us at cs@propertyshops.in with a thorough description, and we will try to resolve the issue for you.
                </p>
            </li>
        </ol>
    </div>
</div>
@stop