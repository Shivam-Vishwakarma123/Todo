@extends('layouts.public')
@section('title',($search_data['sale_rent'] == 'Sale' ?'Buy': 'Rent').' Properties at '.$search_data['city'])

@section('content')
<section class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
    <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <h1 class="text-xl md:text-2xl">
                {{$search_data['sale_rent']}}
                Properties listed for <u>{{ $search_data['city'] }}</u> city
            </h1>
            <p class="my-3">
                {{-- to display total number of properties found --}}
                Total {{ count($propertie) }} Properties Found
            </p>
            <div class="grid gap-2 property_listing">
                @foreach($propertie as $property)
                {{-- to set the width of each card on display --}}
                @php $width  = ''; @endphp
                {{-- component called to show property details cards --}}
                <x-property-card :property="$property" :width="$width" ></x-property-card>
                @endforeach
            </div>
    </div>
</section>
@stop