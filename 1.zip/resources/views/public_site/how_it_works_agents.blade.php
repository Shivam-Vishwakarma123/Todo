@extends('layouts.public')
@section('title', 'How it Works for Agents')

@section('content')
    <div class="ag-container">
        <div class="ag-main-container container sm:mx-auto px-6">

            <div>
                <div class="ag-heading-div">
                    <br>
                    <h1>How it works
                        <br>
                        <span>How could an agent use this website efficiently</span>
                    </h1>
                </div>
                <br>
                <br>
                <section class="ag-signin-section ">
                    <h2 class="text-2xl font-bold">Signin/SignUp</h2>
                    <p class="mt-4">Agent needs to signup or signin in order to see the dashboard</p>
                    <br>
                    <div class="ag-signin-container grid grid-cols-2 gap-6">
                        <div class="ag-signin">
                            <div class="ag-signin-img">
                                <img src="{{ url('/images/agentUse/signin.png') }}" alt="Sign In Page" />
                            </div>
                            <div class="ag-signin-content">
                                <p class="mt-2 text-center">Validate your number</p>
                            </div>
                        </div>
                        <div class="ag-signin-otp">
                            <div class="ag-signin-img">
                                <img src="{{ url('/images/agentUse/signin-otp.png') }}" alt="Sign In Page" />
                            </div>
                            <div class="ag-signin-content">
                                <p class="mt-2 text-center">Enter the received OTP. You'll be directed to the
                                    dashboard page.
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="ag-dashboard">
                    <div class="ag-dashboard-container">
                        <h3 class="text-2xl font-bold">Dashboard</h3>
                        <p class="my-4">This is the page you'll see after you sign in for the first time. </p>
                        <img src="{{ url('/images/agentUse/dashboard.png') }}" alt="Dashboard">
                    </div>
                    <p class="mt-2">You'll receive 5 credits on inviting 5 people.</p>
                    <p>In this you'll see different options.</p>

                    <div class="ag-new-property">
                        <h3 class="text-2xl mt-8 font-bold">New Property</h3>
                        <p>Click on <b>Create New Property</b> to add your property</p>
                        <img src="{{ url('/images/agentUse/create-new-property.png') }}" alt="">
                        <p class="mt-2">Fill in the details of the property and click on <b>Save & Next</b></p>
                        <br>
                        <p> <b> After the property is created you'll see this page.</b></p>
                        <img src="{{ url('/images/agentUse/after-create-property.png') }}" alt="">
                        <br>
                        <h3 class="ag-sidebar text-2xl font-bold">SideBar</h3>
                        <p>Let's discuss all the links.</p>
                        <img src="{{ url('/images/agentUse/property-sidebar.png') }}" alt=""
                            class="ag-property-sidebar">
                        <br>
                        <h3 class="text-2xl font-bold">1. Details</h3>
                        <p>It contains the details of your property, you can change and save them.
                        </p>
                        <img src="{{ url('/images/agentUse/details-property.png') }}" alt="">
                        <br>
                        <h3 class="text-2xl font-bold">2. Description</h3>
                        <p>In this you can add the detail description of your property.</p>
                        <img src="{{ url('/images/agentUse/after-create-property.png') }}" alt="Description">
                        <br>
                        <h3 class="text-2xl font-bold">3. Amenities</h3>
                        <p>You can either choose the amenities that you have or add your own.</p>
                        <img src="{{ url('/images/agentUse/amenities-property.png') }}" alt="Amenities">
                        <br>
                        <h3 class="text-2xl font-bold">4. Price and Features</h3>
                        <p>You can add the price of your property and different features it has like the
                            number of bedrooms, bathrooms, balconies, etc.</p>
                        <img src="{{ url('/images/agentUse/price-features-property.png') }}" alt="Price and Features">
                        <br>
                        <h3 class="text-2xl font-bold">5. Photos Library</h3>
                        <p>Add the pictures of your property or the nearby places(if you want.)</p>
                        <img src="{{ url('/images/agentUse/photo-library.png') }}" alt="Price and Features">
                        <br>
                        <h3 class="text-2xl font-bold">6. Videos</h3>
                        <p>Upload Video of the property.</p>
                        <img src="{{ url('/images/agentUse/videos-property.png') }}" alt="Price and Features">
                        <br>
                        <h3 class="text-2xl font-bold">7. Default Url</h3>
                        <p>Share the url of your property on different social media platforms.
                        </p>
                        <img src="{{ url('/images/agentUse/default-url.png') }}" alt="">
                        <br>
                        <h3 class="ag-heading text-3xl">After creating the Property, Dashboard will have that property with
                            several actions</h3>

                        <p>You can <b>Edit</b>, <b>Preview</b>, <b>Publish</b> and <b>Delete</b> the
                            property.</p>
                        <p>With the Property <b>Preview</b>, only you can see your property untill you publish it.</p>
                        <img src="{{ url('/images/agentUse/property-added.png') }}" alt="">
                        <p class="mt-2 mb-0">Let's talk about <b>Publish</b> action.</p>
                        <p class="mb-0">You can only publish your property with credits</p>
                        <p>Each published property will take one credit and it will be deducted from your
                            credit balance</p>
                        <div class="ag-credits mt-10">
                            <h3 class="text-2xl font-bold">Credits</h3>
                            <p>Credits help you to publish your property. 1 free credit will be provided
                                when you first signup in the site.</p>
                            <p>An agent can buy as many credits as he wants.</p>
                            <p>The <b>Buy More Credits</b> button will take you to the page where different
                                credit plans are available.</p>
                            <img src="{{ url('/images/agentUse/buy-more-credit.png') }}" alt="">
                            <p class="mt-2">In order to publish your property an agent needs to have credits. </p>
                        </div>

                        <h3 class="text-xl">After selecting the plan.</h3>
                        <p>You need to pay the amount as per your choosen plan.</p>
                    </div>
                </section>
                <br>
                <section class="ag-navbar">
                    <div class="ag-navbar-container ">
                        <hr><br>
                        <h3 class="ag-heading text-xl">Let's Discuss the navbar</h3>
                        <img src="{{ url('/images/agentUse/agent-navbar.png') }}" alt="">
                        <br>
                        <p>We have already seen the Dashboard</p>
                        <h3 class="text-2xl font-bold">Manage Properties</h3>
                        <img src="{{ url('/images/agentUse/manage-properties.png') }}" alt="">
                        <p class="mt-2">It will contain all your properties details.</p>

                        <h3 class="text-2xl font-bold">Visit Stats</h3>
                        <img src="{{ url('/images/agentUse/visit-stats.png') }}" alt="">
                        <p class="mb-1">This page illustrates the number of visitors on your published properties.</p>
                        <p class="mt-2">You can also modify the date.</p>

                        <h3 class="text-2xl font-bold">Contact Requests</h3>
                        <img src="{{ url('/images/agentUse/contact-requests.png') }}" alt="">
                        <p class="mb-1">The users who are interested in your property and want to contact you.</p>
                        <p class="mt-2">The list of those users will be here.</p>

                        <h3 class="mt-8 text-2xl font-bold">Billing</h3>
                        <img src="{{ url('/images/agentUse/billing.png') }}" alt="">
                        <p class="mt-2">All your credits that you have bought will come here.</p>
                        <h3 class="mt-8 text-2xl font-bold">Profile</h3>
                        <img src="{{ url('/images/agentUse/profile.png') }}" alt="">
                        <ul class="px-5 mt-4">
                            <li>Upload your profile picture.</li>
                            <li>Upload your Logo.</li>
                            <li>Add your details(Name, Email, Phone Number).</li>
                            <li>You can create your own personal unique url which you can share.</li>
                            <li>Add your address.</li>
                            <li>Add your social media profiles (Facebook, Instagram, LinkedIn, etc).</li>
                            <li>You can share the qr code instead of the url of your profile.</li>
                        </ul>
                        <br>
                    </div>
                </section>
            </div>
        </div>
    </div>
@stop
