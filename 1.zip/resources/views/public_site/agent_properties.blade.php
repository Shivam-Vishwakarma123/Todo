@extends('layouts.public')
@section('title', 'Properties listed by '.$agent->first_name.' '.$agent->last_name)

@section('content')
    <section class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="flex gap-4 flex-wrap mb-10">
                <p class="ap-pricesort flex gap-2">
                    @sortablelink('Price')
                </p>
                <p class="ap-pricesort flex gap-2">
                    @sortablelink('Popularity')
                </p>
                <p class="ap-pricesort flex gap-2">
                    @sortablelink('Recent')
                </p>
                <div class="flex flex-wrap">
                    <div class="relative w-32 mr-2">
                        <?php  if(!(isset($_GET['sale_rent']))){?>
                        <!-- Dropdown menu -->
                        <select data-te-select-init class="rounded-md w-32 p-2 ap-pricesort pl-4"
                            style="border:none;text-align:start;font-size:15px;" id="type" name="type"
                            onChange="window.open(this.value, '_parent')">
                            <option value="{{ url('/properties/listing/All?sort=Recent&direction=asc') }}"
                                {{ $type == 'All' ? 'selected' : '' }}>All</option>
                            <option value="{{ url('/properties/listing/Rent?sort=Recent&direction=asc') }}"
                                {{ $type == 'Rent' ? 'selected' : '' }}>Rent</option>
                            <option value="{{ url('/properties/listing/Sale?sort=Recent&direction=asc') }}"
                                {{ $type == 'Sale' ? 'selected' : '' }}>Sale</option>
                        </select>
                        <?php }?>
                    </div>

                </div>

            </div>

            <h1 class="text-xl md:text-2xl mb-2">
                Properties listed by "{{ $agent->first_name . ' ' . $agent->last_name }}"
            </h1>
            <div class="">
                <div class="flex  rounded-md agent-details" style="background:#ffffff6e;">
                    <div class="flex flex-col justify-center h-44 py-4" style="width:20%">
                        @if ($agent->profile_image != '')
                            <img src="{{ url('/files/agents/') }}/{{ $agent->id }}/{{ $agent->profile_image }}"
                                alt="Agent Image" class="h-full" style="object-fit:contain;">
                        @else
                            <img src="{{ url('/images/logo1.png') }}" class="h-full " alt="Agent Image"
                                style="object-fit:contain;">
                        @endif
                    </div>
                    <div class="border-l-4 flex flex-col justify-center px-4 xs:w-full"
                        style="border-color: #6064681c;width:40%">
                        <div class="inline-block">
                            <p class="font-semibold text-lg">Contact Details</p>
                            @if ($agent->address != '' || $agent->state_name !== '' || $agent->city_name !== '')
                                <p><b>Located:</b> {{ $agent->address }}, {{ $agent->city_name }}, {{ $agent->state_name }}</p>
                            @endif
                            @if (!$agent->dummy_record)
                                <p><b>Phone : </b><a href="tel:{{ $agent->phone }}" class="underline">
                                        {{ $agent->phone }}</a>
                                </p>
                                @if ($agent->whatsapp_no != '')
                                    <a href="https://wa.me/+91{{ $agent->whatsapp_no }}" class="underline">Message on
                                        Whatsapp</a>
                                @endif
                            @endif

                        </div>
                    </div>
                    <div class="border-l-4 flex flex-col justify-center px-4" style="border-color: #6064681c; width:40%">
                        <div class="inline-block py-4">
                            <p class="font-semibold text-lg">Fee Details</p>
                            <div class="flex gap-2">
                                <p>For Sale : </p>
                                @if ($agent->sale_fee_type && $agent->sale_fee_amount)
                                    <p>{{ $agent->sale_fee_amount }} [{{ $agent->sale_fee_type }}]</p>
                                @else
                                    <p>Contact Agent</p>
                                @endif
                            </div>
                            <div class="flex gap-2">
                                <p>For Rent : </p>
                                @if ($agent->rent_fee_type && $agent->rent_fee_amount)
                                    <p>{{ $agent->rent_fee_amount }} [{{ $agent->rent_fee_type }}]</p>
                                @else
                                    <p>Contact Agent</p>
                                @endif
                            </div>
                            <div class="">
                                <ul class="flex gap-2 text-lg py-2 social-media-agent">
                                    @if (!is_null($agent->facebook_profile))
                                        <li>
                                            <a href="/{{ $agent->facebook_profile }}"
                                                class="facebook cursor-pointer hover:bg-red" target="_blank">
                                                <i class="fab fa-facebook-f "></i>
                                            </a>
                                        </li>
                                    @endif

                                    @if (!is_null($agent->instagram_profile))
                                        <li>
                                            <a href="{{ $agent->instagram_profile }}" class="instagram cursor-pointer"
                                                target="_blank">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                        </li>
                                    @endif

                                    @if (!is_null($agent->twitter_profile))
                                        <li>
                                            <a href="{{ $agent->twitter_profile }}" class="twitter cursor-pointer"
                                                target="_blank">
                                                <i class="fab fa-twitter"></i>
                                            </a>
                                        </li>
                                    @endif
                                    @if (!is_null($agent->linkedin_profile))
                                        <li>
                                            <a href="{{ $agent->linkedin_profile }}" class="linkedin cursor-pointer"
                                                target="_blank">
                                                <i class="fab fa-linkedin-in"></i>
                                            </a>
                                        </li>
                                    @endif
                                    @if (!$agent->dummy_record)
                                        @if (!is_null($agent->whatsapp_no))
                                            <li>
                                                <a href="https://wa.me/+91{{ $agent->whatsapp_no }}"
                                                    class="whatsapp cursor-pointer" target="_blank">
                                                    <i class="fab fa-whatsapp"></i>
                                                </a>
                                            </li>
                                        @endif
                                    @endif
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="my-3 mt-3">Total <b>{{ $count }}</b> Properties Found</div>
            <div class="grid gap-2 property_listing">
                @foreach ($propertie as $property)
                    {{-- to set the width of each card on display --}}
                    @php $width = ''; @endphp
                    {{-- component called to show property details cards --}}
                    <x-property-card :property="$property" :width="$width"></x-property-card>
                @endforeach
            </div>
            <div class="row">
                <div class="col-md-12">
                    {{ $propertie->appends(request()->query())->links() }}
                </div>
            </div>
        </div>
    </section>
@stop
