@extends('layouts.public')
@section('title', 'User SignUp')

@section('content')
<div class="flex bg-gray-50 h-full py-24 bg-lime-100">
    <div class="w-5/6 md:w-1/2 mx-auto p-5 h-fit mb-5 mt-10 bg-white rounded-lg shadow">
        <h1 class="text-xl md:text-3xl font-bold text-center mb-6">Sign Up As User</h1>
        <br />
        <form action="{{url('user/user-sign-up')}}" method="post" id="signUp">
            @csrf
            <div class="grid gap-2 mb-6 md:grid-cols-1">
                <div>
                    <label for="user_name" class="block mb-2 text-sm font-medium text-gray-900 ">User Name *</label>
                    <div class="relative mb-6">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5 text-gray-500 ">
                                <path d="M10 8a3 3 0 100-6 3 3 0 000 6zM3.465 14.493a1.23 1.23 0 00.41 1.412A9.957 9.957 0 0010 18c2.31 0 4.438-.784 6.131-2.1.43-.333.604-.903.408-1.41a7.002 7.002 0 00-13.074.003z" />
                            </svg>
                        </div>
                        <input type="text" id="user_name" name="user_name" maxlength="100" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " @if(isset($user_name)) value={{$user_name}} @endif required>
                    </div>
                    <small id="user_namehelp" class="text-red-700 font-bold">@error('user_name'){{$message}}@enderror</small>
                </div>

                <div>
                    <label for="phone" class="block mb-2 text-sm font-medium text-gray-900 ">Phone * <small>[Verified number, Not editable]</small></label>
                    <div class="relative mb-6">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5 text-gray-500 ">
                                <path fill-rule="evenodd" d="M2 3.5A1.5 1.5 0 013.5 2h1.148a1.5 1.5 0 011.465 1.175l.716 3.223a1.5 1.5 0 01-1.052 1.767l-.933.267c-.41.117-.643.555-.48.95a11.542 11.542 0 006.254 6.254c.395.163.833-.07.95-.48l.267-.933a1.5 1.5 0 011.767-1.052l3.223.716A1.5 1.5 0 0118 15.352V16.5a1.5 1.5 0 01-1.5 1.5H15c-1.149 0-2.263-.15-3.326-.43A13.022 13.022 0 012.43 8.326 13.019 13.019 0 012 5V3.5z" clip-rule="evenodd" />
                            </svg>
                        </div>
                        <input type="text" id="phone" name="phone" maxlength="10" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " value="{{ $phone }}" readonly>
                    </div>
                </div>
            </div>

            <button type="submit" class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Sign Up</button>
            <button type="reset" class="bg-amber-500 mb-10 hover:bg-amber-600 focus:ring-4 focus:outline-none focus:ring-amber-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Reset</button>
        </form>
    </div>
</div>
@stop