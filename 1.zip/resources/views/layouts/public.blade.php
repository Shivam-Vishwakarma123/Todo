<!doctype html>
<html lang="en" dir="ltr" class="h-full bg-gray-100">

<head>
    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=1, maximum-scale=5'>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description"
        content="Portal for Property dealers to publish their property, Real Estate portal for Profesionals.">
    <meta name="keywords" content="Real Estate, Property Dealers, Search Properties, Buy Sell house, flats etc.">
    <meta name="author" content="Nirvaat Internet Private Limited">
    <meta name="csrf-token" content="{{ csrf_token() }}">


    <!-- TITLE -->
    <title>@yield('title') - Property Shops</title>

    <!-- FAVICON -->
    <link rel="icon" href="{{ url('/images/favicon-48x48.ico') }}">

    <!-- flowbite css -->
    <link rel="stylesheet" href="{{ url('css/flowbite.min.css') }}" />
    <link href="{{ url('css/fontawesome.min.css') }}" rel="stylesheet" />
    <link href="{{ url('css/app.css') }}" rel="stylesheet" />
    <!-- CUSTOM CSS -->
    <link href="{{ url('css/public-custom.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="{{ url('css/custom.css') }}" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

    <!-- Jquery link -->
    <script src="{{ url('js/jquery.min.js') }}"></script>

    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script src="{{ url('js/PullToRefresh.js') }}?t=123"></script>
    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/8.3.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.3.0/firebase-messaging.js"></script>
    

    <script>
        const navigator = window.navigator;
        const userAgent = navigator.userAgent;
        const normalizedUserAgent = userAgent.toLowerCase();
        const standalone = navigator.standalone;

        const isIos = /ip(ad|hone|od)/.test(normalizedUserAgent) || navigator.platform === 'MacIntel' && navigator
            .maxTouchPoints > 1;
        const isAndroid = /android/.test(normalizedUserAgent);
        const isSafari = /safari/.test(normalizedUserAgent);
        const isWebview = (isAndroid && /; wv\)/.test(normalizedUserAgent)) || (isIos && !standalone && !isSafari);

        // if not webview
        if (!isWebview) {

            // Your web app's Firebase configuration
            var firebaseConfig = {
                apiKey: "AIzaSyBrjNp9pWAuaoED41pJm8OFnm1nIKfNqlQ",
                authDomain: "propertyshops-testing.firebaseapp.com",
                projectId: "propertyshops-testing",
                storageBucket: "propertyshops-testing.appspot.com",
                messagingSenderId: "186312166603",
                appId: "1:186312166603:web:1de259d97b35052dd71f4e",
            };
            firebase.initializeApp(firebaseConfig);

            const messaging = firebase.messaging();
            navigator.serviceWorker.register('../public/firebase-messaging-sw.js')
                .then((registration) => {
                    messaging.useServiceWorker(registration);
                    // Request permission and get token.....
                    function initFirebaseMessagingRegistration() {
                        messaging.requestPermission().then(function() {
                            return messaging.getToken()
                        }).then(function(token) {
                            axios.post("{{ route('fcmToken') }}", {
                                _method: "PATCH",
                                token
                            }).then(({
                                data
                            }) => {
                                console.log(data)
                            }).catch(({
                                response: {
                                    data
                                }
                            }) => {
                                console.error(data)
                            })

                        }).catch(function(err) {
                            console.log(`Token Error :: ${err}`);
                        });
                    }

                    initFirebaseMessagingRegistration();
                });


            messaging.onMessage(function(payload) {
                const noteTitle = payload.notification.title;
                const noteOptions = {
                    body: payload.notification.body,
                    icon: payload.notification.icon,
                };
                new Notification(noteTitle, noteOptions);
            });
        }
    </script>


    <script>
        /* Public URL of the website use in JS - web_url */
        @php
            echo "web_url = \"" . URL::to('/') . "\";";
        @endphp
    </script>
    <?php 
    if($_SERVER["SERVER_NAME"] != "localhost" && strpos($_SERVER["SERVER_NAME"], "192.168") === false && $_SERVER["REMOTE_ADDR"] != "61.247.238.175") {
        ?>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-9347CDELHT"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-9347CDELHT');
    </script>
    <?php 
    }
    ?>
    @php
        // check if mobile or not
        $device = new \Jenssegers\Agent\Agent();
        $mobile = $device->isMobile();
    @endphp
</head>

<body class="h-full">
    @include('flash-message')
    <header>
        <nav class="navbar bg-white border-gray-200 px-4 lg:px-6 py-2 fixed w-full z-20 top-0 left-0">
            <div class="container sm mx-auto">
                <div class="wrapper flex flex-wrap justify-between items-center">
                    <a href="{{ url('/') }}" class="brand">
                        <img src="{{ url('/images/logo-hb.png') }}" class="mr-3 h-14" alt="Property Shops">
                    </a>
                    <!-- hamburger menu -->
                    <span class="burger" id="burger">
                        <span class="burger-line"></span>
                        <span class="burger-line"></span>
                        <span class="burger-line"></span>
                        <span class="burger-line"></span>
                    </span>
                    <!-- menu-links -->
                    <div class="menu" id="menu">
                        <ul class="menu-inner flex justify-center align-items-center flex-row gap-6">
                            <li class="menu-item"><a href="{{ url('/') }}"
                                    class="menu-link font-medium pb-1 hover-underline">Home</a></li>
                            <li class="menu-item"><a href="{{ url('/agents/listing?sort=Recent&direction=asc') }}"
                                    class="menu-link font-medium pb-1 hover-underline">Agents</a></li>
                            <li class="menu-item"><a
                                    href="{{ url('/properties/listing/All?sort=Recent&direction=asc') }}"
                                    class="menu-link font-medium pb-1 hover-underline">Properties</a></li>
                            <li class="menu-item"><a href="{{ url('agent/sign-in') }}"
                                    class="menu-link font-medium pb-1 hover-underline">
                                    @if (session()->has('agent'))
                                        My Account
                                    @elseif (session()->has('user'))
                                        User Account
                                    @else
                                        Sign In
                                    @endif
                                </a></li>
                            <li class="menu-item"><a href="{{ url('plan-details') }}"
                                    class="menu-link font-medium pb-1 hover-underline">Pricing</a></li>

                            <li class="menu-item"><a href="{{ url('/contact-us') }}"
                                    class="menu-link font-medium pb-1 hover-underline">Contact Us</a></li>
                            <li class="menu-item"><a href="{{ url('blog') }}"
                                    class="menu-link font-medium pb-1 hover-underline">Blog</a></li>
                            @if ($mobile)
                                <li class="menu-item"><a href="{{ url('/usage-terms') }}"
                                        class="menu-link font-medium pb-1 hover-underline">Usage Terms</a></li>
                            @endif
                            <li class="menu-item">
                                <button id="dropdownNavbarLink" data-dropdown-toggle="dropdownNavbar"
                                    class="flex items-center justify-between w-full text-gray-600 menu-link font-medium pb-1">
                                    How it Works
                                    <svg class="w-2.5 h-2.5 ml-2.5" aria-hidden="true"
                                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="2" d="m1 1 4 4 4-4" />
                                    </svg></button>
                                <!-- Dropdown menu -->
                                <div id="dropdownNavbar"
                                    class="z-10 hidden font-normal bg-white divide-y divide-gray-100 rounded-lg shadow w-44  ">
                                    <ul class="py-2 text-sm text-gray-700 ">
                                        <li>
                                            <a href="{{ url('/how-it-works-agents') }}"
                                                class="font-medium text-lg pb-1 block px-6 py-2 hover:bg-gray-100 ">Agents</a>
                                        </li>
                                        <li>
                                            <a href="{{ url('/how-it-works-buyers') }}"
                                                class="font-medium text-lg pb-1 block px-6 py-2 hover:bg-gray-100 ">Users</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            @if ($mobile)
                                <li class="menu-item">
                                    <a href="https://play.google.com/store/apps/details?id=com.propertyshops.main"
                                        class="menu-link font-medium pb-1 hover:text-black underline" target="_blank">

                                        <svg width="140" height="45" xmlns="http://www.w3.org/2000/svg">
                                            <image href="{{ url('/images/play_store.svg') }}" width="140" />
                                        </svg>
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <main>
        @yield('content')
    </main>

    <!-- section footer start  -->
    @if (!$mobile)
        <section id="footer" class="">
            <div class=""
                style="background-image: url(https://www.radiustheme.com/demo/wordpress/themes/homlisti/wp-content/themes/homlisti/assets/img/footer-2-bg.jpg);">
                <div class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8">
                    <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
                        <div class="grid grid-cols-1 text-white md:grid-cols-3 m-1">
                            <div class="col-span-2 md:col-span-1">
                                <a href="{{ url('/') }}"><img style="max-width: 200px;"
                                        src="{{ url('/images/logo-vw.png') }}" alt=""></a>
                            </div>
                            <div class="hidden md:block">
                                <h2 class="text-base font-medium text-white">Download Now</h2>
                                <div class="border-b-4 rounded-full border-lime-600 pb-2 w-1/3"></div>
                                <br>
                                <a href="https://play.google.com/store/apps/details?id=com.propertyshops.main"
                                    class="menu-link font-medium pb-1 hover:text-black underline" target="_blank">
                                    <svg width="160" height="55" xmlns="http://www.w3.org/2000/svg">
                                        <image href="{{ url('/images/play_store.svg') }}" width="160" />
                                    </svg>
                                </a>
                            </div>

                            <div class="">
                                <h2 class="hidden md:block text-base font-medium text-white">Contact Us</h2>
                                <div class="hidden md:block border-b-4 rounded-full border-lime-600 pb-2 w-1/3"></div>
                                <div class="mt-5">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor"
                                        class="w-5 h-5 inline text-lime-500 p-px mr-1">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                                    </svg>
                                    Suite B12, BSI Business Park, 161 H Block, Sector 63, Noida
                                </div>
                                <div class="mt-5">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor"
                                        class="w-5 h-5 inline text-lime-500 p-px mr-1">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
                                    </svg>
                                    cs@propertyshops.in
                                </div>
                                <div class="mt-5">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor"
                                        class="w-5 h-5 inline text-lime-500 p-px mr-1">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                                    </svg>
                                    81302 48912 ( WhatsApp )
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-gray-600" style="background-color: #082039;">
                <div class="w-full text-white mx-auto p-5">
                    <div class="text-center">
                        <a href="{{ url('/terms-conditions') }}" class="hover:text-white mr-2"><span>Terms of
                                Use</span></a>
                        <a href="{{ url('/privacy-policy') }}" class="hover:text-white mr-2"><span>Privacy
                                Policy</span></a>
                        <a href="{{ url('/refund-terms') }}" class="hover:text-white mr-2"><span>Refund
                                Terms</span></a>
                        <a href="{{ url('/about-us') }}" class="hover:text-white mr-2"> About Us</a>
                        <a href="{{ url('/contact-us') }}" class="hover:text-white mr-2">Contact Us</a>
                    </div>

                    <div class="mt-4 text-center">
                        <span class="text-gray-300">&copy;
                            2023<?php echo date('Y') > 2023 ? ' - ' . date('Y') : ''; ?>
                            All right reserved. Made with <span style="color:red;">&hearts;</span> by <a
                                href="https://nirvaat.com" target="_blank">Nirvaat Internet Private Limited</a>
                        </span>
                    </div>
                </div>
            </div>
        </section>
    @endif
    <!-- section footer end  -->

    <!-- {{-- {{-to add search box suggestion list on public index page-  --}} -->
    <link href="https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
    <script src="https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    <!-- tailwind js -->
    <!-- <script src="{{ url('js/app.js') }}"></script> -->

    <!-- flowbite js -->
    <script src="{{ url('js/flowbite.min.js') }}"></script>

    <!-- Fontawesome link -->
    <script src="{{ url('js/fontawesome.min.js') }}"></script>

    <!-- function js -->
    <script src="{{ url('js/functions.js') }}?t=123"></script>

    <!-- CUSTOM JS -->
    <script src="{{ url('js/public-custom.js') }}?t=123"></script>

  
</body>

</html>

<script>
  PullToRefresh.init({
        mainElement: 'body',
        distMax: 120,
        onRefresh() {
          window.location.reload();
        }
    });
</script>