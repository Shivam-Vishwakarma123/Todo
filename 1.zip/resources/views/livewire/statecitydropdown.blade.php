
<div class= "grid gap-6 mb-6 md:grid-cols-2">
<div>
    <label class="block mb-2 text-sm font-medium text-gray-900 ">State</label>
    <select wire:model="state_id" wire:change="$emit('getStateCities', $event.target.value)"
        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   "
        name="state_id" id="state_id">
        @if(!$is_state)
        <option value="0">-- Select State --</option>
        @else
        <option value="{{$is_state->id}}" selected>{{$is_state->name}}</option>
        @endif
        @foreach($states as $state)
        <option value="{{ $state->id }}">{{ $state->name }}</option>
        @endforeach
    </select>
</div>
<div class="form-group">
    <label for="city_id" class="block mb-2 text-sm font-medium text-gray-900 ">City</label>
    <select wire:model="city_id"
    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   "
    name="city_id" id="city_id">
    @if(!$is_city)
    <option value="0">-- Select City --</option>
    @else 
    <option value="{{$is_city->id}}">{{$is_city->name}}</option>
    @endif
    @if(isset($cities))
    @foreach($cities as $city)
        <option value="{{ $city->id }}">{{ $city->name }}</option>
    @endforeach
    @endif
    </select>
</div>
</div>

