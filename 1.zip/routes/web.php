<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Agent\AddressController;
use App\Http\Controllers\Agent\AgentsController;
use App\Http\Controllers\UserDashboardController;
use App\Http\Controllers\Agent\PropertyController;
use App\Http\Controllers\Agent\PaymentsController;
use App\Http\Controllers\Agent\VideoController;
use App\Http\Controllers\Agent\TopbarsController;
use App\Http\Controllers\Agent\PropertyImagesController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\Backend\BlogsController;
use App\Http\Livewire\Statecitydropdown;
use App\Http\Controllers\NewImageController;

// Backend controller use start
use App\Http\Controllers\Backend\AdminsController;
use App\Http\Controllers\UserDasboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__ . '/auth.php';


Route::middleware('user')->group(function(){
    Route::get('/user/dashboard', [UserDashboardController::class, 'user_index']);
    // Route::namespace('Auth')->group(function(){
    //     Route::get('sign-out', 'AuthenticatedSessionController@destroy')->name('agentDestroy');
    // });
});


// Agent routes

Route::namespace('Agent')->prefix('agent')->name('agent.')->group(function () {
    Route::get('/', [AgentsController::class, 'agents']);
    
    
    Route::namespace('Auth')->middleware('guest:agent')->group(function () {
        Route::get('sign-in', 'AuthenticatedSessionController@create')->name('login');
        Route::post('sign-in', 'AuthenticatedSessionController@store')->name('agentLogin');
    });

    // Start User signin  / signup

    // Route::namespace('Auth')->middleware('guest:user')->group(function () {
    //     Route::get('sign-in', 'AuthenticatedSessionController@user_create')->name('login');
    //     Route::post('sign-in', 'AuthenticatedSessionController@user_store')->name('agentLogin');
    // });

    // Route::middleware('user')->group(function(){
    //     Route::prefix('user')->group(function(){  
    //         // Route::get('dashboard', 'UserDashboardController@index')->name('dashboard');
    //         Route::get('/dashborad', [UserDashboardController::class, 'user_index'])->name('dashboard');
    //     });
    // });
    
    // End User signin  / signup
    

    //Add login check for all Agent URLS inside this block
    Route::middleware('agent')->group(function(){
        Route::get('dashboard', 'DashboardController@index')->name('dashboard');
        Route::get('property-views',[PropertyController::class,'property_views']);
        Route::namespace('Auth')->group(function(){
            Route::get('sign-out', 'AuthenticatedSessionController@destroy')->name('agentDestroy');
        });
        Route::prefix('property')->group(function(){                                         // prefix-1
            Route::get('address', [PropertyController::class, 'address']);
            Route::get('address/{unique_url}', [PropertyController::class, 'address']);
            Route::get('listing-type', [PropertyController::class, 'listingType']);
            Route::get('amenities', [PropertyController::class, 'amenities']);
            Route::get('description', [PropertyController::class, 'description']);
            Route::get('price-feature', [PropertyController::class, 'priceFeature']);
            Route::get('default', [PropertyController::class, 'default']);
            Route::get('publish/{unique_url}' , [PropertyController::class, 'publish']);
            // to enable and disable property by agent after publish a property
            Route::get('status/{unique_url}' , [PropertyController::class, 'status']);
            // to delete a property
            Route::get('delete/{unique_url}' , [PropertyController::class, 'delete']);
            Route::get('listing', [PropertyController::class, 'listing']);
            Route::get('visit-stats', [PropertyController::class, 'visit_stats']);
            Route::get('property-views',[PropertyController::class,'property_views']);
            Route::post('store-address', [PropertyController::class, 'storeAddress']);
            Route::post('store-address/{data}', [PropertyController::class, 'storeAddress']);
            Route::post('store-amenities', [PropertyController::class, 'storeAmenities']);
            Route::post('store-description', [PropertyController::class, 'storeDescription']);
            Route::post('store-priceFeature', [PropertyController::class, 'storePriceFeature']);
            Route::post('store-listingType', [PropertyController::class, 'storeListingType']);
        });

         // Start Property Images Route ==============================================================
         Route::prefix('property-images')->group(function(){                                // prefix-2
           
            Route::post('save-images', [PropertyImagesController::class, 'storeImage']);
            Route::get('images', [PropertyImagesController::class, 'images']); 
            
            Route::get('images/{id}', [PropertyImagesController::class, 'images']);
            Route::get('delete-images/{id}', [PropertyImagesController::class, 'daleteImage']);
            Route::get('rotate-images/{id}', [PropertyImagesController::class, 'rotateImage']);
        });
        // End Property Images Route =================================================================

        
         // Start Property Video  Route ==============================================================
         Route::prefix('video')->group(function(){                                        // prefix-6
            Route::get('video', [VideoController::class, 'video']);
          //  Route::get('3d-video', [VideoController::class, 'ThreeD_video']);
            Route::post('save-video', [VideoController::class, 'saveVideo']);
            Route::post('save-url-video', [VideoController::class, 'Save_Url_Video']);
            Route::get('delete-video/{id}', [VideoController::class, 'deleteVideo']);
            Route::get('cover-video', [VideoController::class, 'coverVideo']);
            Route::get('feature-video', [VideoController::class, 'featureVideo']);
         
        });
        // End Property Video  Route =================================================================
            
        // Start Property topbar choose section                                         // prefix-7
        Route::prefix('property-topbar')->group(function(){
          
            Route::get('feature-image', [TopbarsController::class, 'featureImage']);
            Route::get('feature-slider',[TopbarsController::class, 'featureSlider']);
            Route::get('selection-for-top', [TopbarsController::class, 'selectionForTop']);
        });
        // End Property topbar choose section

         // Start Property Address Route ==============================================================
         Route::prefix('address')->group(function(){                                   // prefix-8
          
            Route::get('update-address-map', [AddressController::class, 'updateAddressMap']);
        });
        // End Property Address Route =================================================================

        // Agent Profile Route
                                                                                       //prefix-9
        Route::get('profile', [AgentsController::class, 'profile']);
        Route::post('edit-profile-details', [AgentsController::class, 'editProfileDetails']);
        Route::post('brokerage-fee',[AgentsController::class,'brokerageFee']);
        Route::post('edit-profile-address', [AgentsController::class, 'editProfileAddress']);
        Route::post('edit-profile-image', [AgentsController::class, 'editProfileImage']);   
        Route::post('add-social-media-profile', [AgentsController::class, 'AddSociaMediaProfile']);  
        Route::get('delete-profile-image', [AgentsController::class, 'deleteProfileImage']);
        Route::post('edit-logo-image', [AgentsController::class, 'editLogoImage']);  
        Route::get('delete-logo-image', [AgentsController::class, 'deleteLogoImage']);   
        Route::get('credit-plans', [AgentsController::class, 'credit_plans']);
        Route::get('payment-success', [PaymentsController::class, 'paymentSuccess']);
        Route::get('success-page/{id}', [PaymentsController::class, 'SuccessPage']);
        Route::get('payment-error', [PaymentsController::class, 'paymentError']);
        Route::post('checkout', [PaymentsController::class, 'payment']);


        
        Route::get('billing', [AgentsController::class, 'billing']);
        // to show contact requests and contact request details
        Route::get('contact-request-listing', [AgentsController::class, 'contact_request_listing']);
        Route::get('contact-request-listing/{request_id}', [AgentsController::class, 'contact_request_listing']);
        // to show/download agent qr code pdf 
        Route::get('qr-code/{handle}', 'AgentsController@qr_code');
    });
    
    Route::any('sign-up', [AgentsController::class, 'SignUp']);
     // to get agent's unique handle using ajax request
    Route::get('get-unique-handle', [AgentsController::class, 'get_unique_handle']);
    Route::get('agents-address', [AgentsController::class, 'agents_address']);
    Route::post('agents-address-add', [AgentsController::class, 'agents_address_add']);
});


// Backend Section Route                                      
    Route::namespace('Backend')->prefix('backend')->name('backend.')->group(function () {       // prefix-10
    Route::get('/', [AdminsController::class, 'admin']); 

    Route::namespace('Auth')->middleware('guest:admin')->group(function () {
        Route::get('sign-in', 'AuthenticatedSessionController@create')->name('login');
        Route::post('sign-in', 'AuthenticatedSessionController@store')->name('adminlogin');
    });
    
    //Add login check for all Agent URLS inside this block
    Route::middleware('backend')->group(function(){   
        Route::get('dashboard', 'DashboardController@index')->name('dashboard');
        Route::namespace('Auth')->group(function(){
            Route::get('sign-out', 'AuthenticatedSessionController@destroy')->name('adminDestroy');
        });
        Route::get('agents', 'AgentListingController@index');
        Route::get('status', 'AgentListingController@status');
        Route::get('delete', 'AgentListingController@delete');
        Route::get('properties','PropertiesController@index');
        Route::get('expiry-due/{id}','PropertiesController@ExpiryDue');
        Route::get('property-status','PropertiesController@Property_Status');
        // Plans route
        Route::prefix('plans')->group(function(){                              // prefix-11

            Route::get('index/{id?}','PlansController@index');
            Route::get('status','PlansController@status');
            Route::get('add','PlansController@add');
            Route::get('add/{id}','PlansController@add');
            Route::get('delete/{id}','PlansController@delete');
        });
        Route::prefix('blogs')->group(function(){
            Route::get('/','BlogsController@index');
            Route::get('delete/{slug}','BlogsController@delete');
            Route::get('edit/{slug}','BlogsController@edit');
            Route::get('edit','BlogsController@edit');
            Route::post('add','BlogsController@add');
            Route::post('add/{slug}','BlogsController@add');
            Route::get('publish','BlogsController@status');
        });

    });

});


// Public Property Details route

Route::get("/welcome", function () { return view('welcome'); });
Route::get('/get-city-suggestions', 'HomeController@get_city_suggestions')->name('get-city-suggestions');
Route::get('/property/search', 'PropertyController@search')->name('property.search');
Route::get('/cr/{hash}' , [PropertyController::class, 'contactRequest']);

// to send contact form to agents on properties description page
Route::post('/agents/send-contact-mail', 'AgentsController@send_contact_mail')->name('agents/send-contact-mail');
// to show agents listing on public page
Route::get('/agents/listing', 'AgentsController@listing')->name('agents/listing');
// to show properties of specific agents :here passed handle is agent unique handle
Route::get('/agents/{handle}/{type?}', 'AgentsController@properties');
// to send otp on agent's sign in page using ajax request
Route::get('agent/send-otp', 'AgentsController@send_otp');
// to send otp on user's sign in page using ajax request
Route::get('user/user-send-otp', 'UsersController@user_send_otp');
// to verify otp on agent's sign in page using ajax request
Route::get('agent/verify-otp', 'AgentsController@verify_otp');
// to verify otp on user's sign in page using ajax request
Route::get('user/verify-otp', 'UsersController@verify_otp');
Route::any('user/user-sign-up', 'UsersController@user_sign_up');
// to verify otp of enquiry from  on propertydetails page using ajax request
Route::get('agent/verify-contact-otp','AgentsController@verify_contact_otp');

// to show properties listing on public page
Route::get('/properties/listing/{type}', 'PropertyController@listing')->name('properties/listing');
// for advance search
Route::get('/advance-search','PropertyController@advance_search');
// getting the matched data after advance search 
Route::any('/matched-data','PropertyController@matched_data');
// show the pricing details of the plan
Route::get('/plan-details','HomeController@plan_details');
// to show properties of specific cities
Route::get('/properties/city/{city}/{type}', 'PropertyController@cities');
// contact us page on public site
Route::any('/contact-us', 'HomeController@contact_us')->name('contact-us');
// privacy policy page on public site
Route::any('/privacy-policy', 'HomeController@privacy_policy')->name('privacy-policy');
// term and conditions page on public site
Route::any('/terms-conditions', 'HomeController@terms_conditions')->name('terms-conditions');
// Refund Terms 
Route::get('/refund-terms', 'HomeController@refund_terms')->name('refund-terms');
// blogs page
Route::get('/blog', [BlogController::class ,'index']);
// blog detail page
Route::get('/blog/{blog_slug}', [BlogController::class ,'blog_details']);

// static page "Usage Terms" for mobile view only
Route::any('/usage-terms', 'HomeController@usage_terms');

// about us page on public site
Route::any('/about-us', 'HomeController@about_us')->name('about-us');
// overview page on public site
Route::any('/how-it-works-agents','HomeController@how_it_works_agents')->name('how-it-works-agents');
Route::any('/how-it-works-buyers','HomeController@how_it_works_buyers')->name('how-it-works-buyers');

Route::get("/", "HomeController@index");    

Route::get('/{unique_url}', 'PropertyController@details');
Route::get('/invite/{handle}', [AgentsController::class, 'sendInvitations']);

// Firebase notification
Route::patch('/fcm-token', 'HomeController@update_token')->name('fcmToken');
Route::post('/send-notification',[HomeController::class,'notification'])->name('notification');


// PWA
Route::get('/offline', function () {
    return view('modules/laravelpwa/offline');
});