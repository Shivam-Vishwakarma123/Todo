<?php $__env->startSection('title', 'Images'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
<div class="mb-6">
    <div class="m-0  p-1">
        <div class=' block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500   '>

            <form action="<?php echo e(url('agent/property-images/save-images')); ?>" method="post" id="uploadImage" enctype="multipart/form-data">
                <?php echo method_field('POST'); ?>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="property_id" id="property_id" value="<?php echo e($property->id); ?>">
                <div class=" pt-4 mb-6 mt-1 mr-16">
                    <label class="block mb-2 text-sm font-medium text-gray-900 " for="file">Upload file</label>
                    <input class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50  focus:outline-none " id="file" type="file" name = "file[]" multiple="multiple">
                </div>
            </form>
            <p class="mb-4 font-light text-gray-500 ">
                You can upload up to 200 photos per property. However, you can 
                only upload 10 photos simultaneously. If you have more than 10 
                you'll need to upload them in multiple batches.
                The max file size for each individual photo is 20 MB. Photos exceeding 
                that size may be dropped. Please let us know if you have trouble 
                uploading.
            </p>
    
            <div class="mb-4">
                <button id="addFiles" class="bg-lime-500 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"  data-ripple-light="true">Add Images</button>
            </div>
        </div>
    </div> 

  <h2 class="text-3xl font-bold ">Property Images</h2>

    <div class="views-form mt-5 property_image uploaded-images">
        <?php $__currentLoopData = $property_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="inline-block w-52 mx-3 relative gallery-image border-2 p-2 mb-4" id="<?php echo e($property_image->id); ?>">
            <div class="flex justify-center items-center overflow-hidden w-full">
                <img src="<?php echo e(url('/files/property_images/')); ?>/<?php echo e($property_image->property_id); ?>/<?php echo e($property_image->file_name); ?>" id="image<?php echo e($property_image->id); ?>" class="max-w-full max-h-full object-contain object-center" alt="No Image">
            </div>
            <div class="w-full">
                <a href="#" title="Rotate Image" onclick="rotateImage(<?php echo $property_image->id ?>);"><i class="fa fa-rotate mr-5 ml-2 mt-3 text-green-500"></i></a>
                <a href="javascript:deleteImage(<?php echo $property_image->id ?>)" title="Delete Image" class="delete float-right"><i class="fa fa-times mr-5 ml-2 mt-3 text-red-600"></i></a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>

<div class="relative px-5 py-2.5 transition-all ease-in duration-75 bg-white rounded-md group-hover:bg-opacity-0">
  <a href="<?php echo e(url('/agent/property/price-feature')); ?>" class="text-white bg-neutral-600 hover:bg-neutral-700 focus:ring-4 focus:outline-none focus:ring-neutral-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Prev</a>
  <a href="<?php echo e(url('/agent/video/video')); ?>" class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Next</a>
</div>


<div class="h-screen w-full absolute top-0 left-0 hidden justify-center items-center image-rotate-wrap">
    <div class="bg-white ml-36 mr-36 text-center is-filled p-5 shadow-xl w-full rotate-img">
        <div class="text-5xl">
            <a class="float-right" style="cursor: pointer;" onclick="closeRotateImage()"><i class="far fa-times-circle"></i></a>
        </div>
        <div class="mt-2">
            <h2 class="text-xl">Rotate Image</h2>
        </div>
        <br>
        <div class="">
            <a class="cursor-pointer bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded" onClick="leftRotateImg()" data-ripple-light="true"><i class="fas fa-undo mr-2"></i>Left Rotate</a>
            <a class="cursor-pointer bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded" onClick="rightRotateImg()" data-ripple-light="true"><i class="fas fa-redo-alt mr-2"></i>Right Rotate</a>
        </div>
        <br>
        <div class="w-full h-auto m-auto text-center flex justify-center">
            <div class="mt-5 mb-5 w-1/2  m-auto text-center flex justify-center rotated-img">
                <img src="#" id="rotate_img" alt="No Image" class=" object-contain object-center">
            </div>
        </div>
        <input type="hidden" value="0" id="direction">
        <input type="hidden" value="0" id="rotate_id">
        <div class="text-center">
            <button class="bg-lime-500 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2" data-ripple-light="true" onclick="saveImageRotate()">Save And Close</button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/property-images/images.blade.php ENDPATH**/ ?>