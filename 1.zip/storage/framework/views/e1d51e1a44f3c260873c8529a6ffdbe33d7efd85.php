<?php $__env->startSection('title', 'Advance Search'); ?>

<?php $__env->startSection('content'); ?>
<div class="pt-4 bg-gray-100">
    <h1 class="text-center text-4xl font-extrabold leading-none tracking-tight text-gray-900 md:text-5xl lg:text-6xl mb-10">Advance Search</h1>
    <div class="container h-full bg-gray-50 mx-auto p-6">
        <form action="<?php echo e(url('matched-data')); ?>" method="get">
        <?php echo csrf_field(); ?>
            <div class="flex gap-4">
                <div class="flex items-center pl-4 border border-gray-200 rounded  w-full ">
                    <input id="bordered-radio-1" type="radio" value="Sale" name="sale_rent"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  ">
                    <label for="bordered-radio-1"
                        class="w-full py-4 ml-2 text-sm font-medium text-gray-900  cursor-pointer">Sale</label>
                </div>
                <div class="flex items-center pl-4 border border-gray-200 rounded  w-full">
                    <input checked id="bordered-radio-2" type="radio" value="Rent" name="sale_rent"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500   focus:ring-2  ">
                    <label for="bordered-radio-2"
                        class="w-full py-4 ml-2 text-sm font-medium text-gray-900  cursor-pointer">Rent</label>
                </div>
                <div class="flex items-center pl-4 border border-gray-200 rounded  w-full ">
                    <input id="bordered-radio-3" type="radio" value="Any" name="sale_rent"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500   focus:ring-2  ">
                    <label for="bordered-radio-3"
                        class="w-full py-4 ml-2 text-sm font-medium text-gray-900  cursor-pointer">Any</label>
                </div>
            </div>
            <br><br><br>
            <div class="flex">
                <label for="bedrooms" class="text-xl pl-1 pr-4 w-80"> Bedrooms : </label>
                <div class="flex">
                    <select data-te-select-init name="bedrooms" id = "bedrooms" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5    pl-3 pr-6">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="8">9</option>
                        <option value="8">10</option>
                    </select>
                </div>
            </div>
            <br><br><br>
            <div class="price flex">
                <p class="text-xl pr-2 w-80" style= "color:black;">
                    Price :
                </p>
                <div class="flex gap-2 md:flex-wrap">
                    <div>
                        <input type="number" id="min-price"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   "
                            placeholder="min" min="0" name="price_min">
                    </div>
                    <div>
                        <input type="number" id="max-price"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   "
                            placeholder="max" min="0" name="price_max">
                    </div>
                </div>
            </div>
            <br><br><br>
            <div class="flex property-type">
                <p class="text-xl pr-2 w-80" style="color:black;">Property Type: </p>
                <div class="flex gap-2" id="property-type-id">
                    <div class="flex items-center pl-4 border border-gray-200 rounded  w-96">
                        <input id="bordered-radio-3" type="radio" value="Apartment" name="property_type"
                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500   focus:ring-2  ">
                        <label for="bordered-radio-3"
                            class="w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Apartment</label>
                    </div>
                    <div class="flex items-center pl-4 border border-gray-200 rounded  w-1/2">
                        <input id="bordered-radio-4" type="radio" value="Independent House" name="property_type"
                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500   focus:ring-2  ">
                        <label for="bordered-radio-4"
                            class="w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Independent
                            House</label>
                    </div>
                    <div class="flex items-center pl-4 border border-gray-200 rounded  w-1/2">
                        <input checked id="bordered-radio-5" type="radio" value="Any" name="property_type"
                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500   focus:ring-2  ">
                        <label for="bordered-radio-5"
                            class="w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Any</label>
                    </div>
                </div>
            </div>

            <br><br><br>
            <div class="flex furnishing-type">
                <p class="text-xl pr-2 w-80" style="color:black;">Furnishing Type: </p>
                <div id = "furnishing-type-id" class="flex gap-2">
                    <div class="flex items-center pl-4 border border-gray-200 rounded  w-96">
                        <input id="bordered-checkbox-4" type="checkbox" value="Furnished" name="furnishing_type[]"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500   focus:ring-2  ">
                        <label for="bordered-checkbox-4"
                        class="w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Furnished</label>
                    </div>
                    <div class="flex items-center pl-4 border border-gray-200 rounded  w-1/2">
                        <input id="bordered-checkbox-5" type="checkbox" value="SemiFurnished" name="furnishing_type[]"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500   focus:ring-2  ">
                        <label for="bordered-checkbox-5"
                        class="w-full py-4 ml-2 text-sm font-medium text-gray-900 ">Semi-Furnished</label>
                    </div>
                    <div class="flex items-center pl-4 border border-gray-200 rounded  w-1/2">
                        <input id="bordered-checkbox-6" type="checkbox" value="UnFurnished" name="furnishing_type[]"
                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500   focus:ring-2  ">
                        <label for="bordered-checkbox-6"
                        class="w-full py-4 ml-2 text-sm font-medium text-gray-900 ">UnFurnished</label>
                    </div>
                
                </div>
            </div>
            <br><br><br>
            <div class="flex">
                <label for="city" class="text-xl pr-2 w-80">City : </label>
                <!-- Dropdown menu -->
                <select data-te-select-init class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5    pl-3 pr-6" id="city" name="city">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($city->id); ?>><?php echo e($city->name); ?>, <?php echo e($city->state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <br><br><br>

            <div class="flex">
                <label for="parking" class="text-xl pr-2 w-80">Parking : </label>
                <!-- Dropdown menu -->
                <select data-te-select-init class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5    pl-3 pr-8" id="parking" name="parking">
                    <option value="Ignore">Ignore</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="8">9</option>
                    <option value="8">10</option>
                </select>

            </div>
            <br><br><br>
            <div class="submit-btn text-center">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Get Matching Data
                </button>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/advance_search.blade.php ENDPATH**/ ?>