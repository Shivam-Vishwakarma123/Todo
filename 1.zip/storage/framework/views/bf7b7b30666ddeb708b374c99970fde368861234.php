<?php $__env->startSection('title', 'Agents'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
    <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto justify-center">
        
        <p class="ap-pricesort mb-4">
            <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Recent'));?>
        </p>
        <br><br>
        <h1 class="text-xl md:text-3xl">
            Listing of All Agents
        </h1>
        <h2 class="my-3">
            
            Total <?php echo e(count($agents)); ?> Agents Found
                </h2>
        <div class="grid md:max-xl:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-4 gap-2 mx-auto">
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if (isset($component)) { $__componentOriginalc1b0b1e8d23e5d03ad14b18529399eebacbba205 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AgentCard::class, ['agent' => $agent]); ?>
<?php $component->withName('agent-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1b0b1e8d23e5d03ad14b18529399eebacbba205)): ?>
<?php $component = $__componentOriginalc1b0b1e8d23e5d03ad14b18529399eebacbba205; ?>
<?php unset($__componentOriginalc1b0b1e8d23e5d03ad14b18529399eebacbba205); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <?php echo e($agents->appends(request()->query())->links()); ?>

            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/agents_listing.blade.php ENDPATH**/ ?>