<?php $__env->startSection('title', 'Properties listed by '.$agent->first_name.' '.$agent->last_name); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="flex gap-4 flex-wrap mb-10">
                <p class="ap-pricesort flex gap-2">
                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Price'));?>
                </p>
                <p class="ap-pricesort flex gap-2">
                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Popularity'));?>
                </p>
                <p class="ap-pricesort flex gap-2">
                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Recent'));?>
                </p>
                <div class="flex flex-wrap">
                    <div class="relative w-32 mr-2">
                        <?php  if(!(isset($_GET['sale_rent']))){?>
                        <!-- Dropdown menu -->
                        <select data-te-select-init class="rounded-md w-32 p-2 ap-pricesort pl-4"
                            style="border:none;text-align:start;font-size:15px;" id="type" name="type"
                            onChange="window.open(this.value, '_parent')">
                            <option value="<?php echo e(url('/properties/listing/All?sort=Recent&direction=asc')); ?>"
                                <?php echo e($type == 'All' ? 'selected' : ''); ?>>All</option>
                            <option value="<?php echo e(url('/properties/listing/Rent?sort=Recent&direction=asc')); ?>"
                                <?php echo e($type == 'Rent' ? 'selected' : ''); ?>>Rent</option>
                            <option value="<?php echo e(url('/properties/listing/Sale?sort=Recent&direction=asc')); ?>"
                                <?php echo e($type == 'Sale' ? 'selected' : ''); ?>>Sale</option>
                        </select>
                        <?php }?>
                    </div>

                </div>

            </div>

            <h1 class="text-xl md:text-2xl mb-2">
                Properties listed by "<?php echo e($agent->first_name . ' ' . $agent->last_name); ?>"
            </h1>
            <div class="">
                <div class="flex  rounded-md agent-details" style="background:#ffffff6e;">
                    <div class="flex flex-col justify-center h-44 py-4" style="width:20%">
                        <?php if($agent->profile_image != ''): ?>
                            <img src="<?php echo e(url('/files/agents/')); ?>/<?php echo e($agent->id); ?>/<?php echo e($agent->profile_image); ?>"
                                alt="Agent Image" class="h-full" style="object-fit:contain;">
                        <?php else: ?>
                            <img src="<?php echo e(url('/images/logo1.png')); ?>" class="h-full " alt="Agent Image"
                                style="object-fit:contain;">
                        <?php endif; ?>
                    </div>
                    <div class="border-l-4 flex flex-col justify-center px-4 xs:w-full"
                        style="border-color: #6064681c;width:40%">
                        <div class="inline-block">
                            <p class="font-semibold text-lg">Contact Details</p>
                            <?php if($agent->address != '' || $agent->state_name !== '' || $agent->city_name !== ''): ?>
                                <p><b>Located:</b> <?php echo e($agent->address); ?>, <?php echo e($agent->city_name); ?>, <?php echo e($agent->state_name); ?></p>
                            <?php endif; ?>
                            <?php if(!$agent->dummy_record): ?>
                                <p><b>Phone : </b><a href="tel:<?php echo e($agent->phone); ?>" class="underline">
                                        <?php echo e($agent->phone); ?></a>
                                </p>
                                <?php if($agent->whatsapp_no != ''): ?>
                                    <a href="https://wa.me/+91<?php echo e($agent->whatsapp_no); ?>" class="underline">Message on
                                        Whatsapp</a>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="border-l-4 flex flex-col justify-center px-4" style="border-color: #6064681c; width:40%">
                        <div class="inline-block py-4">
                            <p class="font-semibold text-lg">Fee Details</p>
                            <div class="flex gap-2">
                                <p>For Sale : </p>
                                <?php if($agent->sale_fee_type && $agent->sale_fee_amount): ?>
                                    <p><?php echo e($agent->sale_fee_amount); ?> [<?php echo e($agent->sale_fee_type); ?>]</p>
                                <?php else: ?>
                                    <p>Contact Agent</p>
                                <?php endif; ?>
                            </div>
                            <div class="flex gap-2">
                                <p>For Rent : </p>
                                <?php if($agent->rent_fee_type && $agent->rent_fee_amount): ?>
                                    <p><?php echo e($agent->rent_fee_amount); ?> [<?php echo e($agent->rent_fee_type); ?>]</p>
                                <?php else: ?>
                                    <p>Contact Agent</p>
                                <?php endif; ?>
                            </div>
                            <div class="">
                                <ul class="flex gap-2 text-lg py-2 social-media-agent">
                                    <?php if(!is_null($agent->facebook_profile)): ?>
                                        <li>
                                            <a href="/<?php echo e($agent->facebook_profile); ?>"
                                                class="facebook cursor-pointer hover:bg-red" target="_blank">
                                                <i class="fab fa-facebook-f "></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if(!is_null($agent->instagram_profile)): ?>
                                        <li>
                                            <a href="<?php echo e($agent->instagram_profile); ?>" class="instagram cursor-pointer"
                                                target="_blank">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if(!is_null($agent->twitter_profile)): ?>
                                        <li>
                                            <a href="<?php echo e($agent->twitter_profile); ?>" class="twitter cursor-pointer"
                                                target="_blank">
                                                <i class="fab fa-twitter"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if(!is_null($agent->linkedin_profile)): ?>
                                        <li>
                                            <a href="<?php echo e($agent->linkedin_profile); ?>" class="linkedin cursor-pointer"
                                                target="_blank">
                                                <i class="fab fa-linkedin-in"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if(!$agent->dummy_record): ?>
                                        <?php if(!is_null($agent->whatsapp_no)): ?>
                                            <li>
                                                <a href="https://wa.me/+91<?php echo e($agent->whatsapp_no); ?>"
                                                    class="whatsapp cursor-pointer" target="_blank">
                                                    <i class="fab fa-whatsapp"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="my-3 mt-3">Total <b><?php echo e($count); ?></b> Properties Found</div>
            <div class="grid gap-2 property_listing">
                <?php $__currentLoopData = $propertie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $width = ''; ?>
                    
                    <?php if (isset($component)) { $__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PropertyCard::class, ['property' => $property,'width' => $width]); ?>
<?php $component->withName('property-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89)): ?>
<?php $component = $__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89; ?>
<?php unset($__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php echo e($propertie->appends(request()->query())->links()); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/agent_properties.blade.php ENDPATH**/ ?>