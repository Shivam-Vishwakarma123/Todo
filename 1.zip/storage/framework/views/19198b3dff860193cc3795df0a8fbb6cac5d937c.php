<!doctype html>
<html lang="en" dir="ltr">

<head>
    <!-- TITLE -->
    <title><?php echo $__env->yieldContent('title'); ?> - Property Shops</title>

    <!-- FAVICON -->
    <link rel="icon" href="<?php echo e(url('/images/favicon-48x48.ico')); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    
    <?php echo $__env->make('includes.agents.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if (isset($component)) { $__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187 = $component; } ?>
<?php $component = $__env->getContainer()->make(BenSampo\Embed\ViewComponents\StylesViewComponent::class, []); ?>
<?php $component->withName('embed-styles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187)): ?>
<?php $component = $__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187; ?>
<?php unset($__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187); ?>
<?php endif; ?>
    <!-- Cropper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js" integrity="sha512-6lplKUSl86rUVprDIjiW8DuOniNX8UDoRATqZSds/7t6zCQZfaCe3e5zcGaQwxa8Kpn5RTM9Fvl3X2lLV4grPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.css" integrity="sha512-C4k/QrN4udgZnXStNFS5osxdhVECWyhMsK1pnlk+LkC7yJGCqoYxW4mH3/ZXLweODyzolwdWSqmmadudSHMRLA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- Custom Css -->
    <link rel="stylesheet" href="<?php echo e(url('css/custom.css')); ?>">
    <script></script>
    
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js" defer></script>
    <script src="<?php echo e(url('js/PullToRefresh.js')); ?>?t=123"></script>


    
    <script src=" https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js "></script>
	<script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
    <script>
        /* Public URL of the website use in JS - web_url */
        <?php echo "web_url = \"" . URL::to('/') . "\";"; ?>
        </script>
    <?php echo \Livewire\Livewire::styles(); ?>


</head>


<body class="app sidebar-mini ltr light-mode">
    <!-- Flash message 2222 -->
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- PAGE -->
    <?php if(isset($property)): ?>
    <?php if($property['id']): ?>
    <!-- admin dashboard header -->
    <div class="agent_menu">
        <?php echo $__env->make('includes.agents.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="lg:flex">
        <!-- admin dashboard sidebar -->
        <!-- to include agents property sidebar only on property edit, add pages -->
            <?php if(request()->is('agent/property/listing') || request()->is('agent/dashboard'))
            {}else {
                ?>
            <?php echo $__env->make('includes.agents.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
            }
            ?>
            
            <div class="container">
                <!-- to include agents property sidebar only on property edit, add pages -->
                <?php if(request()->is('agent/property/listing') || request()->is('agent/dashboard'))
                {}else {
                    ?>
                    <div class="address_bar flex justify-content-between items-center align-content-between" style="padding:1% 2%;justify-content:space-between;">
                        <!-- <p>My Property Address</p>-->
                        <div class="">
                            <h1 class="text-lg font-bold ">My Property Address</h1>
                            
                            <?php if(!empty(session('property')->address_line_1) || !empty(session('property')->state) || !empty(session('property')->zip)): ?>
                            <a class="nav-brand mr-auto ml-0">
                                <?php if(!empty(session('property')->address_line_1)): ?>
                                <?php echo e(session('property')->address_line_1); ?>,
                                <?php endif; ?>
                                <?php if(!empty(session('property')->city)): ?>
                                <?php echo e($property->city->name); ?>,
                                <?php endif; ?>
                                
                                <?php if(!empty(session('property')->zip)): ?>
                                (<?php echo e(session('property')->zip); ?>)
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="">

                            <a href="<?php echo e(url('/' . session('property')->unique_url)); ?>" class="property_preview text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 my-3 block max-w-sm" target="_blank">
                                Property Preview
                            </a>
                            <?php else: ?>
                            <a class="nav-brand mr-auto ml-0" href="#"><?php echo session('agent')->first_name . " " . session('agent')->last_name; ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <!-- admin content section -->
                <div class="px-4">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php else: ?>
    <div class="page" style="width: 100%;">
        <!-- admin dashboard header -->
        <div class="agent_menu">
            <?php echo $__env->make('includes.agents.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="p-2 mb-5">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <?php endif; ?>
    
    
    <!-- admin dashboard footer -->
    <?php echo $__env->make('includes.agents.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    <!-- admin dashboard foot -->
    <?php echo $__env->make('includes.agents.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<script>
  PullToRefresh.init({
        mainElement: 'body',
        distMax: 120,
        onRefresh() {
          window.location.reload();
        }
    });
</script><?php /**PATH /home/shivam/www/propertyshops/resources/views/layouts/agents/agent.blade.php ENDPATH**/ ?>