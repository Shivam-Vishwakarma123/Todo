<?php $__env->startSection('title', 'Amenities'); ?>

<?php $__env->startSection('content'); ?>
    <?php 
        if(isset($property)){ 
                $data =  $property->id; 
                $agent_id = $property->agent_id; 
            }
            else{
                $data = "";
                $id = ''; 
            }
    ?>

<div class="w-full rounded overflow-hidden">
    <form action="<?php echo e(url('/agent/property/store-amenities')); ?>"  id="amenitesForm"  method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-6">
        <div class="w-full">
           <!-- <h3 class="">Property Amenities</h3>-->
            
           <h2 class="text-3xl font-bold">Property Amenities</h2>

           <div class="grid grid-cols-2 amenities-grid">
               <div class="p-5 my-5 bg-grey-100 flex flex-col">
                   <div class="mt-3 mb-4">
                       <label class="font-bold text-2xl">Amenities</label>
                       <button type="button" class="float-right px-2 text-base bg-amber-500 hover:bg-amber-600 focus:ring-4 focus:outline-none focus:ring-amber-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2" onclick="delete_amenities();">Clear All</button>
                       <!-- <a class="float-right px-2 text-base bg-amber-500 hover:bg-amber-600 focus:ring-4 focus:outline-none focus:ring-amber-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2" onclick="delete_amenities();">Clear All</a> -->
                   </div>
                  <div id="addAmenities" class="h-full p-2 border border-grey-500" >
                       <?php $__currentLoopData = $property->property_amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <a href="javascript:void(0);" id="<?php echo e($amenitie->amenity_id); ?>"  class="amenitiesbutton1 <?php echo e($amenitie->amenity_id); ?>" data-name="<?php echo e(isset($amenitie->Amenities) ? $amenitie->Amenities->name : $amenitie->name); ?>">
                            <div  class="p-amenitie">
                                <span class="amenitiesbutton"><?php echo e(isset($amenitie->Amenities) ? $amenitie->Amenities->name : $amenitie->name); ?></span>
                                <input type="text" hidden value="<?php echo e(isset($amenitie->Amenities) ? $amenitie->Amenities->name : $amenitie->name); ?>" class="amenitiesbutton">
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" id="amenities_array" name="amenities_array" value="<?php echo e(implode(',',$amenities_array)); ?>">
                   </div>
               </div>
               <div class="flex flex-col gap-6 px-5 mb-5 bg-grey-100 py-8" id="amenitie_suggation">
                   <p class="mb-4 text-xl">Click on below items to add to the amenities list.</p>
                   <div class="h-full p-2 border border-grey-500 amenitieData background-color">
                       <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if(count($amenities_array) > 0 ): ?>
                               <?php if(!in_array( $amenitie->id,$amenities_array)): ?>
                                   <span id="<?php echo e($amenitie->id); ?>" class="amenities a-amenitie" onclick="append_amenities(this);"><?php echo e($amenitie->name); ?></span>
                               <?php endif; ?>
                               <?php else: ?>
                               <span id="<?php echo e($amenitie->id); ?>" class="amenities a-amenitie" onclick="append_amenities(this);"><?php echo e($amenitie->name); ?></span>
                           <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
               </div>
           </div>
            <div class="flex px-4 bg-grey-100 py-8">
                <div class="flex items-center mr-4">
                    <span class="block mb-2 text-sm font-medium text-gray-900 ">Add Amenity: </span>
                    <input type="text" id="add_amenitie"  name="add_amenitie"  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 " />
                </div>
                <div class="flex items-center mr-4">
                <span class="bg-lime-500 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2" onclick="add_amenities(this);">Add Amenity</span>
                </div>
            </div>
        </div>
        </div>
        <a href="<?php echo e(url('/agent/property/description')); ?>" class="text-white bg-neutral-600 hover:bg-neutral-700 focus:ring-4 focus:outline-none focus:ring-neutral-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Prev</a>
        <button type="submit" id="amenitiesForm" class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">
        Save & Next
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/Property/amenities.blade.php ENDPATH**/ ?>