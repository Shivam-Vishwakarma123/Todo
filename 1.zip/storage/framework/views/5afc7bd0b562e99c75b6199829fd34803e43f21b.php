<?php $__env->startSection('title',  ($type == 'Sale'? 'Buy' : $type ).' Properties'); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="flex gap-4 flex-wrap mb-10">
                <p class="ap-pricesort flex gap-2">
                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Price'));?>
                </p>
                <p class="ap-pricesort flex gap-2">
                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Popularity'));?>
                </p>
                <p class="ap-pricesort flex gap-2">
                    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Recent'));?>
                </p>
                <div class="flex flex-wrap">
                    <div class="relative w-32 mr-2">
                        <?php  if(!(isset($_GET['sale_rent']))){?>
                        <!-- Dropdown menu -->
                        <select data-te-select-init class="rounded w-32 p-2 ap-pricesort pl-4"
                            style="border:none;text-align:start;font-size:15px;" id="type" name="type"
                            onChange="window.open(this.value, '_parent')">
                            <option value="<?php echo e(url('/properties/listing/All?sort=Recent&direction=asc')); ?>"
                                <?php echo e($type == 'All' ? 'selected' : ''); ?>>All</option>
                            <option value="<?php echo e(url('/properties/listing/Rent?sort=Recent&direction=asc')); ?>"
                                <?php echo e($type == 'Rent' ? 'selected' : ''); ?>>Rent</option>
                            <option value="<?php echo e(url('/properties/listing/Sale?sort=Recent&direction=asc')); ?>"
                                <?php echo e($type == 'Sale' ? 'selected' : ''); ?>>Sale</option>
                        </select>
                        <?php }?>
                    </div>

                </div>
            </div>
            <h1 class="text-2xl">
                Available Properties
            </h1>
            <div class="my-3 mt-3">Total <b><?php echo e($count); ?></b> Properties Found</div>
            <div class="grid gap-2 property_listing">
                <?php $__currentLoopData = $propertie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $width = ''; ?>
                    
                    <?php if (isset($component)) { $__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PropertyCard::class, ['property' => $property,'width' => $width]); ?>
<?php $component->withName('property-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['style' => 'margin-bottom:10px;']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89)): ?>
<?php $component = $__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89; ?>
<?php unset($__componentOriginal2fb2998cff7d78e35086a5119f96c5364f645c89); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br><br>
            <div class="row">
                <div class="col-md-12">
                    <?php echo e($propertie->appends(request()->query())->links()); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/properties_listing.blade.php ENDPATH**/ ?>