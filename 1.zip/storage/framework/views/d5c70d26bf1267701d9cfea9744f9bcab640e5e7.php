<?php $__env->startSection('title', 'Credit Plans'); ?>

<?php $__env->startSection('content'); ?>

<div class="w-full text-center pt-5">
    <h1 class="font-bold text-4xl m-5">Credit Plans</h1>
    <h2 class="px-8">Instead of monthly expiring plans, we are offering credits. You can use 1 credit to publish one property. </h2>
</div>
<div class="grid grid-cols-3 gap-12 mt-6 text-center credit-plans-grid">
    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(url('agent/checkout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card p-8 justify-center bg-purple-50 rounded-none mx-5" id="<?php echo e($plan->id); ?>">
                <input type="hidden" value="<?php echo e($plan->id); ?>" name="id">
                <p class="font-bold text-3xl mt-6"><?php echo e($plan->name); ?></p>
                <p class="font-bold mt-2 text-lg">&#8377; <?php echo e($plan->price); ?> </p>
                <div class="mt-2 mb-5 text-lg"><?php echo e($plan->credits); ?> Credits</div>
                <button class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2" type="submit">Buy Now</button>
                <!-- Payment link will be available soon. -->
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="w-full text-center pt-5 px-8">
    <h3 class ="my-4 font-bold text-2xl">Every plan includes benefits given below:</h3>
    <ul class="text-lg list-disc list-inside inline-block text-left">
        <li>Purchased credits will NEVER expire.</li>
        <li>Each credit allows you to publish one property listing for 30 days.</li>
        <li>NO Monthly commitment.</li>
        <li>NO Monthly membership.</li>
        <li>NO limit on number of properties published.</li>
        <li>Above plan prices are including GST.</li>
    </ul>
    <br><br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/agents/credit_plans.blade.php ENDPATH**/ ?>