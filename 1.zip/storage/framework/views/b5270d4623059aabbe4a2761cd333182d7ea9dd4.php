<?php $__env->startSection('title', 'How it Works for Buyers'); ?>

<?php $__env->startSection('content'); ?>

    <div class="bu-container">
        <div class="bu-main-container container sm:mx-auto px-6">
            <div class="ag-heading-div">
                <br>
                <h1>How it works
                    <br>
                    <span>How could a buyer use this site efficiently</span>
                </h1>
            </div>
            <div class="bu-search-container">
                <br>
                <h2 class="text-2xl mb-4 font-bold">Search Area</h2>
                <img src="<?php echo e(url('/images/buyerUse/search-city.png')); ?>" alt="Search Property">
                <br>
                <p >Search Properties in the area of your interest</p>
                <p>One can perform advance search as well.</p>
                <br>
            </div>
            <div class="bu-property-detail">
                <h2 class="text-2xl mb-2 font-bold">Property Detail</h2>
                <img src="<?php echo e(url('/images/buyerUse/detail-property.png')); ?>" alt="">
                <p class=" mt-2">Click on <b>Details</b> button to see the detail property</p>
                <p >From there if you are interested in the property you can contact the agent.</p>
                <p >Or you can also send an inquiry to the agent. The agent will contact you as soon as
                    possible.</p>
                <img src="<?php echo e(url('/images/buyerUse/agent-contact.png')); ?>" alt="">
            </div>
            <div class="bu-blogs">
                <h2 class="text-2xl mb-2 font-bold">Blogs</h2>
                <img src="<?php echo e(url('/images/buyerUse/blogs-page.png')); ?>" alt="">
                <p class=" mt-2">Here we post latest updates about what is happening at PropertyShops.in and some usefull articles to help you understand the real estate better.</p>
            </div>
        </div>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/how_it_works_buyers.blade.php ENDPATH**/ ?>