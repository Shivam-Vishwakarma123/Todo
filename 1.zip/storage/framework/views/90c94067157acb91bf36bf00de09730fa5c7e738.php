<?php $__env->startSection('title', 'Visit Stats'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h2 class="text-4xl font-bold ">Property Stats</h2>
    </div>
    <div class="mb-6">

        <div class="property-chart mt-10">
            <span class="hidden" id="agent_id"><?php echo e($agent->id); ?></span>
            <br>
            <div class="flex items-end">
                <div>
                    <div id="reportrange" class="flex items-center"
                        style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc;border-radius:5px">
                        <i class="fa fa-calendar"></i>&nbsp;
                        <span class="mx-2"></span> <i class="fa fa-caret-down"></i>
                    </div>
                </div>
                <div class="ml-8">
                    <label for="property_name" class="block mb-1 text-sm font-medium text-gray-900 ">Select
                        an
                        option</label>
                    <select id="property_name"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full   "
                        style="padding: 5px 10px">
                        <option selected value="">All</option>
                        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>

                <div>
                    <button class="text-gray-900 ml-6 bg-lime-300 font-medium rounded-lg text-sm px-5 py-2.5"
                        id="date-range">Go</button>
                </div>
            </div>
            <br>
            <button type="button" id="go-back-btn"
                class="w-full flex items-center justify-center w-1/2 px-5 py-2 text-sm text-gray-700 transition-colors duration-200 bg-white border rounded-lg gap-x-2 sm:w-auto   hover:bg-gray-100  ">
                <svg class="w-5 h-5 rtl:rotate-180" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                    stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18" />
                </svg>
                <span>Go back</span>
            </button>
            <br>
            <div id="canvas-chart" style="max-height: 500px;">
                <canvas id="myChart" height="100"></canvas>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/agents/visit_stats.blade.php ENDPATH**/ ?>