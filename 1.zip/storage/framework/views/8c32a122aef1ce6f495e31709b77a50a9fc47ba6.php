
<?php if($message = Session::get('success')): ?>
<script>
    $(document).ready(function(){
        var message = "<?php echo e($message); ?>";
        showPopUp('success' , message);
    });
</script>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<script>
    $(document).ready(function(){
        var message = "<?php echo e($message); ?>";
        showPopUp('error' , message);
    });
</script>
<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
<script>
    $(document).ready(function(){
        var message = "<?php echo e($message); ?>";
        showPopUp('warning' , message);
    });
</script>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
<script>
    $(document).ready(function(){
        var message = "<?php echo e($message); ?>";
        showPopUp('info' , message);
    });
</script>
<?php endif; ?>

<?php if($errors->any()): ?>
<script>
    $(document).ready(function(){
        showPopUp('error' , 'Please check the Username and Password and try Again.');
    });
</script>
<?php endif; ?>



<?php /**PATH /home/shivam/www/propertyshops/resources/views/flash-message.blade.php ENDPATH**/ ?>