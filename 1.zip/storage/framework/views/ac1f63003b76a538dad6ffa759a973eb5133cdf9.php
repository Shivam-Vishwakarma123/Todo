<div class= "grid gap-6 grid-cols-2 col-span-2">
<div class="input-group-outline input-group is-filled">
    <label class="form-label">State *</label>
    <select
    wire:model="state_id" wire:change="$emit('getStateCities', $event.target.value)"
    class="form-control pl-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        name="state_id" id="state_id">
        <?php if(!$is_state): ?>
        <option value="0">-- Select State --</option>
        <?php else: ?>
        <option value="<?php echo e($is_state->id); ?>" selected><?php echo e($is_state->name); ?></option>
        <?php endif; ?>
        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="input-group-outline input-group ml-5">
    <label class="form-label">City *</label>
    <select wire:model="city_id"
    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   "
    name="city_id" id="city_id">
    <?php if(!$is_city): ?>
    <option value="0">-- Select City --</option>
    <?php else: ?> 
    <option value="<?php echo e($is_city->id); ?>"><?php echo e($is_city->name); ?></option>
    <?php endif; ?>
    <?php if(isset($cities)): ?>
    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </select>
</div>
</div>
<?php /**PATH /home/shivam/www/propertyshops/resources/views/livewire/state-city-dropdown2.blade.php ENDPATH**/ ?>