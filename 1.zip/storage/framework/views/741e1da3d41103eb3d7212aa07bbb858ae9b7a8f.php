<style>
    .laravel-embed__responsive-wrapper { position: relative; height: 0; overflow: hidden; max-width: 100%; } 
    .laravel-embed__fallback { background: rgba(0, 0, 0, 0.15); color: rgba(0, 0, 0, 0.7); display: flex; align-items: center; justify-content: center; } 
</style><?php /**PATH /home/shivam/www/propertyshops/resources/views/vendor/embed/components/styles.blade.php ENDPATH**/ ?>