<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe 
        src="https://www.youtube.com/embed/Gj3gzIt73DA" 
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
</div><?php /**PATH /home/shivam/www/propertyshops/storage/framework/views/f08b5a90e2c20c25e20407f982d35e684b68f0e3.blade.php ENDPATH**/ ?>