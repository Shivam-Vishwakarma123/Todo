<?php $__env->startSection('title', $blog->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col items-center bg-gray-50 h-full py-24 bg-lime-100 justify-center">
        <div class="w-11/12 bg-white rounded-lg shadow p-4 static-page">
            <!-- component -->
            <div class="mx-auto">
                <div class="text-right">
                    <a href="<?php echo e(url()->previous()); ?>"
                        class="inline-flex px-4 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                        Go Back
                    </a>
                </div>
                <main class="mt-10">
                    <div class="mb-4 md:mb-0 w-full mx-auto relative">
                        <div class="px-4 lg:px-0">
                            <h2 class="text-4xl font-semibold text-gray-800 leading-tight">
                                <?php echo e($blog->title); ?>

                            </h2>
                        </div>
                        <?php if($blog->image): ?>
                            <div class="mt-3">
                                <img src="<?php echo e(url('/files/blogs/')); ?>/<?php echo e($blog->slug); ?>/<?php echo e($blog->image); ?>"
                                    class="lg:rounded" style="max-height: 500px;max-width:100%;" />
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="px-3 lg:px-0 mt-3 text-gray-700 text-lg leading-relaxed w-full">
                        <p class="pb-6" style="white-space: pre-wrap"><?php echo html_entity_decode($blog->description); ?></p>
                    </div>
                    <div class="mt-3">
                        <p class="text-gray-500"><b>Published:</b>
                            <?php echo e(date('j M, Y h:m', strtotime($blog->published_at))); ?> IST,
                            <b>Views:</b> <?php echo e($blog->views); ?>

                        </p>
                    </div>
                </main>
                <!-- main ends here -->
            </div>
        </div>
        <div class="flex w-11/12 mt-12 <?php echo e(is_null($previous) ? 'justify-end' : 'justify-between'); ?>">
            <?php if(!is_null($previous)): ?>
                <a type="button" href="<?php echo e(url('blog')); ?>/<?php echo e($previous->slug); ?>"
                    class="bg-gray-800 text-white rounded-l-md border-r border-gray-100 py-2 hover:bg-gray-900 hover:text-white px-3">
                    <div class="flex flex-row align-middle">
                        <svg class="w-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M7.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l2.293 2.293a1 1 0 010 1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="ml-2">Prev</span>
                    </div>
                </a>
            <?php endif; ?>
            <?php if(!is_null($next)): ?>
                <a type="button" href="<?php echo e(url('blog')); ?>/<?php echo e($next->slug); ?>"
                    class="bg-gray-800 text-white rounded-r-md py-2 border-l border-gray-200 hover:bg-gray-900 hover:text-white px-3">
                    <div class="flex flex-row align-middle">
                        <span class="mr-2" >Next</span>
                        <svg class="w-5 ml-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                    </div>
                </a>
            <?php endif; ?>
        </div><br><br>
        <div class="text">
            <a href="<?php echo e(url()->previous()); ?>"
                class="inline-flex px-4 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                Go Back
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/blog_details.blade.php ENDPATH**/ ?>