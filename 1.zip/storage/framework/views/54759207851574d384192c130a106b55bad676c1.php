<?php
    $property = session('property');
?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
    <!-- TITLE -->
    <title><?php echo $__env->yieldContent('title'); ?> - Property Shops</title>

    <!-- FAVICON -->
    <link rel="icon" href="<?php echo e(url('/images/favicon-48x48.ico')); ?>">
    <!-- Jquery link -->
    <script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
    <!-- add style for emded youtube video -->
    <?php if (isset($component)) { $__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187 = $component; } ?>
<?php $component = $__env->getContainer()->make(BenSampo\Embed\ViewComponents\StylesViewComponent::class, []); ?>
<?php $component->withName('embed-styles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187)): ?>
<?php $component = $__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187; ?>
<?php unset($__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(url('css/fontawesome.min.css')); ?>" />
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo e(url('css/custom.css')); ?>">    
    
    <link rel="stylesheet" href="<?php echo e(url('css/jsdeliver.min.css')); ?>">    
    
    <link rel="stylesheet" href="<?php echo e(url('css/lc_lightbox.min.css')); ?>" />
    
    <!-- Custom css and js-->
    <link rel="stylesheet" href="<?php echo e(url('css/public-custom.css')); ?>" />
    <?php 
    if($_SERVER["SERVER_NAME"] != "localhost" && strpos($_SERVER["SERVER_NAME"], "192.168") === false && $_SERVER["REMOTE_ADDR"] != "61.247.238.175") {
        ?>
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-9347CDELHT"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());

            gtag('config', 'G-9347CDELHT');
        </script>
    <?php 
    }
    ?>
    <script>
        /* Public URL of the website use in JS - web_url */
        <?php echo "web_url = \"" . URL::to('/') . "\";"; ?>
    </script>
</head>
<body>
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid p-0">

        <!-- Display Content -->
        <?php echo $__env->yieldContent('content'); ?>
         <!-- Fontawesome link -->
    <script src="<?php echo e(url('js/fontawesome.min.js')); ?>"></script>
    <!-- tailwind js -->
    <script src="<?php echo e(url('js/tailwind.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/jsdeliver.min.js')); ?>"></script>
    <!-- flowbite js -->
    <script src="<?php echo e(url('js/flowbite.min.js')); ?>"></script>
    <!-- function js -->
    <script src="<?php echo e(url('js/functions.js')); ?>?t=123"></script>
    <!-- CUSTOM JS -->
    <script src="<?php echo e(url('js/custom.js')); ?>?t=123"></script>
    <script src="<?php echo e(url('js/public-custom.js')); ?>?t=123" ></script>
    
    
    <script src="<?php echo e(url('js/lc_lightbox.lite.min.js')); ?>"></script>
    

    </div>
</body>

</html><?php /**PATH /home/shivam/www/propertyshops/resources/views/layouts/property.blade.php ENDPATH**/ ?>