<!-- META DATA -->
<meta charset="UTF-8">
<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sash – Bootstrap 5  Admin & Dashboard Template">
<meta name="author" content="Spruko Technologies Private Limited">
<meta name="keywords"
    content="admin,admin dashboard,admin panel,admin template,bootstrap,clean,dashboard,flat,jquery,modern,responsive,premium admin templates,responsive admin,ui,ui kit.">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- flowbite css -->
<link rel="stylesheet" href="<?php echo e(url('css/flowbite.min.css')); ?>" />

<!-- STYLE CSS -->
<link href="<?php echo e(url('css/custom.css')); ?>" rel="stylesheet" />

<!-- FONTAWESOME CSS -->
<link href="<?php echo e(url('css/fontawesome.min.css')); ?>" rel="stylesheet" />




<script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>

<script>
    /* Public URL of the website use in JS - web_url */
    <?php echo "web_url = \"" . URL::to('/') . "\";"; ?>
</script>

<?php 
if($_SERVER["SERVER_NAME"] != "localhost" && strpos($_SERVER["SERVER_NAME"], "192.168") === false && $_SERVER["REMOTE_ADDR"] != "61.247.238.175") {
    ?>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-XYHHTFFNYZ"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-XYHHTFFNYZ');
    </script>
    <?php 
}
?>
<?php /**PATH /home/shivam/www/propertyshops/resources/views/includes/agents/head.blade.php ENDPATH**/ ?>