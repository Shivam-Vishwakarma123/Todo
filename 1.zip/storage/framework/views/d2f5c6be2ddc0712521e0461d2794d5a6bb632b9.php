<a href="<?php echo e(url('/')."/agents/".$agent_handle."/All"); ?>?sort=Recent&direction=asc" class="bg-white my-1 rounded-lg  p-2 mx-2 max-w-[250px] overflow-hidden pt-4">
    <div class="relative">
        <div class="hover:scale-105 flex md:h-72 justify-center items-center ease-in duration-200">
            <img  src="<?php echo e($agent_profile_photo); ?>" alt="<?php echo e($agent_name); ?>" class="max-w-full max-h-full object-contain object-center"  />
        </div>
        <div class="absolute bottom-2.5 left-5 property-count">
            <div class="counts-property relative bg-white px-2 py-1.5 shadow-lg rounded text-sm inline-block text-slate-950 ">
                <h3 class= "m-0 font-normal text-sm">
                    <?php echo e($agent_property_count); ?> Listings
                </h3>
            </div>
        </div>
    </div>
    <div class="mt-2 px-1 text-left px-4">
        <h4 class="truncate font-medium pt-2.5 mb-1 capitalize">
            <?php echo e($agent_name); ?>

        </h4>
        <div class="text-gray-400 mb-1 capitalize">
            <span><?php echo e($agent_business_name); ?></span>
        </div>
        <?php if(!$agent_dummy_record): ?>
        <div class="text-gray-400 mb-1 capitalize">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline text-lime-500 p-px"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" /></svg>
            <span>+<?php echo e($agent_phone_number); ?></span>
        </div>
        <?php endif; ?>
    </div>
</a><?php /**PATH /home/shivam/www/propertyshops/resources/views/components/agent-card.blade.php ENDPATH**/ ?>