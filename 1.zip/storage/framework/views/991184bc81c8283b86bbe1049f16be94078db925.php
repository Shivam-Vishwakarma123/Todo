<?php $__env->startSection('title', 'SignUp'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex bg-gray-50 h-full py-24 bg-lime-100">
    <div class="w-5/6 md:w-1/2 mx-auto p-5 h-fit mb-5 mt-10 bg-white rounded-lg shadow">
        <h1 class="text-xl md:text-3xl font-bold text-center mb-6">Sign Up As Agent</h1>
        <div class="font-bold text-center text-xl text-green-500 mb-6">Launch Offer: Get 10 FREE credits, if you join NOW! </div>
        <br/>
        <form action="<?php echo e(url('/agent/sign-up')); ?>" method="post"  id="signUp" >
            <?php echo csrf_field(); ?>
            <div class="grid gap-2 mb-6 md:grid-cols-2">
                <div>
                    <?php $first_name=old('first_name') ?>
                    <label for="first_name" class="block mb-2 text-sm font-medium text-gray-900 ">First Name *</label>
                    <div class="relative mb-6">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5 text-gray-500 ">
                            <path d="M10 8a3 3 0 100-6 3 3 0 000 6zM3.465 14.493a1.23 1.23 0 00.41 1.412A9.957 9.957 0 0010 18c2.31 0 4.438-.784 6.131-2.1.43-.333.604-.903.408-1.41a7.002 7.002 0 00-13.074.003z" />
                            </svg>
                        </div>
                        <input type="text" id="first_name" name="first_name" maxlength="100" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " <?php if(isset($first_name)): ?> value=<?php echo e($first_name); ?> <?php endif; ?> required>
                    </div>
                    <small id="first_namehelp" class="text-red-700 font-bold"><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                </div>

                <div>
                    <?php $last_name=old('last_name') ?>
                    <label for="last_name" class="block mb-2 text-sm font-medium text-gray-900 ">Last Name *</label>
                    <div class="relative mb-6">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5 text-gray-500 ">
                            <path d="M10 8a3 3 0 100-6 3 3 0 000 6zM3.465 14.493a1.23 1.23 0 00.41 1.412A9.957 9.957 0 0010 18c2.31 0 4.438-.784 6.131-2.1.43-.333.604-.903.408-1.41a7.002 7.002 0 00-13.074.003z" />
                            </svg>
                        </div>
                        <input type="text" id="last_name" name="last_name" maxlength="100" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " <?php if(isset($last_name)): ?> value=<?php echo e($last_name); ?> <?php endif; ?>>
                    </div>
                    <small id="last_namehelp" class="text-red-700 font-bold"><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                </div>
                <div>
                    <label for="unique_handle" class="block mb-2 text-sm font-medium text-gray-900 ">Unique Handle* <small>[Your shop URL on our site.]</small></label>
                    <div class="relative mb-6">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5 text-gray-500 ">
                                <path d="M10 8a3 3 0 100-6 3 3 0 000 6zM3.465 14.493a1.23 1.23 0 00.41 1.412A9.957 9.957 0 0010 18c2.31 0 4.438-.784 6.131-2.1.43-.333.604-.903.408-1.41a7.002 7.002 0 00-13.074.003z" />
                            </svg>
                        </div>
                        <input type="text" id="unique_handle" name="handle" maxlength="20" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " value="<?php echo e(old('unique_handle')); ?>" required>
                        <input type="hidden" id="isUnique" value="1">
                    </div>
                    <small id="unique_handlehelp" class="text-red-700 font-bold"></small>
                </div>
                <div>
                    <?php $email=old('email') ?>
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 ">Your Email</label>
                    <div class="relative mb-6">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg aria-hidden="true" class="w-5 h-5 text-gray-500 " fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path></svg>
                        </div>
                        <input type="email" id="email" name="email" maxlength="255" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " placeholder="email@example.com" <?php if(isset($email)): ?> value=<?php echo e($email); ?> <?php endif; ?>>
                    </div>
                    <small id="emailhelp" class="text-red-700 font-bold"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                </div>
                <div>
                    <label for="phone" class="block mb-2 text-sm font-medium text-gray-900 ">Phone * <small>[Verified number, Not editable]</small></label>
                    <div class="relative mb-6">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5 text-gray-500 "><path fill-rule="evenodd" d="M2 3.5A1.5 1.5 0 013.5 2h1.148a1.5 1.5 0 011.465 1.175l.716 3.223a1.5 1.5 0 01-1.052 1.767l-.933.267c-.41.117-.643.555-.48.95a11.542 11.542 0 006.254 6.254c.395.163.833-.07.95-.48l.267-.933a1.5 1.5 0 011.767-1.052l3.223.716A1.5 1.5 0 0118 15.352V16.5a1.5 1.5 0 01-1.5 1.5H15c-1.149 0-2.263-.15-3.326-.43A13.022 13.022 0 012.43 8.326 13.019 13.019 0 012 5V3.5z" clip-rule="evenodd" /></svg>
                        </div>
                        <input type="text" id="phone" name="phone" maxlength="10" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " value="<?php echo e($phone); ?>" readonly>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Sign Up</button>
            <button type="reset" class="bg-amber-500 mb-10 hover:bg-amber-600 focus:ring-4 focus:outline-none focus:ring-amber-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Reset</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/agents/SignUp.blade.php ENDPATH**/ ?>