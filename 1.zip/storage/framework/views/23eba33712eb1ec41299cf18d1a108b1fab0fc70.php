<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>
<?php 
    $form_hidden = "";
    if(isset($status) && ($status == 'success'))
    {
        $form_hidden = "hidden";
    } 
?>
<div class="bg-gray-50 h-full py-24 bg-lime-100">
    <div class="w-5/6 md:w-4/12 mx-auto p-5 h-fit mb-5 mt-10 bg-white rounded-lg shadow static-page">
        <h1 class="text-3xl font-bold text-center mb-10">Contact Us</h1>
        <form action="<?php echo e(url('/contact-us')); ?>" method="post" class="<?php echo e($form_hidden); ?>" id="contact_form">
            <?php echo csrf_field(); ?>

            <label for="contact_name" class="block mb-2 text-sm font-medium text-gray-900 ">Your Name</label>
            <div class="relative mb-6">
                <input type="text" id="contact_name" name="contact_name" value="<?php echo e(old('contact_name')); ?>" maxlength="255" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 " placeholder="Enter Your Name" required>
            </div>
            <label for="contact_email" class="block mb-2 text-sm font-medium text-gray-900 ">Your Email</label>
            <div class="relative mb-6">
                <input type="email" id="contact_email" name="contact_email" value="<?php echo e(old('contact_email')); ?>" maxlength="255" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="Enter Your Email Id">
            </div>
            <label for="contact_phone" class="block mb-2 text-sm font-medium text-gray-900 ">Phone Number</label>
            <div class="relative mb-6">
                <input type="text" id="contact_phone" name="contact_phone" value="<?php echo e(old('contact_phone')); ?>" maxlength="255" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="Enter Your Phone Number" required>
            </div>
            
            <button id="verifyPhone" type ="button" class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg     text-sm px-5 py-2.5 text-center mr-2 mb-2">Verify</button>
        
            <!-- For checking purpose phone is verified or not -->
            <input type="hidden" class="status" name="status" value = "0">

            
            <div id="otp_section" class="hidden">
                <label for="contOtp" class="block mb-2 text-sm font-medium text-gray-900 ">OTP</label>
                <div class="relative mb-6">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <svg  aria-hidden="true" class="w-5 h-5 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"></path></svg>
                    </div>
                    <input type="text" id="contOtp" name="otp" maxlength="4" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5    " placeholder="Please enter otp sent on your mobile number">
                </div>
            </div>

            <label for="contact_message" class="block mb-2 text-sm font-medium text-gray-900 ">Message</label>
            <div class="relative mb-6">
                <textarea id="contact_message" name="contact_message" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="Type Message" required><?php echo old('contact_message'); ?></textarea>
            </div>
            <button type="submit" class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Submit</button>
        </form>
        <span class="text-green-800"> <?php echo (isset($form_message)) ? $form_message : '' ; ?></span>
    </div>
    <br>
    <div class="justify-center mx-auto p-5 h-fit mb-2 mt-10 bg-white rounded-lg shadow static-page" style="align-items: center;gap:1rem;max-width:752px" >
        <h2 class="text-base font-medium text-black">Mailing Address</h2>
        <div class="border-b-4 rounded-full border-lime-600 pb-2 w-1/3"></div>
        <div class="mt-5">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline text-lime-500 p-px mr-1">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" /> <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" /></svg>
            Suite B12, BSI Business Park, 161 H Block, Sector 63, Noida
        </div>
        <div class="mt-5">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline text-lime-500 p-px mr-1">
            <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>
            cs@propertyshops.in
        </div>
        <div class="mt-5">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline text-lime-500 p-px mr-1">
            <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" /></svg>
            81302 48912 ( WhatsApp )
        </div>                   
    </div>
    <br>
    <div class="contact-whatsapp flex justify-center mx-auto p-5 h-fit mb-5 mt-10 bg-white rounded-lg shadow static-page" style="align-items: center;gap:1rem;max-width:fit-content">
        <h2 style="font-size: 20px;">Scan the QR code to<br/>Connect with us on WhatsApp</h2>
        <img src="<?php echo e(url('/images/whatsapp_qr.jpg')); ?>" style="max-width: 400px;"/>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/contact_us.blade.php ENDPATH**/ ?>