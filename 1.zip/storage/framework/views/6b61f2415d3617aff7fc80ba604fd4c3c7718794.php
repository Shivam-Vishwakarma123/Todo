<?php $__env->startSection('title', 'Billing'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h2 class="text-4xl font-bold ">Package Details</h2>
</div>
<div class="mb-6">
    <span class="font-bold text-lg bg-yellow-800 text-white">Total credit Balance : <?php echo $agents->credit_balance; ?></span>
    <table class="ps-table">
        <thead>
            <tr>
                <th>ID:</th>
                <th>Date</th>
                <th>Credits Purchased</th>
                <th>Amount Due</th>
                <th>Status</th>
                <th>Invoice</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payment_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($payment->id); ?></td>
                <td><?php echo e(($payment->payment_date == "") ? "" : \Carbon\Carbon::parse($payment->payment_date)->format('d-m-Y')); ?>

                </td>
                <td><?php echo e($payment->plans->credits); ?></td>
                <td><span style="font-family: DejaVu Sans; sans-serif;">&#8377; <?php echo e($payment->amount); ?></span></td>
                <td><?php echo e(($payment->status == "Pending")?"Failed":$payment->status); ?></td>

                <td class="text-blue-600">
                    <?php if($payment->status == "Paid"): ?>
                    <a href='<?php echo e(url('/files/invoices/'.$payment->invoices?->file_name)); ?>'
                        target="_blank">Download
                    </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="m-12">
        <?php echo e($payment_details->render()); ?>

    </div>
</div>
<form style="display: inline" action="<?php echo e(url('agent/credit-plans')); ?>" method="get">
    <button class="text-gray-900 bg-lime-300 font-medium rounded-lg text-sm px-5 py-2.5">Buy More Credits <i
            class="fa-solid fa-arrow-right ml-2"></i></button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/agents/billing.blade.php ENDPATH**/ ?>