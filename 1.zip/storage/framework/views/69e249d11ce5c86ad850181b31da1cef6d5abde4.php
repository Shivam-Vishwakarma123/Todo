<?php $__env->startSection('title', 'Pricing'); ?>

<?php $__env->startSection('content'); ?>

<section class="pt-8 pb-10">
    <div class="h-full">
        <div class="text-center container mx-auto px-8">
            <h1 class=" text-3xl text-black font-semibold">
                Credit Plans
            </h1>
            <h2 class="text-xl text-black ">
                Instead of monthly expiring plans, we are offering credits. You can use 1 credit to publish one
                property.
            </h2>
        </div>
        <br>
        <div class="container mx-auto">
            <div class="grid gap-6 grid-cols-3 mt-5" id="price-container" style="align-items:center; justify-items:center;">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(url('agent/checkout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="basic-box h-80 w-64 rounded-xl ">
                        <input type="hidden" value="<?php echo e($plan->id); ?>" name="id">
                        <h3 class="title-box text-2xl text-center pt-4 pb-4"><?php echo e($plan->name); ?></h3>
                        <div class="box-content flex flex-col justify-center items-center gap-6" style="height:80%;">
                            <div class="view">
                                <div class="cost">
                                    <p class="amount text-xl text-black">&#8377; <?php echo e($plan->price); ?></p>
                                    <br>
                                    <p class="detail text-xl text-black"><?php echo e($plan->credits); ?> Credits</p>
                                </div>
                            </div>
                            
                            <button type="submit"
                                class="bg-transparent hover:bg-lime-600 text-lime-600 font-semibold hover:text-white py-2 px-4 border border-lime-600 hover:border-transparent rounded">
                                Buy Now 
                            </button>
                        </div>
                    </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <br><br>
        <div class="plan-benefits container mx-auto text-center text-lg">
            <br>
            <div class="inline-block text-left px-8">
                <p class="text-xl text-gray-950" style="color:black;">Every plan includes benefits given below:</p>
                <ul class="text-gray-500 list-disc list-inside inline-block text-left">
                    <li>
                        Purchased credits will NEVER expire.
                    </li>
                    <li>
                        Each credit allows you to publish one property listing for 30 days.
                    </li>
                    <li>
                        No Monthly commitment.
                    </li>
                    <li>
                        No Monthly membership.
                    </li>
                    <li>
                        No limit on number of properties published.

                    </li>
                </ul>
            </div>
            <br><br>
            
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/public_site/pricing.blade.php ENDPATH**/ ?>