<?php $__env->startSection('title', 'Contact Request'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
<h2 class="text-4xl font-bold ">Contact Request Details</h2>
</div>
<div class="mb-6">
    <table class="ps-table">
        <thead>
            <tr>
                <th>ID:</th>
                <th>Property_id</th>
                <th>User Name</th>
                <th>Request Date</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $contact_request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnt_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($cnt_request->id); ?></td>
                <td><?php echo e($cnt_request->property_id); ?></td>
                <td><?php echo e($cnt_request->user_name); ?></td>
                <td><?php echo e(($cnt_request->created_at == "") ? "" : \Carbon\Carbon::parse($cnt_request->created_at)->format('d-m-Y')); ?></td>
                <td class="text-blue-600"><a href='<?php echo e(url('/agent/contact-request-listing/' . $cnt_request['id'])); ?>' target="_blank">View Details</a></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/agents/contact_request_listing.blade.php ENDPATH**/ ?>