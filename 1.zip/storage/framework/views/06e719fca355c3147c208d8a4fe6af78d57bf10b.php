<!-- Jquery script -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<!-- tailwind js -->
<script src="<?php echo e(url('js/tailwind.min.js')); ?>"></script>

<!-- flowbite js -->
<script src="<?php echo e(url('js/flowbite.min.js')); ?>"></script>

<!-- Fontawesome link -->
<script src="<?php echo e(url('js/fontawesome.min.js')); ?>"></script>

<!-- function js -->
<script src="<?php echo e(url('js/functions.js')); ?>"></script>

<!-- CUSTOM JS -->
<script src="<?php echo e(url('js/custom.js')); ?>?t=123"></script>

<script src="<?php echo e(url('js/public-custom.js')); ?>?t=123"></script>
<?php /**PATH /home/shivam/www/propertyshops/resources/views/includes/agents/foot.blade.php ENDPATH**/ ?>