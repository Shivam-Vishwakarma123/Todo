<?php $__env->startSection('title', 'Manage Properties'); ?>

<?php $__env->startSection('content'); ?>
    <br>
<div class="text-right">
            <a href="<?php echo e(url('/agent/property/address')); ?>" class="new-property btn-action" >Create New Property</a>
        </div>

    <h1 class="text-3xl font-bold mt-2">Your Properties</h1>
    <table class="ps-table">
        <thead>
            <tr>
                <th scope="col">Property Name</th>
                <th scope="col">City, State</th>
                <th scope="col">Price</th>
                <th scope="col">Count Of Images</th>
                <th scope="col">Count Of Floor Plans</th>
                <th scope="col">Views</th>
                <th scope="col">Published</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <?php if(count($properties) > 0): ?>
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row['name']); ?></td>
                <td>
                    <?php if(!empty($row['city'])): ?> 
                        <?php echo e($row['city']['name']); ?>, 
                    <?php endif; ?> 
                    <?php if(!empty($row['state'])): ?> 
                        <?php echo e($row->state->name); ?>

                    <?php endif; ?> 
                </td>
                <td class="text-right"><span style="font-family: DejaVu Sans, sans-serif;">&#8377; <?php echo e($row['price']); ?> </span></td>
                <td class="text-center"><?php echo e($row->property_images->count()); ?></td>
                <td class="text-center"><?php echo e($row->property_floorplans->count()); ?></td>
                <td class="text-center"><?php echo e($row->views); ?></td>
                <td class="text-center">
                    <?php echo e(($row['published'] == 1) ? "Yes" : "No"); ?><br/> 
                    <?php echo e(($row['published'] == 1) ? "Valid till: " . \Carbon\Carbon::parse($row['expiry_date'])->format('d-m-Y') : ""); ?>

                </td>
                <td class="py-4 px-6">
                    <a href="<?php echo e(url('/agent/property/address/' . $row['unique_url'])); ?>"><svg class="w-6 h-6 fill-lime-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M5.433 13.917l1.262-3.155A4 4 0 017.58 9.42l6.92-6.918a2.121 2.121 0 013 3l-6.92 6.918c-.383.383-.84.685-1.343.886l-3.154 1.262a.5.5 0 01-.65-.65z"></path><path d="M3.5 5.75c0-.69.56-1.25 1.25-1.25H10A.75.75 0 0010 3H4.75A2.75 2.75 0 002 5.75v9.5A2.75 2.75 0 004.75 18h9.5A2.75 2.75 0 0017 15.25V10a.75.75 0 00-1.5 0v5.25c0 .69-.56 1.25-1.25 1.25h-9.5c-.69 0-1.25-.56-1.25-1.25v-9.5z"></path></svg>
                    Edit
                    </a>
                    <a href="<?php echo e(url('/' . $row['unique_url'])); ?>" target="_blank" >
                        <svg class="w-6 h-6 fill-lime-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path clip-rule="evenodd" fill-rule="evenodd" d="M4.25 5.5a.75.75 0 00-.75.75v8.5c0 .414.336.75.75.75h8.5a.75.75 0 00.75-.75v-4a.75.75 0 011.5 0v4A2.25 2.25 0 0112.75 17h-8.5A2.25 2.25 0 012 14.75v-8.5A2.25 2.25 0 014.25 4h5a.75.75 0 010 1.5h-5z"></path>
                        <path clip-rule="evenodd" fill-rule="evenodd" d="M6.194 12.753a.75.75 0 001.06.053L16.5 4.44v2.81a.75.75 0 001.5 0v-4.5a.75.75 0 00-.75-.75h-4.5a.75.75 0 000 1.5h2.553l-9.056 8.194a.75.75 0 00-.053 1.06z"></path>
                        </svg>
                        Preview
                    </a>
                    <?php if($row['published'] == 0): ?>
                        <a href="<?php echo e(url('/agent/property/publish/' . $row['unique_url'])); ?>" >
                            <svg class="w-6 h-6 fill-lime-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                            <path clip-rule="evenodd" fill-rule="evenodd" d="M1 2.75A.75.75 0 011.75 2h16.5a.75.75 0 010 1.5H18v8.75A2.75 2.75 0 0115.25 15h-1.072l.798 3.06a.75.75 0 01-1.452.38L13.41 18H6.59l-.114.44a.75.75 0 01-1.452-.38L5.823 15H4.75A2.75 2.75 0 012 12.25V3.5h-.25A.75.75 0 011 2.75zM7.373 15l-.391 1.5h6.037l-.392-1.5H7.373zM13.25 5a.75.75 0 01.75.75v5.5a.75.75 0 01-1.5 0v-5.5a.75.75 0 01.75-.75zm-6.5 4a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 016.75 9zm4-1.25a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z"></path>
                            </svg>
                            Publish
                        </a>
                        <a href="<?php echo e(url('/agent/property/delete/' . $row['unique_url'])); ?>"  class="delete">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 22 22" stroke-width="1" stroke="currentColor" class="w-6 h-6  fill-red-400">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                            </svg>
                            Delete
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/agent/property/status/' . $row['unique_url'])); ?>" >
                        <?php if($row['active'] == 0): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-6 h-6 fill-cyan-600">
                            <path fill-rule="evenodd" d="M2 3.75A.75.75 0 012.75 3h11.5a.75.75 0 010 1.5H2.75A.75.75 0 012 3.75zM2 7.5a.75.75 0 01.75-.75h6.365a.75.75 0 010 1.5H2.75A.75.75 0 012 7.5zM14 7a.75.75 0 01.55.24l3.25 3.5a.75.75 0 11-1.1 1.02l-1.95-2.1v6.59a.75.75 0 01-1.5 0V9.66l-1.95 2.1a.75.75 0 11-1.1-1.02l3.25-3.5A.75.75 0 0114 7zM2 11.25a.75.75 0 01.75-.75H7A.75.75 0 017 12H2.75a.75.75 0 01-.75-.75z" clip-rule="evenodd" />
                            </svg>
                        Enable
                        <?php else: ?>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-6 h-6 fill-red-600">
                        <path fill-rule="evenodd" d="M2 3.75A.75.75 0 012.75 3h11.5a.75.75 0 010 1.5H2.75A.75.75 0 012 3.75zM2 7.5a.75.75 0 01.75-.75h7.508a.75.75 0 010 1.5H2.75A.75.75 0 012 7.5zM14 7a.75.75 0 01.75.75v6.59l1.95-2.1a.75.75 0 111.1 1.02l-3.25 3.5a.75.75 0 01-1.1 0l-3.25-3.5a.75.75 0 111.1-1.02l1.95 2.1V7.75A.75.75 0 0114 7zM2 11.25a.75.75 0 01.75-.75h4.562a.75.75 0 010 1.5H2.75a.75.75 0 01-.75-.75z" clip-rule="evenodd" />
                        </svg>                              
                        Disable
                        <?php endif; ?>   
                        </a>
                    <?php endif; ?>
                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr class="bg-white border-b ">
                <td class="py-4 px-6 text-center" colspan="8">No Properties Found.</td>
            </tr>
        <?php endif; ?>
    </table>
        <?php echo $properties->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/Property/listing.blade.php ENDPATH**/ ?>