<?php if (isset($component)) { $__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d = $component; } ?>
<?php $component = $__env->getContainer()->make(BenSampo\Embed\ViewComponents\ResponsiveWrapperViewComponent::class, ['aspectRatio' => $aspectRatio]); ?>
<?php $component->withName('embed-responsive-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <iframe 
        src="https://www.youtube.com/embed/<?php echo e($videoId); ?>" 
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d)): ?>
<?php $component = $__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d; ?>
<?php unset($__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d); ?>
<?php endif; ?>
<?php /**PATH /home/shivam/www/propertyshops/resources/views/vendor/embed/services/youtube.blade.php ENDPATH**/ ?>