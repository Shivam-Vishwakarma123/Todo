<?php $__env->startSection('title', 'Address'); ?>

<?php $__env->startSection('content'); ?>
<?php
$country_name = "India";
if(isset($_POST)){
if(isset($property))
{
$data = $property->id;
$agent_id = $property->agent_id;
$unique_url = $property->unique_url;
$address_line_1 = $property->address_line_1;
$city = $property->city_id;
$state = $property->state_id;
$zip = $property->zip;
$country_id = $property->country_id;
$property_type = $property->sale_rent;
}
else{
$data = "";
$agent_id = $agent->id;
$unique_url = old('unique_url');
$address_line_1 = old('address_line_1');
$city = (old('city_name') ? old('city_name') : 'Select City');
$state = (old('state_name') ? old('state_name') : 'Select State') ;
$zip = old('zip');
}
} else {
$data = "";
$agent_id = $agent->id;
$unique_url = "";
$address_line_1 = "";
$city = "Select City";
$state = "Select state";
$zip = "";
}
?>


<form action="<?php echo e(url('/agent/property/store-address',$data)); ?>" id="amenitesForm" method="post">
    <?php echo csrf_field(); ?>
    <h3 class="text-3xl font-bold  my-4">Property Address</h3>
    <div class="grid gap-6 mb-6 md:grid-cols-2">
        <div>
            <label for="address_line_1" class="block mb-2 text-sm font-medium text-gray-900 ">Area / Location</label>
            <input type="text" id="address_line_1" name="address_line_1" maxlength="100"
                value="<?php echo e(isset($address_line_1) ? $address_line_1 : $address_line_1); ?>"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 " />
        </div>
    </div>

    <div class="">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('statecitydropdown', [])->html();
} elseif ($_instance->childHasBeenRendered('EKIz1yl')) {
    $componentId = $_instance->getRenderedChildComponentId('EKIz1yl');
    $componentTag = $_instance->getRenderedChildComponentTagName('EKIz1yl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EKIz1yl');
} else {
    $response = \Livewire\Livewire::mount('statecitydropdown', []);
    $html = $response->html();
    $_instance->logRenderedChild('EKIz1yl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

    <div class="grid gap-6 mb-6 md:grid-cols-2">
        <div>
            <label for="zip" class="block mb-2 text-sm font-medium text-gray-900 ">Pin Code</label>
            <input type="text" id="zip" name="zip" maxlength="6" value="<?php echo e($zip); ?>"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 " />
        </div>
        <input type="hidden" id="country_id" name="country_id" value="<?php echo e(isset($property->country) ? $property->country->name : $country_name); ?>" />
        <input type="hidden" id="agent_id" name="agent_id" value="<?php echo e($agent_id); ?>"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 " />

    </div>
    <button type="submit"
        class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">
        <span>Save & Next</span>
    </button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agents.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shivam/www/propertyshops/resources/views/Agent/Property/address.blade.php ENDPATH**/ ?>