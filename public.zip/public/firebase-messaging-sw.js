importScripts('https://www.gstatic.com/firebasejs/8.3.2/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.3.2/firebase-messaging.js');

firebase.initializeApp({apiKey: "AIzaSyBrjNp9pWAuaoED41pJm8OFnm1nIKfNqlQ", projectId: "propertyshops-testing", messagingSenderId: "186312166603", appId: "1:186312166603:web:1de259d97b35052dd71f4e"});

const messaging = firebase.messaging();
messaging.setBackgroundMessageHandler(function (payload) {
    console.log("[firebase-messaging-sw.js] Received background message ", payload,);

    const notificationTitle = "Background Message Title";
    const notificationOptions = {
        body: "Background Message body.",
        // icon: "https://propertyshops.in/images/ps-logo.png",
    };

    return self.registration.showNotification(notificationTitle, notificationOptions,);
});
