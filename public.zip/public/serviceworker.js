var staticCacheName = "propertyshops-cache" + new Date().getTime();
var filesToCache = [
    '/offline',
    '/css/app.css',
    '/css/custom.css',
    '/css/public-custom.css',
    '/css/cloudare-cdn-jquery-ui.min.css',
    '/css/flowbite.min.css',
    '/css/fontawesome.min.css',
    '/css/jsdeliver.min.css',
    '/css/lc_lightbox.min.css',
    '/js/app.js',
    '/js/custom.js',
    '/js/fontawesome.min.js',
    '/js/functions.js',
    '/js/jquery.min.js',
    '/js/jsdeliver.min.js',
    '/js/lc_lightbox.min.js',
    '/js/public-custom.js',
    '/js/tailwind.min.js',
    '/js/backend/custom.js',
    '/images/icons/icon-72x72.png',
    '/images/icons/icon-96x96.png',
    '/images/icons/icon-128x128.png',
    '/images/icons/icon-144x144.png',
    '/images/icons/icon-152x152.png',
    '/images/icons/icon-192x192.png',
    '/images/icons/icon-384x384.png',
    '/images/icons/icon-512x512.png',
    '/images/icons/splash-640x1136.png',
    '/images/icons/splash-750x1334.png',
    '/images/icons/splash-828x1792.png',
    '/images/icons/splash-1125x2436.png',
    '/images/icons/splash-1242x2208.png',
    '/images/icons/splash-1536x2048.png',
    '/images/icons/splash-1668x2224.png',
    '/images/icons/splash-1668x2388.png',
    '/images/icons/splash-2048x2732.png',
    '/images/favicon-48x48.ico',
    '/images/logo-hb.png',
    '/images/logo-hw.png',
    '/images/logo-vb.png',
    '/images/logo-vw.png',
    '/images/logo1.png',
    '/images/ps-logo.png',
    '/images/default_image.png',
    '/vendor/livewire/livewire.js',
    '/vendor/livewire/livewire.js.map',
    '/vendor/livewire/manifest.js',
    '/webfonts/fa-brands-400.eot',
    '/webfonts/fa-brands-400.svg',
    '/webfonts/fa-brands-400.ttf',
    '/webfonts/fa-brands-400.woff',
    '/webfonts/fa-brands-400.woff2',
    '/webfonts/fa-regular-400.eot',
    '/webfonts/fa-regular-400.svg',
    '/webfonts/fa-regular-400.ttf',
    '/webfonts/fa-regular-400.woff',
    '/webfonts/fa-regular-400.woff2',
    '/webfonts/fa-solid-900.eot',
    '/webfonts/fa-solid-900.svg',
    '/webfonts/fa-solid-900.ttf',
    '/webfonts/fa-solid-900.woff',
    '/webfonts/fa-solid-900.woff2',
    '/webfonts/fonts/summernote.eot',
    '/webfonts/fonts/summernote.ttf',
    '/webfonts/fonts/summernote.woff',
    '/webfonts/fonts/summernote.woff2'
];

// Cache on install
self.addEventListener("install", event => {
    this.skipWaiting();
    event.waitUntil(
        caches.open(staticCacheName)
            .then(cache => {
                return cache.addAll(filesToCache);
            })
    )
});

// Clear cache on activate
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames
                    .filter(cacheName => (cacheName.startsWith("pwa-")))
                    .filter(cacheName => (cacheName !== staticCacheName))
                    .map(cacheName => caches.delete(cacheName))
            );
        })
    );
});

// Serve from Cache
self.addEventListener("fetch", event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                return response || fetch(event.request);
            })
            .catch(() => {
                return caches.match('offline');
            })
    )
});