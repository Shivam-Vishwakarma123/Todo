
// ############################################################
// js to hide and show navigation menu bar starts
// function to show navigation menu bar starts
function open_Nav_Menu() {
    $('#nav-menu').fadeToggle();
    $('#nav-menu').toggleClass('hidden');
}

// function to close the navigation menu code starts
function close_Nav_Menu() {
    $('#nav-menu').fadeToggle();
    $('#nav-menu').toggleClass('hidden');
}

// js to hide and show navigation menu bar ends

/**
 * This function applied the styles of tailwind input and text area to new elements.
 * Just pass the wrapper element selector to this function. This selector should include only newly added elements.
 */
function apply_tailwind_styles(selector) {
    $( selector + " input, " + selector + " textarea").each(function() {
        $(this).focus(function(){ $(this).parent().addClass("focused")});
        $(this).blur(function(){ 
            $(this).parent().removeClass("focused");
            if($(this).val() != "") {
                $(this).parent().addClass("is-filled");    
            } else {
                $(this).parent().removeClass("is-filled");
            }
        });
        
        if($(this).val() != "") {
            $(this).parent().addClass("is-filled");    
        } else {
            $(this).parent().removeClass("is-filled");
        }
    });
}

//   js to show toast message starts
function showPopUp(type , message)
{
    var html = "";
    html += "<div id='toast-message' class='flex items-center absolute top-5 right-5 p-4 mb-4 w-full max-w-xs text-gray-500 bg-white rounded-lg shadow z-20' role='alert'>";
    if(type == 'success')
    {
        html +=  "<div class='inline-flex flex-shrink-0 justify-center items-center w-8 h-8 text-green-500 bg-green-100 rounded-lg '>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z' clip-rule='evenodd'></path></svg>";
        html +=  "<span class='sr-only'>Check icon</span>";
        html +=  "</div>";
        html +=  "<div class='ml-3 text-sm font-normal'>" + message + "</div>";
        html +=  "<button type='button' class='ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex h-8 w-8' id='hideToastIcon'>";
        html +=  "<span class='sr-only'>Close</span>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z' clip-rule='evenodd'></path></svg>";
    }
    else if(type == 'error')
    {
        html +=  "<div class='inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-red-500 bg-red-100 rounded-lg dark:bg-red-800 dark:text-red-200 '>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z' clip-rule='evenodd'></path></svg>";
        html +=  "<span class='sr-only'>Check icon</span>";
        html +=  "</div>";
        html +=  "<div class='ml-3 text-sm font-normal'>" + message + "</div>";
        html +=  "<button type='button' class='ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex h-8 w-8' id='hideToastIcon'>";
        html +=  "<span class='sr-only'>Close</span>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z' clip-rule='evenodd'></path></svg>";
    }
    else if(type == 'warning')
    {
        html +=  "<div class='inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-orange-500 bg-orange-100 rounded-lg dark:bg-orange-700 dark:text-orange-200'>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z' clip-rule='evenodd'></path></svg>";
        html +=  "<span class='sr-only'>Check icon</span>";
        html +=  "</div>";
        html +=  "<div class='ml-3 text-sm font-normal'>" + message + "</div>";
        html +=  "<button type='button' class='ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex h-8 w-8' id='hideToastIcon'>";
        html +=  "<span class='sr-only'>Close</span>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z' clip-rule='evenodd'></path></svg>";
    }
    else if(type == 'info')
    {
        html +=  "<div class='inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-blue-500 bg-blue-100 rounded-lg dark:bg-blue-800 dark:text-blue-200'>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z' clip-rule='evenodd'></path></svg>";
        html +=  "<span class='sr-only'>Check icon</span>";
        html +=  "</div>";
        html +=  "<div class='ml-3 text-sm font-normal'>" + message + "</div>";
        html +=  "<button type='button' class='ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex h-8 w-8' id='hideToastIcon'>";
        html +=  "<span class='sr-only'>Close</span>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z' clip-rule='evenodd'></path></svg>";
    }
    else
    {
        html +=  "<div class='inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-orange-500 bg-orange-100 rounded-lg dark:bg-orange-700 dark:text-orange-200'>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z' clip-rule='evenodd'></path></svg>";
        html +=  "<span class='sr-only'>Check icon</span>";
        html +=  "</div>";
        html +=  "<div class='ml-3 text-sm font-normal'>Something Went Wrong</div>";
        html +=  "<button type='button' class='ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex h-8 w-8' id='hideToastIcon'>";
        html +=  "<span class='sr-only'>Close</span>";
        html +=  "<svg aria-hidden='true' class='w-5 h-5' fill='currentColor' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'><path fill-rule='evenodd' d='M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z' clip-rule='evenodd'></path></svg>";
    }
    html +=  "</button>";
    html +=  "</div>";
    // to show flash messages inside body
    $("body").append(html);
    // to hide toast message box auto after 5 seconds
    setTimeout(function() { $('#toast-message').remove(); }, 5000);
    // $(document).on("click","#hideToastIcon",function(){
    //     console.log("gsfsh");
    //     $('#toast-message').remove();
    // });
}
//   js to show toast message ends


//delete property  image 

function deleteImage(id){
    $.ajax({
        type: "GET",
        url: web_url +  "/agent/property-images/delete-images/"+id,
        success: function(response){
            if(response.success==0){
                showPopUp('error' , response.error);
              }else{
                $('#'+id).remove();
                showPopUp('success' , response.message);
                  
              }            
          }
      });
}

//  Property Document Delete Function Start ========
 
function deleteDocument(id,property_id){
    $("#dialog").addClass("open");
    $('.dialog-msg').html("Do you really want to delete the document ?");

    // if user click on dialog's box button NO then remove this dialog box event
    $("#dialog").click(function() {
        $(".dialog-yes-btn").unbind();
    });
    
    //Attach document delete function to yes button
    $("#dialog .dialog-yes-btn").click(function(){
        $("#dialog").removeClass("open");
        $.ajax({
           type: "GET",
           url:  web_url +  "/agent/property-document/delete-document/"+property_id,
           success: function(response){
            $('#documentfilename'+id).remove();
              if(response.success==0){
                    showPopUp('error' , response.error);
                }else{
                    showPopUp('success' , response.message);
                }
            }
        })
    });
 }

 //  Property Document Delete Function End ==========

//  Property Document Delete Function Start ========
 
function deletehotspot(id,file_name,floorplan_id,property_id) {
    $("#dialog").addClass("open");
    $('.dialog-msg').html("Do you really want to delete the Hotspot ?");

    // if user click on dialog's box button NO then remove this dialog box event
    $("#dialog").click(function() {
        $(".dialog-yes-btn").unbind();
    });

    //Attach document delete function to yes button
    $("#dialog .dialog-yes-btn").click(function(){
        $("#dialog").removeClass("open");
        $.ajax({
           type: "GET",
           url:  "../delete-hotspot",
           data:{id:id},
           success: function(response){
                $('#hotspot'+id).remove();
                $('#HotspotData'+id).remove();
              if(response.success==0){
                    showPopUp('error' , response.error);
                }else{           
                    location.reload();
                    // source = '';
                    // source += '<div class="relative">';
                    // source += '<img src="' + web_url + '/files/property_images/'+ property_id +'/' + file_name + '" data-id="' + id + '" class="' + floorplan_id + ' w-52 h-48 m-3 inline-block hotspot-image">';
                    // source += '<div ondragstart="onDragStart(event);"  id="' + id + '" draggable="true" class ="' + floorplan_id + ' absolute inset-0 w-52 m-3 h-48 z-30" style="cursor:crosshair;"></div>';
                    // source += '</div>';
                    // $('#Drag_Box').append(source);
                    // showPopUp('success' , response.message);        
                }
            }
        });
    });
 }

//  Property Floor Plan Delete Function Start ========
 
function deleteFloorplan(id,property_id){
    $("#dialog").addClass("open");
    $('.dialog-msg').html("Do you really want to delete the Floor plan ?");

    // if user click on dialog's box button NO then remove this dialog box event
    $("#dialog").click(function() {
        $(".dialog-yes-btn").unbind();
    });

        //Attach document delete function to yes button
    $("#dialog .dialog-yes-btn").click(function(){
        $("#dialog").removeClass("open");
        $.ajax({
           type: "GET",
           url:  web_url +  "/agent/property-floorplan/delete-floorplan/"+property_id,
           success: function(response){
               if(response.success==0){
                   showPopUp('error' , response.error);
                }else{
                    $('#floorplan_block'+id).remove();
                    showPopUp('success' , response.message);
                }
            }
        })
    });
}
//  Property Floor Plan Delete Function End ==========

// Property Floor Plan Image Name Chnage Function Start ==========
function changeFloorPlanImageName(id,floorplanId){
    var FileName = $("#fileName"+id).text();
    $.ajax({
        type: "GET",
        data : {id:id,name:FileName,floorplanId:floorplanId},
        url:  web_url +  "/agent/property-floorplan/save-floorplans",
        success: function(data){
            $('#'+id).remove();
            if(data.success==0){
                    showPopUp('error' , data.error);
                }else{
                    showPopUp('success' , data.message);
                }
            }
        })
}

// Property Floor Plan Image Name Chnage Function End ==========
// Property Floor Plan Custom js End

// Hide and show delete button of image

 // Rotate the image
 function rotateImage(id){
    $(".image-rotate-wrap").css("display","flex");
    $(".image-rotate-wrap").css("background-color", "#0000007a");
    $('#rotate_img').attr('src', $('#image'+id).attr('src') );
    $('#rotate_id').val(id);
    // console.log($("#rotate_img").val());
    $("#direction").val(0);     //reset direction for next rotate
 }

 // Right Rotation of Image
function rightRotateImg() {
    rotation = parseInt($('#direction').val());
    rotation += 90; // add 90 degrees, you can change this as you want
    if (rotation === 360) {         
    rotation = 0;  // 360 means rotate back to 0
    }
    document.querySelector("#rotate_img").style.transform = `rotate(${rotation}deg)`;
    document.querySelector("#direction").value = `${rotation}`;
}

//  Left Rotation of Image
function leftRotateImg() {
    rotation = parseInt(document.querySelector("#direction").value);
    rotation -= 90; // add 90 degrees, you can change this as you want
    if (rotation === -360) { 
    rotation = 0;  // 360 means rotate back to 0
    }
    document.querySelector("#rotate_img").style.transform = `rotate(${rotation}deg)`;
    document.querySelector("#direction").value = `${rotation}`;
}

// Close The rotate Image body

function closeRotateImage(){
    $(".image-rotate-wrap").hide();
    $("#direction").val(0);     //reset direction for next rotate
    $("#rotate_img").css("transform","");

}

// Save The Image Rotate 
function saveImageRotate(){

    var degrees = document.querySelector("#direction").value;
    var id = document.querySelector("#rotate_id").value;
    const time = new Date();

    $.ajax({
        type: "GET",
        url: web_url + "/agent/property-images/rotate-images/"+id,
        data:{"degrees":degrees},
        success: function(response){

            $(".image-rotate-wrap").hide();
            showPopUp('success' , 'Image Rotate Successfully');
            
            //update the image in page with a new url with timestamp
            $('#image' + id).attr('src', web_url  + '/files/property_images/' + response.property_id + '/' + response.file_name + '?q=' + time.getTime());
            
            $("#rotate_img").removeAttr('style');           //reset style for image in popup
            
            $("#direction").val(0);     //reset direction for next rotate
        }
    });
} 

function allowDrop(ev) {
    ev.preventDefault();   
}

function drag(ev,id,property_id){ 
   $("#property_id").val(property_id);
    ev.dataTransfer.setData("text", ev.target.id); 
    ev.dataTransfer.setData("div_id", id);    
} 
function drop(ev){   
    if($("#sequence").val()==0){
       gallery_id=[];
    }  
    ev.preventDefault(); 
    sequence=parseInt($("#sequence").val());
    sequence=sequence+1;   
    var data = ev.dataTransfer.getData("text");    
     this.gallery_id.push(data);    
    $("#"+data).removeAttr("ondragstart");
    var div=document.createElement('div');
    // Add Attribute for jquery-ui sortable grid class name (ui-state-default)
    div.setAttribute('class','inline ui-state-default');
    var div1=document.createElement('div');
    div1.setAttribute('class','w-52 h-48 ml-3 mt-3 inline-table border-2');
    var span=document.createElement('span');
    span.setAttribute('class','mt-3  top-1  relative p-1 pl-2 pr-2 bg-blue')
    span.setAttribute('name','sequence');
    span.append(sequence);
    document.getElementById('sequence').value=sequence;
    div1.append(ev.target.appendChild(document.getElementById(data)),span);
    div.append(div1);
    document.getElementById('div1').append(div);
    div_id=ev.dataTransfer.getData("div_id");  
    $("#"+div_id).remove();
} 

// Add a New Gallery
function addGallery(){
    gallery_id =  gallery_count;

    html = "";
    html += '<form action="" id="' + gallery_id + '" method="post">';
    html += '<div class="input-group input-group-outline mt-3 mb-3">';
    html += '<label class="form-label">Gallery name</label>';
    html += '<input type="text" name="gallery_name" maxlength="100" value = "Gallery ' + gallery_count +'" id="gallery_name' + gallery_count + '" class="form-control" />';
    html += '</div>';
    html += '<div class="input-group input-group-outline mt-3 mb-3">';
    html += '<label for="short_description" class="form-label">Short Description</label>';
    html += '<textarea id="short_description' + gallery_count + '" name="short_description" maxlength="255" class="form-control"></textarea>';
    html += '</div>';
    html += '<div class="border h-96 overflow-auto" id="Drop_Box' + gallery_count +'"></div>';
    html += '<input type="hidden" value="' + gallery_count + '" id="sequence" name="sequence" />';
    html += '<input type="hidden" id="gallery_id'+ gallery_count +'" value=0>';
    html += '<a href="#" class="button button-green mt-1" onclick="saveImageGallery(' + gallery_count +');"  data-ripple-light="true">Save Gallery ' + gallery_count +'</a>';
    html += '</form>';
    $("#gallery").append(html);
    
    //Apply tailwind styules to new added elemnts
    apply_tailwind_styles("#" + gallery_id);

    DropBox = document.getElementById('Drop_Box' + gallery_count),
    new Sortable(DropBox, {
        group: 'shared', // set both lists to same group
        animation: 150
    });

    gallery_count++;
}

// delete image gallery 
function deleteImagegallery(sequence,gallery_id){
    // for remove form get gallery childer form tag
    var gallery = $('#gallery').children('form').length;

    $("#dialog").addClass("open");
    $('.dialog-msg').html("Do you really want to delete the Gallery ?");

    // if user click on dialog's box button NO then remove this dialog box event
    $("#dialog").click(function() {
        $(".dialog-yes-btn").unbind();
    });

    //Attach gallery delete function to yes button
    $("#dialog .dialog-yes-btn").click(function(){
        $("#dialog").removeClass("open");

            $.ajax({
                type: "GET",
                url: web_url +  "/agent/galleries/delete-property-galleries",
                dataType: 'json',
                data:{"sequence":sequence,"gallery_id":gallery_id,"gallery_length":gallery},
                success: function(data){
                    if (data['response'] == 1) {
                        $('#saveimagegallery' + sequence).remove();
                        // when we have on one gallery then remove delete button on deleteting second last gallery
                        if(gallery == 2) {
                            $('.deleteimagegallery').remove();
                        }
                        showPopUp('success', data['message']);
                    } else {
                        showPopUp('error' , data['message']);
                        
                    }
                }
            });
        });
}
// Save Gallery Image 
function saveImageGallery(sequence){
    var Drop_img_id = [];
    if(sequence){
        if(document.getElementById('Drop_Box'+sequence).innerHTML){
            id = $("#gallery_id" + sequence).val();
            gallery_name=$("#gallery_name"+sequence).val();
            default_image = $("#default_image" + sequence).val();
            short_description=$('#short_description'+sequence).val();
            Drop_Box = $('#Drop_Box'+sequence).children('.inline-block');
            Drop_Box.each(function(){
                Drop_img_id.push( $(this).attr('id'));
            });
        }
    }

    if(Drop_img_id.length == 0 ){
        showPopUp('error' , 'Requierd Gallery Image');
        return false;
    }
    $.ajax({
        type: "GET",
        url: web_url +  "/agent/galleries/property-galleries",
        dataType: 'json',
        data:{"id":id,"gallery_name":gallery_name,"short_description":short_description,"default_image":default_image,"Drop_img_id":Drop_img_id},
        success: function(data){
            if (data['response'] == 1) {

                //Set gallery id in hidden field
                $("#gallery_id" + sequence).val(data["gallery_id"]);

                showPopUp('success' , 'success');
                setTimeout(() => {
                    location.reload();
                }, 1000);  
                }
            }
        })
}

// $('.default_image').chosen({
//     width:"100%",
//     html_template:'{text}<img style="border:3px solid #ff703d;padding:0px;margin-right:4px"  class="{class_name}" src="{url}" />'
// })
function saveImageSlider(){
    var Drop_img_id = [];
        if(document.getElementById('Drop_Box').innerHTML){
            id = $("#gallery_id").val();
            Drop_Box = $('#Drop_Box').children('.inline-block');
            Drop_Box.each(function(){
                Drop_img_id.push( $(this).attr('id'));
            });
        }

    if(Drop_img_id.length == 0 ){
        showPopUp('error' , 'Error on updating slider');
        return false;
    }
    $.ajax({
        type: "GET",
        url: web_url +  "/agent/property-topbar/feature-slider",
        dataType: 'json',
        data:{"id":id,"Drop_img_id":Drop_img_id},
        success: function(data){
            if (data['success'] == 1) {
                showPopUp('success' , 'Successfully Updated Slider');
                }
            }
        })
}
// Save topbar for property as Image, Video, Slider
function saveForProperty(obj){
    choose_type = $(obj).data('subject');
    $.ajax({
        type: "GET",
        url: web_url +  "/agent/property-topbar/selection-for-top",
        dataType: 'json',
        data:{"type":choose_type},
        success: function(data){
            if (data['success'] == 1) {
                showPopUp('success' , data.message);
                    var image = $('.saveforimage');
                    var slider = $('.saveforslider');
                    var video = $('.saveforvideo');

                    if(data['topbar'] == "Image") {
                        image.attr({'onclick': '','data-subject': ''});
                        image.attr('class','button button-grey mt-1 float-right saveforimage')

                        slider.attr({'onclick': 'saveForProperty(this)','data-subject': 'slider'});
                        slider.attr('class','button button-green mt-1 float-right saveforslider')

                        video.attr({'onclick': 'saveForProperty(this)','data-subject': 'video'});
                        video.attr('class','button button-green mt-1 float-right saveforvideo')

                    } else if(data['topbar'] == "Slider"){

                        image.attr({'onclick': 'saveForProperty(this)','data-subject': 'image'});
                        image.attr('class','button button-green mt-1 float-right saveforimage')

                        slider.attr({'onclick': '','data-subject': ''});
                        slider.attr('class','button button-grey mt-1 float-right saveforslider')

                        video.attr({'onclick': 'saveForProperty(this)','data-subject': 'video'});
                        video.attr('class','button button-green mt-1 float-right saveforvideo')

                    } else if(data['topbar'] == "Video"){

                        image.attr({'onclick': 'saveForProperty(this)','data-subject': 'image'});
                        image.attr('class','button button-green mt-1 float-right saveforimage')

                        slider.attr({'onclick': 'saveForProperty(this)','data-subject': 'slider'});
                        slider.attr('class','button button-green mt-1 float-right saveforslider')

                        video.attr({'onclick': '','data-subject': ''});
                        video.attr('class','button button-grey mt-1 float-right saveforvideo')

                    }
                } else {
                    showPopUp('error' , data.message);
                }
            }
        })
}


// Property Video Custom js Start Here -------------------

// Add Property Cover Video
 function coverVideo(video_id){
    $.ajax({
        type: "GET",
        url: "cover-video",
        data:{'video_id':video_id},
        success: function(response){
            if(response.success==0){
                showPopUp('error' , response.error);
           }else{
                showPopUp('success' , response.message);
            }           
        }              
      })     
 }
 
// Add Property Featured Video
function featureVideo(video_id,obj){
    $.ajax({
        type: "GET",
        url: web_url + "/agent/video/feature-video",
        data:{'video_id':video_id},
        success: function(response){
            if(response.success==0){
                showPopUp('error' , response.error);
           }else{
                showPopUp('success' , response.message);
                // here I display all featuredvideo class element
                // And hide all currentvideo class element
                // And hide current click element
                // And find the siblings of current object and display

                $('.featuredvideo').show();
                $('.currentvideo').hide();
                $(obj).hide();
                $(obj).siblings().show();
            }           
        }
      })        
 }

//  Add property Featured Image
    function saveFeatureImage(image_id,obj){
        $.ajax({
            type: "GET",
            url: web_url + "/agent/property-topbar/feature-image",
            data:{'image_id':image_id},
            success: function(response){
                if(response.success==0){
                    showPopUp('error' , response.error);
               }else{
                    showPopUp('success' , response.message);
                // here I display all featuredvideo class element
                // And hide all currentvideo class element
                // And hide current click element
                // And find the siblings of current object and display

                $('.featureimage').show();
                $('.currentimage').hide();
                $(obj).hide();
                $(obj).siblings().show();
                    
                }           
            }
          })    
    }

    function saveFeatureGalleryImage(gallery_image_id,gallery_id,obj){
        $.ajax({
            type: "GET",
            url: web_url + "/agent/galleries/save_featured_gallery_images",
            data: {'gallery_image_id':gallery_image_id,'gallery_id':gallery_id},
            success: function(response){
                if(response.success==0){
                    showPopUp('error' , response.message);
               }else{
                    showPopUp('success' , response.message);
                    // here I display all featuredgalleryimage class element
                    // And hide all currentgalleryimage class element
                    // And hide current click element
                    // And find the siblings of current object and display

                    $('.featuredgalleryimage').show();
                    $('.currentgalleryimage').hide();
                    $(obj).hide();
                    $(obj).siblings().show();
                }           
            }
          }) 
    }
 // Delete the Property video
 
 function deleteVideo(id){
    $.ajax({
        type: "GET",
        url: "delete-video/"+id,
        success: function(response){
            $('#'+id).remove();
            if(response.success==0){
            showPopUp('error' , response.error);
            }else{
                showPopUp('success' , response.message);
                setTimeout(() => {
                    location.reload();
                },0);
            }            
        }
    })
 }

 // Save the 3d matter port url
   function save3D_Url(){
        matterport_url=$("#matterport_url").val();
        if(matterport_url == ""){
            showPopUp('error' , 'The matterport url field is required');
        }else{
          index=matterport_url.indexOf('https://');
          if(index == -1 || index != 0){
             matterport_url='https://'+matterport_url;
           }
           $("#matterport_url").val("");
            $.ajax({
                type: "GET",
                url: "save-matterport-url",
                data:{'matterport_url':matterport_url},
                datatype:'json',
                success: function(response){
                   if(response.success==0){
                        showPopUp('error' , response.error);
                   }else{   
                    showPopUp('success' , response.message);
                        html = "";
                        html += '<tr id="'+ response.matterport_id +'">';
                        html += '<td><iframe width="300" height="200" class="overflow-hidden" src="'+ response.matterport_url + '" frameborder="0" allowfullscreen allow="xr-spatial-tracking"></iframe></td>';
                        html += '<td class="p-2 text-2xl">'+ response.matterport_url + '</td>';
                        html += '<td> <a href="#" onclick="delete3D_Url('+ response.matterport_id +');" class="button button-red ml-5 delete">Delete</a></td>';
                        html += '<tr>';
                        $(".table_3durl").append(html);      
                    }                    
                }    
            });
        }    
    }

  // 3d matter port url delete alert show

 function delete3D_Url(id){
   $("#dialog").addClass("open");
    $('.dialog-msg').html("Do you really want to delete the 3d matterport url ?");
        //Attach image delete function to yes button
    $("#dialog .dialog-yes-btn").click(function(){
        $("#dialog").removeClass("open");
        $.ajax({
           type: "GET",
           url: "delete-matterport-url/"+id,
           success: function(response){
              $('#'+id).remove();
              if(response.success==0){
                showPopUp('error' , response.error);
                }else{
                    showPopUp('error' , response.message);
                }
            }
        })
    });
 }
// Property Video Custom js End Here -------------------


//Use the below code to show the location map for the property

// Update the Address Map
// function updateMap(){
//    let address_line_1=$("#address_line_1").val();
   
//    let city=$("#city").val();
//    let state=$("#state :selected").val();
//    let country= $.trim($('#country').text());
//    $('.custom-shadow').attr('src',"https://maps.google.com/maps?width=600&q=" + encodeURIComponent(address_line_1 +" " + city +" " + state +" " + country) + "&output=embed");
// }

// // Save the Address Map

// function saveMap(){
//    let address_line_1=$("#address_line_1").val();
//    let city=$("#city").val();
//    let state=$("#state").val();
//    let zip=$("#zip").val();
//    let country=$("#country").val();
//     $.ajax({
//         type: "get",
//         url: "update-address-map",
//         data:{'address_line_1':address_line_1,'city':city,'state':state,'zip':zip,'country':country},
//         datatype:'json',
//         success: function(response){
//             if(response.success==0){
//                 showPopUp('error' , response.error);
//             }else{   
//                 showPopUp('success' , response.message);
//             }                    
//         }    
//     });    
// }


// Add Code for copy property url in agent default url section in sidebar 
function copyPropertyUrl() {
    // Get the text field
    var copyText = document.getElementById("propertyUrl").innerHTML;

    // Copy the text inside the field
    navigator.clipboard.writeText(copyText);
    
    // Notification the copied text
    showPopUp('success' , 'Copied the clipboard');
}

//  Delete Profile Image

function deleteProfileImage(){
    $("#dialog").addClass("open");
    $('.dialog-msg').html("Do you really want to delete the Profile Image ?");

    // if user click on dialog's box button NO then remove this dialog box event
    $("#dialog").click(function() {
        $(".dialog-yes-btn").unbind();
    });

        //Attach image delete function to yes button
    $("#dialog .dialog-yes-btn").click(function(){
        $("#dialog").removeClass("open");
        $.ajax({
           type: "GET",
           url: "delete-profile-image/",
           success: function(response){
            if(response.success==0){
                showPopUp('error' , response.error);
              }else{
                showPopUp('success' , response.message);
              }
             $("#upload-profile").css("display", "block");
             $('#delete-profile').css('display','none');
          }
        })
    });
}

//  Delete Profile Image

function deleteLogoImage(){
    $("#dialog").addClass("open");
    $('.dialog-msg').html("Do you really want to delete the Logo Image ?");

    // if user click on dialog's box button NO then remove this dialog box event
    $("#dialog").click(function() {
        $(".dialog-yes-btn").unbind();
    });

        //Attach image delete function to yes button
    $("#dialog .dialog-yes-btn").click(function(){
        $("#dialog").removeClass("open");
        $.ajax({
           type: "GET",
           url: "delete-logo-image/",
           success: function(response){
            if(response.success==0){
                showPopUp('error' , response.error);
              }else{
                showPopUp('success' , response.message);
              }
              $("#upload-logo").css("display", "block");
              $('#delete-logo').css('display','none'); 
          }
        })
    });
}


// add validation on agent profile email edit

function validation(){
    var email =document.getElementById('email');
    if(email.value != '' && ValidateEmail() == false ) {
        return false;
    }
}
function ValidateEmail(){
    var email =document.getElementById('email');
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(email.value.match(mailformat)) {   
        document.getElementById("small-email").innerHTML = "";
        return true;  
    } else {
        document.getElementById("small-email").innerHTML = "The entered email is not a valid email.";
        document.getElementById("small-email").style.color = "red";
        return false;
    }
}

var floorplansName = 1;
// Add the value filled in signup form
function validaAddress(frm){

    document.getElementById('cityhelp').innerHTML = "";
    document.getElementById('phonehelp').innerHTML = "";
    document.getElementById('countrieshelp').innerHTML = "";
    document.getElementById('statehelp').innerHTML = "";
    document.getElementById('cityhelp').innerHTML = "";
    document.getElementById('ziphelp').innerHTML = "";

    var failed = false;
    var phone = frm.phone.value;
    if (phone == '') {
        document.getElementById('phonehelp').innerHTML = "* Phone Number filled are required";
        failed = true;
    }
    var countries = frm.countries.value;
    if (countries == 0) {
        document.getElementById('countrieshelp').innerHTML = "* Country filled are required";
        failed = true;
    }
    var state = frm.state.value;
    if (state == '') {
        document.getElementById('statehelp').innerHTML = "* State filled are required";
        failed = true;
    }
    var city = frm.city.value;
    if (city == '') {
        document.getElementById('cityhelp').innerHTML = "* City filled are required";
        failed = true;
    }
    
    var zip = frm.zip.value;
    if (zip == '') {
        document.getElementById('ziphelp').innerHTML = "* Zip filled are required";
        failed = true;
    }
    var address = frm.address.value;
    if (address == '') {
        document.getElementById('addresshelp').innerHTML = "* City filled are required";
        failed = true;
    }

    if(!failed) {
        return true;
    } else {
        return false;
    }
}

// Append the Amenities data
function append_amenities(Amenities){
    id=Amenities.id;
    if($('#addAmenities').find("#"+id).length == 0){
        const addAmenities=document.getElementById('addAmenities');
        const amenities=Amenities.cloneNode(true).innerHTML;
        $("#"+id).remove();

        let span = document.createElement("span");
        span.classList.add("amenitiesbutton");
        span.innerHTML = amenities;

        let input = document.createElement("input");
        input.type="text";
        input.value=amenities;
        input.setAttribute("type", "hidden");
        input.setAttribute('value',amenities);
        input.setAttribute("class", "amenitiesbutton");
        
        let a = document.createElement("a");
        a.setAttribute("href", 'javascript:void(0);');
        a.classList.add("amenitiesbutton1", id);
        a.setAttribute("data-name", amenities);
        a.setAttribute("id", id);
        // a.append('x');
        
        let div = document.createElement("div");
        div.setAttribute("class","p-amenitie is-filled");
        div.append(span,input);
        a.append(div); 
        addAmenities.append(a);
        var amenitites_id = document.getElementById("amenities_array").value;
        if( amenitites_id == ''){
             Array_amenities = [];
         }else{
            Array_amenities = amenitites_id.split(",");
         }
        Array_amenities.push(id);
        document.getElementById("amenities_array").value = Array_amenities;
    }
}

// TODO: Reduce function for adding amenites 

function add_amenities() {
    const amenite = $('#add_amenitie')[0].value;
    const addAmenities=document.getElementById('addAmenities');
    let span = document.createElement("span");
    span.classList.add("amenitiesbutton");
    span.innerHTML = amenite;


    let input = document.createElement("input");
    input.type="text";
    input.value=amenite;
    input.setAttribute("type", "hidden");
    input.setAttribute('value',amenite);
    input.setAttribute("class", "amenitiesbutton");
    
    let a = document.createElement("a");
    a.setAttribute("href", 'javascript:void(0);');
    a.classList.add("amenitiesbutton1");
    a.setAttribute("data-name",amenite);
    // a.append('x');
    
    let div = document.createElement("div");
    div.append(span,input);
    div.setAttribute("class","p-amenitie is-filled");
    a.append(div);
    addAmenities.append(a);
    var amenitites_id = document.getElementById("amenities_array").value;

        if( amenitites_id == ''){
             Array_amenities = [];
         }else{
            Array_amenities = amenitites_id.split(",");
         }
        Array_amenities.push(amenite);
        document.getElementById("amenities_array").value = Array_amenities;
   
}
function delete_amenities(){
    $('#addAmenities .amenitiesbutton1').each((i,elem) => {
        let Amenitite_id = elem.classList[1];
        let Amenitite_name = elem.dataset['name'];
        let amenitites_id = $("#amenities_array").val();
        if( amenitites_id == ''){
            Array_amenities = [];
            }else{
            Array_amenities = amenitites_id.split(",");
            }
        Array_amenities.map((data,i) =>{    
            if(data == Amenitite_id) {
                Array_amenities.splice(i, 1);
                $tagName=  $('#'+data);

                let span= document.createElement('span')
                span.setAttribute("class", "amenities a-amenitie");
                span.setAttribute("id", Amenitite_id);
                span.setAttribute("name", Amenitite_name);
                span.textContent=Amenitite_name;
                span.setAttribute("onclick", 'append_amenities(this);');
                $('.amenitieData').append(span)
                Array_amenities.splice(Amenitite_id,1);
                $("#amenities_array").val(Array_amenities);
                return;
            }
        });
    });
    document.getElementById('addAmenities').innerHTML="";
}

