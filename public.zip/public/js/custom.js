
// js to search location on public index page in search box section code starts
$(document).ready(function () {

    var request = null;
    $('#search_text').keyup(function () {
        // to hide suggestion listing div by default
        $('.suggestion').hide();
        var location = $('#search_text').val().trim();
        if (location.length > 2) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            request = $.ajax({
                type: 'get',
                url: 'get-city-suggestions',
                data: { location: location },
                success: function (data) {
                    if (data != 'NONE') {
                        // to show suggestion listing div if some data found
                        $('.suggestion').show();
                        const myArray = data;
                        $("#search_text").autocomplete({
                            source: myArray,
                            autoFocus: true,
                            appendTo: ".suggestion",
                            select: function (event, ui) {
                                $(event.target).val(ui.item.label);
                                $("#city_id_search").val(ui.item.value);
                                return false;
                            }
                        })
                        $('#ui-id-1').css('position', 'relative');
                    }
                },
                // kill old request before initiating new requests
                beforeSend: function () {
                    if (request !== null) {
                        request.abort();
                    }
                }
            });
        }
    })
});

// js to search location on public index page in search box section code ends

//TODO: notifications to be replaced by notify.js - if no other library found
var alert = document.getElementById("alert");
var btn = document.getElementById("btn");

if (btn) {
    btn.addEventListener('click', function () {
        alert.style.display = "none";
    });

    setTimeout(hide, 3000);
    function hide() {
        document.getElementById("alert").style.display = 'none';
    }
}

$(document).ready(function () {
    $(".confirm-alert").click(function () {
        msg = $(this).data("msg");
        if (typeof msg == "undefined") {
            msg = "Do you really want to do this?";
        }

        if (confirm(msg) == true) {
            return true;
        } else {
            return false;
        }
    });


    $(document).on('click', '.amenitiesbutton1', function (e) {
        e.preventDefault()
        if (e.currentTarget.classList[1]) {
            var Amenitite_id = e.currentTarget.classList[1];
            var Amenitite_name = e.currentTarget.dataset['name'];
            var amenitites_id = document.getElementById("amenities_array").value;
            if (amenitites_id == '') {
                Array_amenities = [];
            } else {
                Array_amenities = amenitites_id.split(",");
            }
            Array_amenities.map((data, i) => {
                if (data == Amenitite_id) {
                    Array_amenities.splice(i, 1);
                    $tagName = $('#' + data);

                    let span = document.createElement('span')
                    span.setAttribute("class", "amenities a-amenitie");
                    span.setAttribute("id", Amenitite_id);
                    span.setAttribute("name", Amenitite_name);
                    span.textContent = Amenitite_name;
                    span.setAttribute("onclick", 'append_amenities(this);');
                    $('.amenitieData').append(span)
                    Array_amenities.splice(Amenitite_id, 1);
                    document.getElementById("amenities_array").value = Array_amenities;
                    return;
                }
            });
            $("#" + Amenitite_id).remove();
        } else {
            const amenitites_id = document.getElementById("amenities_array").value;

            if (amenitites_id == '') {
                Array_amenities = [];
            } else {
                Array_amenities = amenitites_id.split(",");
            }

            const index = Array_amenities.indexOf(e.target.dataset.name);

            // only splice array when item is found
            if (index > -1) {
                // 2nd parameter means remove one item only
                Array_amenities.splice(index, 1);
            }
            document.getElementById("amenities_array").value = Array_amenities;

            // code for remove custom amenitie
            e.target.parentElement.remove();
        }
    });

    $("#amenitieToggler").click(function () {
        $("#amenitie_suggation").toggle();
    });

    $('#addFiles').click(function () {
        if ($("#file").val() == "") {
            showPopUp('error', 'Please select a file first !!!');
            return false;
        }
        else {
            $('#uploadImage').submit();
        }
    })

    $(document).on("keypress", ".form-control", function (e) {
        //Clear the text in error div
        $("#" + $(this).attr("name") + "help").html("");
    });

    //Show alert on delete action
    $(document).on('click', '.delete', function () {
        return confirm('Do you really want to DELETE this record?');
    });

    $(document).on("click", "#addhotspot", function () {
        console.log("TEST");
        $('#hotspot-sidebar').show();
    });

    $(document).on("click", "#close-hotspot-sidebar", function () {
        $('#hotspot-sidebar').hide();
    });

    // Here Add code for remove scrollbar on proeprty gallery section

    var a = $('.address_bar').outerHeight();
    var b = $('.gallery_body').outerHeight();
    $(".gallery_body").css("height", parseInt(b) - parseInt(a) - 10 + 'px');

    $(window).on('resize', function () {
        $(".gallery_body").css("height", $(window).outerHeight() - a + 'px');
    });

});

// js to hide toast message on click on close icon starts
$(document).on("click", "#hideToastIcon", function () {
    $('#toast-message').remove();
});
// js to hide toast message on click on close icon ends

$(document).on("change", "#unique_handle", function () {
    unique_handle = $("#unique_handle").val().trim();
    if (unique_handle.length > 0) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'get',
            url: 'get-unique-handle',
            data: { unique_handle: unique_handle },
            success: function (data) {
                if (!(data == unique_handle)) {
                    showPopUp('error', 'Entered handle value is not unique. Please enter a unique value.');
                    $("#isUnique").val("0");
                    $('#unique_handlehelp').html('This name is already taken .Please choose another one.<br>Suggested handle is: ' + data);
                    return false;
                }
                else {
                    $("#isUnique").val("1");
                    $('#unique_handlehelp').html('');
                }
            }
        });
    }
});
// js to set unique handles to agents on sign up page ends

// js to validate agents sign up form on submiting starts
$(document).on("submit", "#signUp", function () {
    unique_handle = $('#unique_handle').val().trim();
    // the value set to check if the handler box value is unique or not
    isUnique = $("#isUnique").val();
    // here , 0 means that the value is not unique ie; 1 given by default
    if (unique_handle.length == 0 || isUnique == 0) {
        showPopUp('error', 'Unique handle is required and it should be unique.');
        return false;
    }
});

// Js to check phone is verified or not
$(document).on("submit", "#contact_form", function () {
    is_varified = $('#contact_form .status').val();
    if (is_varified != 1) {
        showPopUp('error', "Please verify phone number to send the request. It will only be used by the Admin to contact you.");
        return false;
    }
    return true;
});
// js to validate agents sign up form on submiting ends

$(document).on("keypress", "#phone", function (event) {
    if (event.keyCode == 13) {
        $("#validateMobile").trigger("click");
    }
});

// js to validate agents phone number by sending otp starts
$(document).on("click", "#validateMobile, #resendOtp", function () {
    // hide countdown and resend otp button and change otp input box value to blank
    $("#otp").val('');
    $(".countdown").html('03:01');
    $(".countdown").hide();
    $("#resendOtp").hide();
    var phone = $("#phone").val().trim();

    if (phone.length == 10 && (!isNaN(phone))) {
        $("#validateMobile").hide();
        $(".form_loader").show();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'get',
            url: web_url + '/agent/send-otp',
            data: { phone: phone },
            success: function (data) {
                if (data == 'success') {
                    $(".form_loader").hide();
                    $("#otp_section").show();
                    $(".countdown").show();

                    showPopUp('success', 'Otp send successfully');

                    // countdown time1 set to enable resend otp button after 3 minutes countdown ends
                    var time2 = "2:00";
                    var interval = setInterval(function () {
                        var time1 = time2.split(':');

                        //by parsing integer, I avoid all extra string processing
                        var minutes = parseInt(time1[0], 10);
                        var seconds = parseInt(time1[1], 10);

                        --seconds;

                        minutes = (seconds < 0) ? --minutes : minutes;
                        if (minutes < 0) clearInterval(interval);
                        seconds = (seconds < 0) ? 59 : seconds;
                        seconds = (seconds < 10) ? '0' + seconds : seconds;
                        //minutes = (minutes < 10) ?  minutes : minutes;
                        $('.countdown').html(minutes + ':' + seconds);
                        time2 = minutes + ':' + seconds;
                        // when countdown ends
                        if (minutes == '0' && seconds == '00') {
                            // show resend otp button and hide countdown
                            $(".countdown").hide();
                            $("#resendOtp").show();
                        }
                    }, 1000);

                    $("#otp_section input").focus();
                }
                else {
                    // if otp not sent 
                    $(".form_loader").hide();
                    $("#validateMobile").show();

                    showPopUp('error', 'Erorr sending OTP. Please try again.');
                }
            }
        });
    }
    else {
        // if phone number length is not equal to 10
        showPopUp('error', 'Phone number should have 10 digits and only numeric characters allowed.')
        return false;
    }
});
// js to validate agents phone number by sending otp ends

// js to validate agents otp 
$(document).on("keyup", "#otp", function () {
    var otp = $("#otp").val().trim();
    if (isNaN(otp)) {
        showPopUp('error', 'Only numeric characters allowed!!!');
        return false;
    }
    if (otp.length == 4) {
        var phone = $("#phone").val().trim();
        // to redirect agent after successfull validate phone number
        redirect = web_url + '/agent/sign-up';
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'get',
            url: web_url + '/agent/verify-otp',
            data: { otp: otp, phone: phone },
            success: function (data) {
                if (data['message'] == 'success') {
                    if (data['agent_status'] == 1) {
                        // if agent already sign up then redirect to agent dashboard
                        redirect = web_url + '/agent/dashboard';
                    }
                    // else redirect to sign up page
                    window.location.href = redirect;
                }
                else {
                    showPopUp('error', 'OTP not matched');
                }
            }
        });
    }
});

$(document).on("keypress", "#contact_phone", function (event) {
    if (event.keyCode == 13) {
        $("#verifyPhone").trigger("click");
    }
});

// js for sending otp for contact form
$("#verifyPhone,  #resendOtp").click(function () {
    $("#otp").val('');
    $(".countdown").html('03:01');
    $(".countdown").hide();
    $("#resendOtp").hide();
    var contact_phone = $("#contact_phone").val().trim();

    if (contact_phone.length == 10 && (!isNaN(contact_phone))) {
        $.ajax({
            type: 'get',
            url: web_url + '/agent/send-otp',
            data: { phone: contact_phone },
            success: function (data) {
                if (data == 'success') {
                    $("#verifyPhone").hide();
                    $("#otp_section").show();
                    $(".countdown").show();
                    showPopUp('success', 'Otp send successfully');

                    // countdown time1 set to enable resend otp button after 3 minutes countdown ends
                    var time2 = "3:00";
                    var interval = setInterval(function () {
                        var time1 = time2.split(':');

                        //by parsing integer, I avoid all extra string processing
                        var minutes = parseInt(time1[0], 10);
                        var seconds = parseInt(time1[1], 10);

                        --seconds;

                        minutes = (seconds < 0) ? --minutes : minutes;
                        if (minutes < 0) clearInterval(interval);
                        seconds = (seconds < 0) ? 59 : seconds;
                        seconds = (seconds < 10) ? '0' + seconds : seconds;
                        //minutes = (minutes < 10) ?  minutes : minutes;
                        $('.countdown').html(minutes + ':' + seconds);
                        time2 = minutes + ':' + seconds;
                        // when countdown ends
                        if (minutes == '0' && seconds == '00') {
                            // show resend otp button and hide countdown
                            $(".countdown").hide();
                            $("#resendOtp").show();
                        }
                    }, 1000);

                    $("#otp_section input").focus();
                } else {
                    showPopUp('error', 'Erorr sending OTP. Please try again.');
                    $("#verifyPhone").show();
                    $("#otp_section").hide();
                }
            }
        });
    }
    else {
        showPopUp('error', 'Phone number should have 10 digits and only numeric characters allowed.')
        return false;
    }
});

// js to validate contact_form otp 
$("#contOtp").keyup(function () {
    var contotp = $("#contOtp").val().trim();
    if (isNaN(contotp)) {
        showPopUp('error', 'Only numeric characters allowed!!!');
        return false;
    }
    if (contotp.length == 4) {
        var contact_phone = $("#contact_phone").val().trim();
        $.ajax({
            type: 'get',
            url: web_url + '/agent/verify-contact-otp',
            data: { otp: contotp, phone: contact_phone },
            success: function (data) {
                if (data['message'] == 'success') {
                    showPopUp('success', 'Otp verified successfully');
                    $(".status").val("1");
                    $('#contact_phone').prop("readonly", true);
                    $("#otp_section").hide();
                    $('#verifyPhone').hide();
                    $("#verifiedPhone").html("OTP Verified");
                    $(".countdown").hide();
                }
                else {
                    showPopUp('error', 'OTP not matched');
                }
            }
        });
    }
});

const checkNumbers = () => {
    let numbers = $(".invitation-number");
    let arry = [];
    for (let i = 0; i < numbers.length; i++) {
        if (numbers[i].value.length != 10) {
            $("#error_invitation").html("Phone number should have 10 digits")
            return false;
        }
        arry.push(numbers[i].value);

    }
    // check if phone number is duplicated or not
    let resultToReturn = false;
    resultToReturn = arry.some((element, index) => {
        return arry.indexOf(element) !== index;
    });
    if (resultToReturn) {
        $("#error_invitation").html("Each phone number should be unique.")
        return false;
    }
    return true;
}
// INVITATION FORM
$("#invitation_form").submit((e) => {
    if (!checkNumbers()) {
        e.preventDefault();
    }

})


// active nav-items
$(document).ready(function () {
    var url = window.location.href;
    $('#ag-nav li a').each(function () {
        var href = $(this).attr('href');
        if (url == href) {
            $(this).css('color', '#1d4ed8');
        }
    });
});


// Profile pic cropped
let imgInp = document.getElementById("user_avatar");
let image = document.getElementById("image-container");

if (typeof imgInp != 'undefined') {
    $('#user_avatar').change(() => {
        const [file] = imgInp.files
        if (file) {
            image.src = URL.createObjectURL(file)
        }
        var options = {
            dragMode: 'move',
            aspectRatio: 0.878,
            //autoCropArea: 0.92,
            restore: false,
            guides: false,
            center: false,
            highlight: false,
            cropBoxMovable: true,
            cropBoxResizable: false,
            cropBoxWidth: 215,
            cropBoxHeight: 245,
            toggleDragModeOnDblclick: false,
            viewMode: 0,
        }
        const cropper = new Cropper(image, options);

        document.getElementById("btnCrop").addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            let canvas = cropper.getCroppedCanvas();
            console.log(canvas);

            canvas.toBlob(function (blob) {
                let url = URL.createObjectURL(blob);
                var reader = new FileReader();
                reader.readAsDataURL(blob);
                reader.onloadend = function () {
                    let base64data = reader.result;
                    $.ajax({
                        type: "POST",
                        url: "edit-profile-image",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        data: { '_token': $('meta[name="_token"]').attr('content'), 'image': base64data },
                        error: function (xhr, error) {
                            // check status && error
                            console.log(xhr);
                            console.log(error);
                        },
                        success: function (data) {
                            console.log("Image successfully uploaded");
                            window.location.reload();
                        }
                    })

                }
            })
        })
    })
}

// chart js 
$(document).ready(function () {

    if($("#myChart").length > 0) {
        const NoPropertyselected = () => $("#property_name").val("")
        const goBackBtn = $("#go-back-btn");
        const property_stats = (start = null, end = null, property_id = null) => {
            $.ajax({
                type: 'get',
                url: 'property-views',
                data: { "id": $("#agent_id").text(), "start": start, "end": end, "property_id": property_id },
                success: function (data) {
                    data = data.sort((a, b) => new Date(a.visit_date) - new Date(b.visit_date));

                    var coloR = [];
                    var dynamicColors = function () {
                        var r = Math.floor(Math.random() * 255);
                        var g = Math.floor(Math.random() * 255);
                        var b = Math.floor(Math.random() * 255);
                        return "rgb(" + r + "," + g + "," + b + ")";
                    };
                    for (var i in data) {
                        coloR.push(dynamicColors());
                    }

                    $("canvas#myChart").remove();
                    console.log(property_id)
                    $("div#canvas-chart").append('<canvas id="myChart" class="animated fadeIn" height="100"></canvas>');
                    if (property_id != null && property_id != undefined) {
                        const myNewChart = new Chart(
                            document.getElementById('myChart'),
                            {
                                data: {
                                    datasets: [
                                        {
                                            type: 'line',
                                            label: 'User Views',
                                            borderColor: dynamicColors(),
                                            tension: 0.1,
                                            data: data.map(row => row.total_views)
                                        }
                                    ],
                                    labels: data.map(row => row.visit_date),
                                },
                                options: {
                                    plugins: {
                                        legend: {
                                            display: false
                                        }
                                    }
                                }

                            }
                        );
                    }
                    else {
                        const myNewChart = new Chart(
                            document.getElementById('myChart'),
                            {
                                type: 'bar',
                                data: {
                                    datasets: [
                                        {
                                            label: 'User Views',
                                            backgroundColor: coloR,
                                            data: data.map(row => row.total_views)
                                        }
                                    ],
                                    labels: data.map(row => row.properties[0].name),
                                },
                                options: {
                                    plugins: {
                                        legend: {
                                            display: false
                                        }
                                    }
                                }

                            }
                        );
                        goBackBtn.css("display", "none");
                        document.getElementById("myChart").addEventListener('click',
                            ((evt) => {
                                const points = myNewChart.getElementsAtEventForMode(evt, 'nearest', { intersect: true }, true);
                                if (points[0]) {
                                    var label = data[points[0].index].property_id;
                                    let tmp = $('#reportrange span').text().split(" - ");
                                    let [month1, date1, year1] = tmp[0].split(" ");
                                    let [month2, date2, year2] = tmp[1].split(" ");
                                    start_date = year1 + "-" + moment().month(month1).format("MM") + "-" + date1;
                                    end_date = year2 + "-" + moment().month(month2).format("MM") + "-" + date2;

                                    $("#property_name").val(data[points[0].index].property_id)

                                    goBackBtn.css("display", "flex");
                                    property_stats(start_date, end_date, label);
                                }
                            })
                        )
                    }
                }

            });
        }

        property_stats();
        goBackBtn.click(() => {
            NoPropertyselected();
            property_stats();
        })
        const date_range = document.getElementById("date-range");
        if (date_range) {
            // if click on go
            date_range.addEventListener("click", () => {
                let property_id = $("#property_name").val();
                if (property_id == "") {
                    property_id = null;
                }

                let tmp = $('#reportrange span').text().split(" - ");
                let [month1, date1, year1] = tmp[0].split(" ");
                let [month2, date2, year2] = tmp[1].split(" ");
                start_date = year1 + "-" + moment().month(month1).format("MM") + "-" + date1;
                end_date = year2 + "-" + moment().month(month2).format("MM") + "-" + date2;
                goBackBtn.css("display", "flex");

                property_stats(start_date, end_date, property_id);
            });
        }

        var start = moment().subtract(6, 'days');
        var end = moment();

        function cb(start, end) {
            $('#reportrange span').html(start.format('MMMM D YYYY') + ' - ' + end.format('MMMM D YYYY'));
        }
        cb(start, end);  //default value

        $('#reportrange').daterangepicker({
            startDate: start,
            endDate: end,
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb);
    }
});
