@extends('layouts.agents.agent')
@section('title', 'Videos')

@section('content')
    <div class="w-full">
       <div class="mb-6">
       <h2 class="text-3xl font-bold ">Add Property Videos</h2>
       </div>

       @if($property_videos->count() == 2)
            <div class="w-full my-10">
            You are allowed to add only 2 videos, which are already added. If you want to change/replace a video then 
            please first remove a video from below and then upload the new video.
            </div>
        @else 
            <div class="grid md:grid-cols-2 md:gap-6">
                    <form action="{{url('agent/video/save-video')}}" id="video_form" method="post" enctype="multipart/form-data">
                        @method('POST')
                        {{ csrf_field() }}
                        <input type="hidden" name="property_id" id="property_id" value="">
                        <div class="mb-6">
                            <h3 class="text-2xl font-bold ">Upload Video File</h3>
                            <label class="block mb-2 text-sm font-medium text-gray-900 " for="file">Select file to upload</label>
                            <input class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50  focus:outline-none " id="file" type="file" name = "file" accept="video/mp4,video/x-m4v,video/wmv,video/*" required>
                        </div>
                        @if($property_videos->count() < 2)
                            <button type="submit" class="bg-lime-500 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2" data-ripple-light="true">Add Videos</button>
                        @endif
                    </form>

                <!-- Right side iput box for video url -->
                <div class="">
                    <form action="{{url('agent/video/save-url-video')}}" id="video_url_form" method="post">
                        @csrf
                        <div class="mb-6">
                            <h3 class="text-2xl font-bold ">Add from YouTube or Vimeo</h3>
                            <label class="block mb-2 text-sm font-medium text-gray-900 ">Add Urls</label>
                            <input type="text" id="video_url"   name="video_url" maxlength="255" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   " style="border:2px solid lightgrey;" required/>
                        </div>
                        <div class="mb-6">
                        <span class="block mb-2 text-lg font-medium text-gray-900 ">Video Source :</span>
                            <div class="flex gap-6 w-full justify-between">
                                <div class="flex items-center cursor-pointer px-4 w-1/2 border border-gray-200 rounded ">
                                    <input checked id="video_source-youtube" type="radio" value="YouTube" name="video_source" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2  cursor-pointer">
                                    <label for="video_source-youtube" class="cursor-pointer w-full py-4 ml-2 text-sm font-medium text-gray-900 ">YouTube</label>
                                </div>
                                <div class="cursor-pointer flex items-center px-4 w-1/2 border border-gray-200 rounded ">
                                    <input id="video_source-vimeo" type="radio" value="Vimeo" name="video_source" class="text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500  focus:ring-2   cursor-pointer">
                                    <label for="video_source-vimeo" class="w-full py-4 ml-2 text-sm font-medium text-gray-900  cursor-pointer">Vimeo</label>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="bg-lime-500 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Add Url</button>
                    </form>
                </div>
            </div>
        @endif
      <div class="mb-6">
     <h3 class="text-2xl font-bold ">Property Videos</h3>
    </div>
        <div class="views-form property_videos flex flex-wrap gap-4">
            <?php 
            if($property_videos->count() == 0) {
                echo "No videos added.";
            }
            ?>
            @foreach($property_videos as $property_video)        
                <div class="mb-6 mr-3 border-2 p-4" id="{{$property_video->id}}">
                    <div class="w-auto pb-0 inline-block relative gallery-image" name="{{ $property_video->video_type}}">
                        @if(is_null($property_video->video_url))
                            <video width="285" height="100%" controls>
                                <source src="{{url('/files/property_videos/')}}/{{$property_video->property_id}}/{{$property_video->file_name}}" type="video/mp4">
                                <source src="{{url('/files/property_videos/')}}/{{$property_video->property_id}}/{{$property_video->file_name}}" type="video/ogg" />
                                Your browser does not support the video tag.
                            </video>
                        @else 
                        <x-embed url="{{ $property_video->video_url }}"/>
                        @endif
                        <br>
                        <a href="javascript:deleteVideo('<?php echo $property_video->id ?>')" title="Delete" class="delete cursor-pointer bg-transparent hover:bg-red-600 font-semibold hover:text-white p-2 border border-red-600 hover:border-transparent rounded text-red-600 font-bold">Delete</a>
                    </div>
                </div>
            @endforeach
        </div>
        <br><br>
        <div>
            <a href="{{url('/agent/property-images/images')}}" class="text-white bg-neutral-600 hover:bg-neutral-700 focus:ring-4 focus:outline-none focus:ring-neutral-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Prev</a>
            <a href="{{url('/agent/property/default')}}" class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Next</a>
        </div>

    </div>

@stop