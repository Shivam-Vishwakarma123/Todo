@extends('layouts.agents.agent')
@section('title', 'Videos')

@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">
    <div class="w-full my-6"> 
        <div class="input-group input-group-outline ">
            <label class="form-label">Add Urls</label>
            <input type="text" id="matterport_url" name="matterport_url" maxlength="500" class="form-control" />
        </div>
        <div class="my-5">
            <a href="{{url('/agent/video/video')}}" class="button button-blue float-left font-bold mx-2 py-3">Prev</a>
            <a href="#" class="button button-green p-3" onclick="save3D_Url();" >add URl for model</a> 
            <a href="{{url('/agent/property-topbar/choose')}}" class="button button-blue font-bold mx-2 py-3 float-right">Next</a>
            
        </div>                  
        <div class="w-full">
            <h4>3D Matterport Videos</h4>                    
            <table class="table table-striped table_3durl">
                @foreach($property_matterports as $property_matterport)
                    <tr id="{{$property_matterport->id}}">
                        <td><iframe width="300" height="200"  src="{{$property_matterport->matterport_url}}" frameborder="0" allowfullscreen allow="xr-spatial-tracking"></iframe></td>
                        <td class="p-2 text-2xl">{{$property_matterport->matterport_url}}</td>
                        <td> <a href="#" onclick="delete3D_Url('{{$property_matterport->id}}');" class="button button-red ml-5 delete">Delete</a></td>
                    </tr>
                @endforeach
            </table>
        </div>
    </div>
@stop