@extends('layouts.agents.agent')
@section('title', 'Dashboard')

@section('content')

    <div>
        <div class="flex justify-between items-center">
            <span class="hidden" id="agent_id">{{ $agent->id }}</span>
            <h3 class="text-md font-bold  mt-2">Credits remaining: {{ $agent->credit_balance }}</h3>
            <a href="{{ url('agent/credit-plans') }}">
                <button class="text-gray-900 bg-lime-300 font-medium rounded-lg text-sm px-3 py-2.5 my-4">Buy More Credits <i
                        class="fa-solid fa-arrow-right ml-2"></i></button>
            </a>
        </div>
        <div class="mb-6 flex flex-col items-baseline">
            <a href="https://wa.me/?text=I would like to invite you to join PropertyShops.in. Join using the link below and get additional 5 FREE credits - {{url('invite')}}/{{$agent->handle}}" class="text-gray-900 bg-lime-300 font-medium rounded-lg text-sm px-3 py-2.5 my-4" type="button">
                <i class="fab fa-whatsapp pr-2" style="font-size: 14px"></i>
                Invite on Whatsapp
            </a>
            <p class="font-normal">Refer your friends to earn 5 Free Credits for both</p>
        </div>

        <a href="{{ url('/agent/property/address') }}"
            class="new-property text-white font-semibold bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 my-2">
            New Property
        </a>
        <br>
        <div class="property-chart mt-10" id="canvas-chart">
            <h3 class="text-2xl font-bold mt-2 mb-2">Number of views in last 7 days</h3>
            <canvas id="myChart"></canvas>
        </div>
        <br>
        <h3 class="text-2xl font-bold mt-2 mb-2">Recently Added Property</h3>
        @if (count($property_descending_order) > 0)
            @foreach ($property_descending_order as $property)
                <x-mobile-view-property-card :property="$property"></x-mobile-view-property-card>
            @endforeach
        @else
            <span class=" text-center" colspan="9">No Properties Found.</span>
        @endif

        <!-- here property_update = get data from database in decending order where last update property  -->

        <h3 class="text-2xl mb-3 mt-5 font-bold ">Recently Updated Property</h3>


        @if (count($property_update) > 0)
            @foreach ($property_update as $property)
                <x-mobile-view-property-card :property="$property"></x-mobile-view-property-card>
            @endforeach
        @else
            <td class=" text-center" colspan="9">No Properties Found.</td>
        @endif
        </table>
    </div>
@stop
