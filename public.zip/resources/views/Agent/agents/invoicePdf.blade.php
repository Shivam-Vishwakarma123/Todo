<?php
$cgst_persntg = ($agent_address->state->id == 27) ? '9%' : '0%';
$sgst_persntg = ($agent_address->state->id == 27) ? '9%' : '0%';
$igst_persntg = ($agent_address->state->id != 27) ? '18%' : '0%';
?>
<!DOCTYPE html>

<html>

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{
        font-size: 11px;
        font-family: "DejaVu Sans; sans-serif";
    }
    .top-tr{
        margin:0px !important;
        padding:0px !important;
    }
    table{
        margin:0px; 
        padding:0px;
    }
    th{
        margin:0px !important;
        padding:0px 2px !important;
        border:2px solid black;
    }
    td{
        border:2px solid black !important;
        padding:0px 4px !important;
    }
    .top-table td, .top-table th 
    {
        border:none !important;
    }
    .top-table th{
        text-align: left;
    }
    .top-table tr{
        border:2px solid black !important;
    }
    </style>
</head>
<div style="text-align:center;">
    <h1 style="font-size 22px;">TAX INVOICE</h1>
</div>
<div style="height:190px">
    <div style= "width:33%;float:left;">
        <img src="{{ public_path('/images/logo-vb.png') }}" style="width: 150px;">
    </div>
    <div style= "width:33%;float:left;">
        <p style="margin-bottom:0px;">Nirvaat Internet Private Limited
            <br>
            402, Second Floor, Shakti Khand 3 
            <br>
            Indirapuram, Ghaziabad - 201010
        </p>
        <table class ="top-table">
            <tr>
                <th>Call / WhatsApp: </th>
                <td>+91 81302 48912</td>
            </tr>
            <tr>
                <th>GST #</th>
                <td>09AAFCN0710J1ZM</td>
            </tr>
            <tr>
                <th>PAN #</th>
                <td>AAFCN0710J</td>
            </tr>
            <tr>
                <th>TAN #</th>
                <td>MRTN03165B</td>
            </tr>
            <tr>
                <th>CIN #</th>
                <td>U72300UP2015PTC074370</td>
            </tr>
        </table>
    </div>
    <div style="width:33%;float:right;">
        <table class="top-table">
            <tr>
                <th><b>Invoice :</b></th>
                <td><span> {{ $invoices->invoice_no }}</span></td>
            </tr>
            <tr>
                <th><b>Invoice Date :</b></th>
                <td><span>{{ ($payment_details->payment_date == "") ? "" : \Carbon\Carbon::parse($payment_details->payment_date)->format('d-m-y')  }}</span></td>
            </tr>
            <tr>
                <th><b>Billing State :</b></th>
                <td><span>Uttar Pradesh</span></td>
            </tr>
            <tr>
                <th><b>Supply State :</b></th>
                <td><span>{{$agent_address->state->name}}</span></td>
            </tr>
        </table>
    </div>
</div>
<br>
<div style="height:100px;">
    <div style ="width:45%;float:left;text-align:left;">
        <b>Bill To:</b>
        <p style="margin-top:2px;">{{Str::ucfirst($agents->first_name) }}<br>
            {{$agent_address->address}}<br>
            {{ $agent_address->city->name }}, {{ $agent_address->state->name }} - {{$agent_address->zip}}<br>
            <b>GST No:{{$agent_address->gst_no}}<br/>
        </p>    
    </div>
    <div style="width:45%;float:right;text-align:left;">
        <b>Ship To:</b>
        <p style="margin-top:2px;">{{ Str::ucfirst($agents->first_name) }}<br>
            {{$agent_address->address}}<br>
            {{ $agent_address->city->name }}, {{ $agent_address->state->name }} - {{$agent_address->zip}}<br>
        </p>   
    </div>
</div>
<div style="height:70px">
    <table style="width:100%;border:2px solid black;border-collapse:collapse;">
        <thead>
            <tr>
                <th style="width:10%">S.No.</th>
                <th style="width:40%">Description</th>
                <th style="width:10%">HSN</th>
                <th style="width:10%">Price</th>
                <th style="width:10%">GST</th>
                <th style="width:20%">Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1.</td>
                               <td >
                Service Name: PropertyShops.in
                <br>
                Plan Name: {{$payment_details->plans->name}}
                </td>
                <td style="text-align: center">997331</td>
                <td style="text-align: right"><span>&#8377;<?= $invoices->taxable_amount ?></span></td>
                <td style="text-align: right"><span>&#8377;<?= $invoices->total_gst ?></span></td>
                <td style="text-align: right"><span>&#8377;{{ $invoices->net_amount }}</span></td>
            </tr>
        </tbody>
    </table>
</div>
<br>
<div style="height:70px;">
    <table style="width:100%;border:2px solid black;border-collapse:collapse;">
        <thead>
            <tr style="text-align:right">
                <th style="text-align:right;">Total Taxable Amount</th>
                <td><span>&#8377;<?= $invoices->taxable_amount ?></span></td>
            </tr>
            <tr style="text-align:right">
                <th style="text-align:right;">GST @18%</th>
                <td><span >&#8377;<?= $invoices->total_gst ?></span></td>
            </tr>
            <tr style="text-align:right">
                <th style="text-align:right">Net Payment Due</th>
                <td><span >&#8377;{{ $invoices->net_amount }}</span></td>
            </tr>
        </thead>
    </table>
</div>
<br>
<div style="height:100px;width:100%">
<h2 style= "font-size:16px;">GST Calculation:</h2>
    <table style="width:100%;border:2px solid black;border-collapse:collapse;">
        <thead>
            <tr>
                <th rowspan="2" style="width:10%">Taxable Amount:</th>
                <th colspan="2" style="width:25%">CGST:</th>
                <th colspan="2" style="width:25%">SGST:</th>
                <th colspan="2" style="width:25%">IGST:</th>
                <th rowspan="2" style="width:15%">Total GST:</th>
            </tr>
            <tr>
                <th>Rate</th>
                <th>Amount</th>
                <th>Rate</th>
                <th>Amount</th>
                <th>Rate</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="text-align: right"><span >&#8377;<?= $invoices->taxable_amount ?></span></td>
                <td><?= $cgst_persntg ?></td>
                <td style="text-align: right"><span >&#8377;<?= $invoices->cgst ?></span></td>
                <td><?= $sgst_persntg ?></td>
                <td style="text-align: right"><span >&#8377;<?= $invoices->sgst ?></span></td>
                <td><?= $igst_persntg ?></td>
                <td style="text-align: right"><span >&#8377;<?= $invoices->igst ?></span></td>
                <td style="text-align: right"><span >&#8377;<?= $invoices->total_gst ?></span></td>
            </tr>
        </tbody>
    </table>
</div>
<br><br><br>
<hr>
    <p style="text-align:center;">For more information about your order or any other queries contact us on cs@propertyshops.in.
        <br>
        You can also check order details using your propertyshops.in account.
    </p>
</body>

</html>