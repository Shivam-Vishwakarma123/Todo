<p>Dear Agent,</p>
<p>A buyer is interested in your property. The details are given below:</p>
<ul>
    <li>Buyer Name: {{ $user['name'] }}</li>
    <li>Phone number: {{ $user['phone'] }}</li>
    <li>Email Id: {{ $user['email'] }}</li>
    <li>Message: {!! $user['message'] !!}</li>
    <li>Property Url: {{ url('/')}}/{{ $user['property_url'] }}</li>
</ul>
<p>
    Please contact the buyer as soon as possible.
</p>
<p>
Thank you,<br/>
PropertyShops Team
</p>