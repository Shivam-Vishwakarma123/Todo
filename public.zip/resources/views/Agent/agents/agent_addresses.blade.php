@include('includes.agents.head')
<div class="signup-form rounded-lg" style="width:70%;">
    <div class="mb-6" style="text-align: center;font-size:30px;font-weight:600;">
        <h1>Agents Address</h1>
    </div>
    @include('flash-message')
    <form action="{{url('/agent/agents-address-add')}}" method="post" class="p-10" onsubmit="return validaAddress(this);">
        @csrf
        <div class="grid gap-6 mb-6 md:grid-cols-2">
        @php $business_name=old('business_name') @endphp
            <div class="input-group input-group-outline">
                <label for="business_name" class="form-label">Business Name</label>
                <input type="text" id="business_name" maxlength="100" name="business_name" class="form-control" @if(isset($business_name)) value={{$business_name}} @endif />
                <small class="text-red-700 font-bold">@error('business_name'){{$message}}@enderror</small>
            </div>
            <div class="input-group input-group-outline">
            @php $phone=old('phone') @endphp
                <label for="phone" class="form-label">Phone</label>
                <input type="text" id="phone" name="phone" maxlength="50" class="form-control" @if(isset($phone)) value={{$phone}} @endif required/>
                <small id="phonehelp" class="text-red-700 font-bold">@error('phone'){{$message}}@enderror</small>
            </div>

            <div class="w-100">
            @php $country=old('countries') @endphp
                <input id="country_name" name="country_name" value="{{isset($countries) ? $countries->name : ''}}" class="form-control px-3" readonly/>
                <small id="countrieshelp" class="text-red-700 font-bold">@error('countries')*{{$message}}@enderror</small>
            </div>
            <div class="input-group input-group-outline is-filled">
            @php $state=old('state') @endphp
                <label class="form-label">State</label>
                <select class="form-control" @if(isset($state)) value={{$state}} @endif name="state_id" id="state_id" placeholder="Language" required>
                    <option value="0" selected>Choose State</option>
                    @foreach($states as $state)
                        <option value="{{$state->id}}">{{$state->name}}</option>
                    @endforeach
                </select>
                <small id="statehelp" class="text-red-700 font-bold">@error('state'){{$message}}@enderror</small>
            </div>
            <div class="input-group input-group-outline">
            @php $city=old('city') @endphp
                <label for="city" class="form-label">City</label>
                <input type="text" id="city" maxlength="100" name="city" class="form-control" @if(isset($city)) value={{$city}} @endif  required/>
                <small id="cityhelp" class="text-red-700 font-bold">@error('state'){{$message}}@enderror</small>
            </div>
            <div class="input-group input-group-outline">
            @php $zip=old('zip') @endphp
                <label for="zip" class="form-label">Zip</label>
                <input type="text" id="zip" maxlength="10" name="zip" maxlength="6" min="1" class="form-control" @if(isset($zip)) value={{$zip}} @endif required/>
                <small id="ziphelp" class="text-red-700 font-bold">@error('zip')*{{$message}}@enderror</small>
            </div>
        </div>
        <div class="input-group input-group-outline">
        @php $zip=old('address') @endphp
            <label for="address" class="form-label">Address</label>
            <textarea id="address" name="address" class="form-control" required>@if(isset($address)) value={{$address}} @endif</textarea>
            <small id="addresshelp" class="text-red-700 font-bold">@error('address')*{{$message}}@enderror</small>
        </div>
        <button type="submit" class="button button-green w-36 mt-10 mb-10" data-ripple-light="true">Submit</button>
        <button type="reset" class="button  button-orange w-36 ml-10 " data-ripple-light="true">Reset</button>
    </form>
</div>
@include('includes.agents.foot')