@extends('layouts.agents.agent')
@section('title', 'paymentError')

@section('content')

<a href="credit-plans" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Back</a>
<div class="w-full md:p-28">
    <div class="text-center bg-light md:p-28 my-5 text-red-700">
        <i class="fa-solid fa-circle-exclamation text-7xl mb-9 "></i>
        <p class="text-7xl uppercase">Transaction Failed!</p>
        <p class="mt-4 mb-3">Your payment is failed. Please Try Again!</p>
        <a href="{{url('agent/credit-plans')}}">
            <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Retry</button> 
         </a>                   
    <a href="credit-plans" class="block bg-grey-400 mt-8 hover:bg-red-700 hover:text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline uppercase">Go to Subscription Page</a>
    </div>
</div>
@stop