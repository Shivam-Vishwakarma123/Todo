@extends('layouts.agents.agent')
@section('title', 'Profile')

@section('content')
@php
if($agent_address != false){
$ag_bs_name = $agent_address->business_name;
$ag_rera = $agent_address->rera_no;
$ag_gst = $agent_address->gst_no;
$ag_addr = $agent_address->address;
$ag_state = isset($agent_address->state) ? $agent_address->state->name : "";
$ag_city = isset($agent_address->city) ? $agent_address->city->name : "";
$ag_zip = $agent_address->zip;
$ag_phone = $agent_address->phone;
$ag_country = isset($agent_address->country) ? $agent_address->country->name : "";
$ag_state_id = $agent_address->state_id;
}
else{
$ag_bs_name = "";
$ag_rera = "";
$ag_gst = "";
$ag_addr = "";
$ag_state = "";
$ag_city = "";
$ag_zip = "";
$ag_phone = "";
$ag_country = "";
$ag_state_id = "";
}
@endphp

<div class="flex w-full p-2 m-2 mx-auto profile-flex">
    <div class="w-1/2">
        <h1 class="mt-4 text-center text-3xl font-medium leading-tight text-primary">Profile image</h1>
        @if($agent->profile_image == '')
        <div class="mb-6 " id="upload-profile">
            <!-- Modal toggle -->
                <input data-modal-toggle="defaultModalprofileimage" type="file"  id="user_avatar"
                    class=" block w-5/6 bg-gray-50 rounded-lg border border-gray-300 cursor-pointer focus:outline-none"
                    name="profile_image" style="margin-top:23px;">

            <!-- Main modal -->
            <div id="defaultModalprofileimage" tabindex="-1" aria-hidden="true"
                class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
                <div class="relative w-full max-w-2xl max-h-full">
                    <!-- Modal content -->
                    <div class="relative bg-white rounded-lg shadow ">
                        <!-- Modal header -->
                        <div class="flex items-start justify-between p-4 border-b rounded-t ">

                            <button type="button"
                                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center "
                                data-modal-toggle="defaultModalprofileimage">
                                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                                    viewBox="0 0 14 14">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                </svg>
                                <span class="sr-only">Close modal</span>
                            </button>
                        </div>
                        <!-- Modal body -->
                        <div class="p-10">

                            <div class="mb-6">
                                <div class="dialog-overlay"></div>
                                <div class="mb-6">
                                    <div class="mb-6">

                                        <img class="w-10" id="image-container" src="#" alt="Image comes here" />
                                        <div class="mb-6">
                                            <div class="dialog-footer my-4">
                                                <button
                                                    class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                                                    id="btnCrop">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal footer -->

                    </div>
                </div>
            </div>

            <!-- for testing ends -->


        </div>
        @else
        <div class="my-5 mx-2" id="delete-profile">
            <img src="@if($agent->profile_image != ''){{url('/files/agents/')}}/{{$agent->id}}/{{$agent->profile_image}}@endif"
                class="max-w-full max-h-full object-contain object-center my-4" alt="No profile image">
            <a href="{{url('agent/delete-profile-image')}}" onclick="deleteProfileImage();"
                class="bg-rose-500 hover:bg-rose-600 focus:ring-4 focus:outline-none focus:ring-rose-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center delete my-4"
                 id="addvideos" data-ripple-light="true">Delete Image</a>
        </div>
        @endif
    </div>

    <div class="w-1/2">
        <h1 class="mt-4 text-center text-3xl font-medium leading-tight text-primary">Logo Image</h1>
        @if($agent->logo_image == '')
        <div class="mb-6" id="upload-logo">
            <form action="{{url('agent/edit-logo-image')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="mb-6">
                    <div class="dialog-overlay"></div>
                    <div class="mb-6">
                        <div class="mb-6">
                            <div class="mb-6">
                            </div>
                            <input type="file"
                                class="block w-5/6 bg-gray-50 rounded-lg border border-gray-300 cursor-pointer focus:outline-none"
                                id="logo_image" name="logo_image">
                            <div class="dialog-footer my-4">
                                <button
                                    class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        @else
        <div class="my-5 mx-2" id="delete-logo">
            <img src="@if($agent->logo_image != ''){{url('/files/agents/')}}/{{$agent->id}}/{{$agent->logo_image}} @endif"
                alt="No logo image" class="max-w-full max-h-full object-contain object-center my-4">
            <a href="{{url('agent/delete-logo-image')}}" onclick="deleteLogoImage()"
                class="bg-rose-500 hover:bg-rose-600 focus:ring-4 focus:outline-none focus:ring-rose-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center delete my-4"
                data-ripple-light="true">Delete Logo</a>
        </div>
        @endif
    </div>
</div>


<div id="accordion-collapse" data-accordion="collapse" class="my-8">
    <h2 id="basic-details-heading">
        <button type="button"
            class="flex items-center justify-between w-full p-5 font-medium text-left bg-neutral-100 text-gray-500 border border-b-0 border-gray-400 rounded-t-xl focus:ring-4 focus:ring-gray-200"
            data-accordion-target="#profile-basic-details" aria-expanded="true" aria-controls="profile-basic-details">
            <span class="text-slate-900 text-md">Contact Details</span>
            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
    </h2>
    <div id="profile-basic-details" class="hidden" aria-labelledby="basic-details-heading">
        <div class="p-5 font-light border border-b-0 border-gray-200  ">
            <p class="block mb-2 text-sm font-medium text-gray-900"><b>Name: </b> {{$agent->first_name}}
                {{$agent->last_name}}</p>
            <p class="block mb-2 text-sm font-medium text-gray-900"><b>Email: </b> {{$agent->email}}</p>
            <p class="block mb-2 text-sm font-medium text-gray-900"><b>Phone: </b> {{$agent->phone}}</p>
            <!-- Modal toggle -->
            <button
                class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"
                type="button" data-modal-toggle="defaultModal">
                Edit Details</button>

            <!-- Main modal -->
            <div id="defaultModal" tabindex="-1" aria-hidden="true"
                class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-modal md:h-full">
                <div class="relative w-full h-full max-w-2xl md:h-auto">
                    <!-- Modal content -->
                    <div class="relative bg-white rounded-lg shadow ">
                        <!-- Modal header -->
                        <div class="flex items-start justify-between p-4 border-b rounded-t">
                            <h3 class="text-xl font-semibold text-gray-900">
                                Contact Details
                            </h3>
                            <button type="button"
                                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
                                data-modal-toggle="defaultModal">
                                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                        clip-rule="evenodd"></path>
                                </svg>
                                <span class="sr-only">Close modal</span>
                            </button>
                        </div>
                        <!-- Modal body -->
                        <div class="mb-6 px-2">
                            <form action="{{url('agent/edit-profile-details')}}" method="post">
                                @csrf
                                <div class="mb-6"></div>
                                <div class="">
                                    <div class=""></div>
                                    <div class="mb-6">
                                        <div class="mb-6">
                                            <div class="mb-6"></div>
                                            <div class="mb-6">
                                                <div class="mb-6">
                                                    <label class="block mb-2 text-sm font-medium text-gray-900">First
                                                        Name *</label>
                                                    <input type="text" id="first_name" value="{{$agent->first_name}}"
                                                        name="first_name"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        maxlength="100" required />
                                                </div>
                                                <div class="mb-6">
                                                    <label class="block mb-2 text-sm font-medium text-gray-900">Last
                                                        Name *</label>
                                                    <input type="text" id="last_name" value="{{$agent->last_name}}"
                                                        name="last_name"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        maxlength="100" required />
                                                </div>
                                                <div class="mb-6">
                                                    <label class="block mb-2 text-sm font-medium text-gray-900">Email</label>
                                                    <input type="email" id="email" name="email"
                                                        value="{{$agent->email}}"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        maxlength="255" onchange="return ValidateEmail()" />
                                                    <p class="small" id="small-email"></p>
                                                </div>
                                            </div>
                                            <div class="">
                                                <button data-modal-toggle="defaultModal" type="button"
                                                    class="bg-amber-500 mb-10 hover:bg-amber-600 focus:ring-4 focus:outline-none focus:ring-amber-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Close</button>
                                                <button
                                                    class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"
                                                    onclick="return validation()">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Brokerage / Fees -->
    <h2 id="brokerage-heading">
        <button type="button"
            class="flex items-center justify-between w-full p-5 font-medium text-left bg-neutral-100 text-gray-500 border border-b-0 border-gray-400 rounded-t-xl focus:ring-4 focus:ring-gray-200"
            data-accordion-target="#brokerage-details" aria-expanded="true" aria-controls="brokerage-details">
            <span class="text-slate-900 text-md">Brokerage / Fees</span>
            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
    </h2>
    <div id="brokerage-details" class="hidden" aria-labelledby="brokerage-heading">
        <div class="p-5 font-light border border-b-0 border-gray-200  ">
            <form action="{{url('agent/brokerage-fee')}}" method="post">
                @csrf
                <div class="grid mb-6 md:grid-cols-3">
                    <div>
                        <p class="block mb-2 text-sm font-medium text-gray-900"><b>Sale Deals</b></p>
                        <div class="">
                            <!-- Dropdown menu -->
                            <select data-te-select-init class="rounded-md w-32 p-2" id="sale_fee_type_id"
                                name="sale_fee_type">
                                @if($agent->sale_fee_type != '')
                                <option value="{{$agent->sale_fee_type}}">{{$agent->sale_fee_type}}</option>
                                @endif
                                @if ($agent->sale_fee_type != "Variable")
                                <option value="Variable">Variable</option>
                                @endif
                                @if ($agent->sale_fee_type != "Fixed")
                                <option value="Fixed">Fixed</option>
                                @endif
                                @if ($agent->sale_fee_type !="Percent")
                                <option value="Percent">Percent</option>
                                @endif
                            </select>
                        </div>
                        <br>
                        <div class="mb-6">
                            <input type="number" id="sale_fee_amount_id" step="any" name="sale_fee_amount"
                                class="w-32 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   "
                                value="{{$agent->sale_fee_amount}}">
                        </div>
                    </div>
                    <div>
                        <p class="block mb-2 text-sm font-medium text-gray-900"><b>Rent Deals</b></p>
                        <div class="">
                            <!-- Dropdown menu -->
                            <select data-te-select-init class="rounded-md w-32 p-2" id="rent_fee_type_id"
                                name="rent_fee_type">
                                @if($agent->rent_fee_type != '')
                                <option value="{{$agent->rent_fee_type}}">{{$agent->rent_fee_type}}</option>
                                @endif
                                @if ($agent->rent_fee_type != "Variable")
                                <option value="Variable">Variable</option>
                                @endif
                                @if ($agent->rent_fee_type != "Fixed")
                                <option value="Fixed">Fixed</option>
                                @endif
                                @if ($agent->rent_fee_type !="Percent")
                                <option value="Percent">Percent</option>
                                @endif
                            </select>
                        </div>
                        <br>
                        <div class="mb-6">
                            <input type="number" id="rent_fee_amount_id" step="any" name="rent_fee_amount"
                                value="{{$agent->rent_fee_amount}}"
                                class="w-32 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   ">
                        </div>
                    </div>
                    <div class="text-center">
                        <button
                            class="w-32 bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"
                            onclick="return validation()">Save</button>
                    </div>
                </div>
                
            </form>
        </div>
    </div>

    <h2 id="address-heading">
        <button type="button"
            class="flex items-center justify-between w-full p-5 font-medium text-left text-gray-500 bg-neutral-100 border border-b-0 border-gray-400 rounded-t-xl focus:ring-4 focus:ring-gray-200"
            data-accordion-target="#address-details" aria-expanded="true" aria-controls="address-details">
            <span class="text-slate-900 text-md">Business Details</span>
            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
    </h2>
    <div id="address-details" class="hidden" aria-labelledby="address-heading">
        <div class="p-5 font-light border border-b-0 border-gray-200  ">
            <div class="flex">
                <div class="w-1/2">
                    <p class="block mb-2 text-sm font-medium text-gray-900"><b>Business Name: </b> {{$ag_bs_name}}</p>
                    <p class="block mb-2 text-sm font-medium text-gray-900">
                        <b>Address: </b> <br />
                        {{$ag_addr}}<br />
                        {{$ag_city}} {{$ag_state}} {{$ag_zip}}<br />
                        {{$ag_state}}<br />
                        {{$ag_country}}
                    </p>
                    <p class="block mb-2 text-sm font-medium text-gray-900"><b>Phone: </b> {{$ag_phone}}</p>
                </div>
                <div class="w-1/2">
                    <p class="block mb-2 text-sm font-medium text-gray-900"><b>RERA No: </b> {{$ag_rera}}</p>
                    <p class="block mb-2 text-sm font-medium text-gray-900"><b>GST No: </b> {{$ag_gst}}</p>
                </div>
            </div>
            <!-- Modal toggle -->
            <button
                class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"
                type="button" data-modal-toggle="defaultModaladdress">
                Edit Address</button>

            <!-- Main modal -->
            <div id="defaultModaladdress" tabindex="-1" aria-hidden="true"
                class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-modal md:h-full">
                <div class="relative w-full h-full max-w-2xl md:h-auto">
                    <!-- Modal content -->
                    <div class="social-profilerelative bg-white rounded-lg shadow ">
                        <!-- Modal header -->
                        <div class="flex items-start justify-between p-4 border-b rounded-t">
                            <h3 class="text-xl font-semibold text-gray-900">
                                Address
                            </h3>
                            <button type="button"
                                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
                                data-modal-toggle="defaultModaladdress">
                                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                        clip-rule="evenodd"></path>
                                </svg>
                                <span class="sr-only">Close modal </span>
                            </button>
                        </div>
                        <!-- Modal body -->
                        <form action="{{url('agent/edit-profile-address')}}" method="post">
                            @csrf
                            <div class="dialog">
                                <div class="dialog-overlay"></div>
                                <div class="modal-dialog dialog-box">
                                    <div class="dialog-content">
                                        <div class="dialog-header"></div>
                                        <div class="dialog-body">
                                            <div class="grid grid-gap-2 grid-cols-2 p-2">
                                                <div class="input-group-outline input-group my-3">
                                                    <label class="form-label">Business Name</label>
                                                    <input type="text" id="business_name" value="{{$ag_bs_name}}"
                                                        name="business_name"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        maxlength="100" />
                                                </div>
                                                <div class="input-group-outline input-group my-3 ml-5">
                                                    <label class="form-label">RERA No</label>
                                                    <input type="text" id="rera_no" value="{{$ag_rera}}"
                                                        name="rera_no"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        maxlength="100" />
                                                </div>
                                                <div class="input-group-outline input-group my-3">
                                                    <label class="form-label">GST No</label>
                                                    <input type="text" id="gst_no" value="{{$ag_gst}}"
                                                        name="gst_no"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        maxlength="100" />
                                                </div>
                                                <div class="input-group-outline input-group my-3 ml-5">
                                                    <label class="form-label">Address *</label>
                                                    <input type="text" id="address" name="address" value="{{$ag_addr}}"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        required />
                                                </div>
                                                <!-- <div> -->

                                                <livewire:statecitydropdown2 />
                                                <!-- </div> -->
                                                <div class="input-group-outline input-group my-3">
                                                    <label class="form-label">Zip *</label>
                                                    <input type="text" id="zip" name="zip" maxlength="6"
                                                        value="{{$ag_zip}}"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        required />
                                                </div>
                                                <div class="ml-5 mt-3">
                                                    <label class="form-label">Country</label>
                                                    <input id="country" name="country" value="India"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        readonly />
                                                </div>
                                                <div class="input-group-outline input-group my-3">
                                                    <label class="form-label">Phone *</label>
                                                    <input type="text" maxlength="10" id="phone" name="phone"
                                                        value="{{$ag_phone}}"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                        required />
                                                </div>
                                            </div>
                                            <div class="dialog-footer p-2">
                                                <button data-modal-toggle="defaultModaladdress" type="button"
                                                    class="bg-amber-500 mb-10 hover:bg-amber-600 focus:ring-4 focus:outline-none focus:ring-amber-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Close</button>
                                                <button
                                                    class="button bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- end code for address section  -->
        </div>
    </div>


    <h2 id="profile-qr-code-heading">
        <button type="button"
            class="flex items-center justify-between w-full p-5 font-medium text-left text-gray-500 bg-neutral-100 border border-b-0 border-gray-400 rounded-t-xl focus:ring-4 focus:ring-gray-200"
            data-accordion-target="#profile-qr-code" aria-expanded="true" aria-controls="profile-qr-code">
            <span class="text-slate-900 text-md">QR Code</span>
            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
    </h2>
    <div id="profile-qr-code" class="hidden" aria-labelledby="profile-qr-code-heading">
        <div class="p-5 font-light border border-b-0 border-gray-200  ">
            <h3 class="text-lg font-bold pb-4 my-4">Profile QR Code</h3>
            <div class="mb-6">
                {!! QrCode::size(200)->generate(url('/')."/agents/".$agent->handle."?t=".base64_encode($agent->handle)) !!}
            </div>
            <a href="{{ url('/agent/qr-code/'.$agent->handle ) }}" class="p-2 rounded-lg bg-lime-500">Print QR Code</a>
        </div>
    </div>

    <h2 id="unique-handle-heading">
        <button type="button"
            class="flex items-center justify-between w-full p-5 font-medium text-left bg-neutral-100 text-gray-500 border border-b-0 border-gray-400 rounded-t-xl focus:ring-4 focus:ring-gray-200"
            data-accordion-target="#unique-handle" aria-expanded="true" aria-controls="unique-handle">
            <span class="text-slate-900 text-md">Unique URL</span>
            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
    </h2>
    <div id="unique-handle" class="hidden" aria-labelledby="unique-handle-heading">
        <div class="p-5 font-light border border-b-0 border-gray-200  ">
            <!-- start code for agent unique handle -->
            <h3 class="text-lg font-bold my-4">Unique URL</h3>
            <p class="block mb-2 text-sm font-medium text-gray-900"><b>Unique Handle: </b> {{$agent->handle}} </p>
            <p class="block mb-2 text-sm font-medium text-gray-900"><b>Public URL: </b>
            <div class="overflow-y-scroll text-sm font-medium text-gray-500 p-2">
                <a href="{{ url('/')}}/agents/{{$agent->handle}}" target="_blank">
                    {{ url('/agents/'.$agent->handle) }}
                </a>
            </div>

            <!-- code end for agent unique handle -->
        </div>
    </div>




    <h2 id="social-profile-heading">
        <button type="button"
            class="flex items-center justify-between w-full p-5 font-medium text-left bg-neutral-100 text-gray-500 border border border-gray-400 rounded-xl focus:ring-4 focus:ring-gray-200"
            data-accordion-target="#social-profile-details" aria-expanded="true" aria-controls="social-profile-details">
            <span class="text-slate-900 text-md">Social Profiles</span>
            <svg data-accordion-icon class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
    </h2>
    <div id="social-profile-details" class="hidden" aria-labelledby="social-profile-heading">
        <div class="p-5 font-light border border border-gray-200 rounded-lg">
            <!-- start code for social media section  -->
            @if(!is_null($agent->facebook_profile))
            <p class="block mb-2 text-sm font-medium text-gray-900">
                <b>Facebook Profile:</b> {{$agent->facebook_profile}}
            </p>
            @endif

            @if(!is_null($agent->instagram_profile))
            <p class="block mb-2 text-sm font-medium text-gray-900">
                <b>Instagram Profile:</b> {{$agent->instagram_profile}}
            </p>
            @endif

            @if(!is_null($agent->twitter_profile))
            <p class="block mb-2 text-sm font-medium text-gray-900">
                <b>Twitter Profile: </b> {{$agent->twitter_profile}}
            </p>
            @endif

            @if(!is_null($agent->linkedin_profile))
            <p class="block mb-2 text-sm font-medium text-gray-900">
                <b>Linkedin Profile: </b> {{$agent->linkedin_profile}}
            </p>
            @endif
            @if(!is_null($agent->whatsapp_no))
            <p class="block mb-2 text-sm font-medium text-gray-900">
                <b>WhatsApp No: </b> {{$agent->whatsapp_no}}
            </p>
            @endif
            <!-- Modal toggle -->
            <button
                class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"
                type="button" data-modal-toggle="defaultModalsocial">
                Edit Social Media</button>

            <!-- Main modal -->
            <div id="defaultModalsocial" tabindex="-1" aria-hidden="true"
                class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-modal md:h-full">
                <div class="relative w-full h-full max-w-2xl md:h-auto">
                    <!-- Modal content -->
                    <div class="relative bg-white rounded-lg shadow ">
                        <!-- Modal header -->
                        <div class="flex items-start justify-between p-4 border-b rounded-t">
                            <h3 class="text-xl font-semibold text-gray-900">
                                Social Media Details
                            </h3>
                            <button type="button"
                                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
                                data-modal-toggle="defaultModalsocial">
                                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                        clip-rule="evenodd"></path>
                                </svg>
                                <span class="sr-only">Close modal</span>
                            </button>
                        </div>
                        <!-- Modal body -->
                        <form action="{{url('agent/add-social-media-profile')}}" method="post">
                            @csrf
                            <div class="dialog px-2">
                                <div class="dialog-overlay"></div>
                                <div class="modal-dialog dialog-box">
                                    <div class="dialog-content">
                                        <div class="dialog-header"></div>
                                        <div class="dialog-body">
                                            <div class="grid grid-gap-2 grid-cols-2 p-2">
                                                <div class="input-group-outline input-group my-3">
                                                    <label class="form-label">Facebook Profile Url</label>
                                                    <input type="text" id="facebook_profile" maxlength="255"
                                                        value="@if(!is_null($agent->facebook_profile)) {{$agent->facebook_profile}} @endif"
                                                        name="facebook_profile"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                                         />
                                                </div>
                                                <div class="input-group-outline input-group my-3 ml-5">
                                                    <label class="form-label">Instagram Profile Url</label>
                                                    <input type="text" id="instagram_profile" maxlength="255"
                                                        value="@if(!is_null($agent->instagram_profile)) {{$agent->instagram_profile}} @endif"
                                                        name="instagram_profile"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" />
                                                </div>
                                                <div class="input-group-outline input-group my-3">
                                                    <label class="form-label">Twitter Profile Url</label>
                                                    <input type="text" id="twitter_profile" maxlength="255"
                                                        value="@if(!is_null($agent->twitter_profile)) {{$agent->twitter_profile}} @endif"
                                                        name="twitter_profile"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" />
                                                </div>
                                                <div class="input-group-outline input-group my-3 ml-5">
                                                    <label class="form-label">Linekdin Profile Url</label>
                                                    <input type="text" id="linkedin_profile" maxlength="255"
                                                        value="@if(!is_null($agent->linkedin_profile)) {{$agent->linkedin_profile}} @endif"
                                                        name="linkedin_profile"
                                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" />
                                                </div>
                                                <div class="input-group-outline input-group my-3">
                                                    <label class="form-label">WhatsApp No</label>
                                                    <input type="text" id="whatsapp_no" maxlength="10"
                                                        value="@if(!is_null($agent->whatsapp_no)) {{$agent->whatsapp_no}} @endif"
                                                        name="whatsapp_no"
                                                        class=" ml-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" />
                                                </div>
                                            </div>
                                            <div class="dialog-footer p-2">
                                                <button data-modal-toggle="defaultModalsocial" type="button"
                                                    class="bg-amber-500 mb-10 hover:bg-amber-600 focus:ring-4 focus:outline-none focus:ring-amber-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Close</button>
                                                <button
                                                    class="bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- end code for social media section  -->
        </div>
    </div>
</div>

@stop