@extends('layouts.agents.agent')
@section('title', 'Price&Features')

@section('content')
@php
if(isset($property)){
$bedroom = $property->bedroom;
$bathroom = $property->bathroom;
$open_parkings = $property->open_parkings;
$covered_parkings = $property->covered_parkings;
$price = $property->price;
$balconies = $property->balconies;
$floor_no = $property->floor_no;
$total_floors = $property->total_floors;
$carpet_area = $property->carpet_area;
$super_area = $property->super_area;
$furnishing_type = $property->furnishing_type;
$security_deposit = $property->security_deposit;
$agreement_period = $property->agreement_period;
$available_from = $property->available_from;
$sale_rent = $property->sale_rent;
}
else{
$id = '';
$bedroom = old('bedroom') ;
$bathroom = old('bathroom');
$open_parkings = old('open_parkings');
$covered_parkings = old('covered_parkings');
$price = old('price');
$balconies = old('balconies');
$floor_no = old('floor_no');
$total_floors = old('total_floors');
$carpet_area = old('carpet_area');
$super_area = old('super_area');
$furnishing_type = old('furnishing_type');
$security_deposit = old('security_deposit');
$agreement_period = old('agreement_period');
$available_from = old('available_from');
$sale_rent = old('sale_rent');
}
@endphp

<div class="w-full rounded overflow-hidden">
    <form action="{{url('/agent/property/store-priceFeature')}}" id="amenitesForm" method="post">
        <div class="mb-6">
            @csrf
            <div class="w-full">
                <h2 class="text-3xl font-bold ">Property Listing Status</h2>
                <div class="p-5 mt-4 bg-grey-100">
                    <p class="mb-3 text-2xl">GENERAL</p>
                    <div class="input-group input-group-outline">
                        <span>Display Price :</span>
                        <input type="text" id="price" style="border:2px solid lightgrey;" placeholder="Property price..."
                            name="price" value="{{ $price }}"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                    </div>
                </div>
                <div class=" pb-5 p-5 mt-4 bg-grey-100">
                    <p class="mb-3 text-2xl">ADDITIONAL</p>
                    <div class="grid grid-cols-4 price-feature-grid">
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Bedrooms</span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="bedroom" name="bedroom" value="{{$bedroom}}" max="50"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Bathrooms: </span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="bathroom" name="bathroom" value="{{$bathroom}}" max="50"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Balconies</span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="balconies" name="balconies" value="{{$balconies}}" max="50"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Floor No : </span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="floor_no" name="floor_no" value="{{$floor_no}}" max="100"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Total Floors</span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="total_floors" name="total_floors" value="{{$total_floors}}" max="100"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Open Parkings:</span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="open_parkings" name="open_parkings" value="{{ $open_parkings }}" max="50"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Covered Parkings:</span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="covered_parkings" name="covered_parkings" value="{{ $covered_parkings }}" max="50"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Carpet Area: (in Square Feet)</span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="carpet_area" name="carpet_area" value="{{$carpet_area}}"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Super Area: (in Square Feet)</span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="super_area" name="super_area" value="{{ $super_area }}"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Furnishing Type</span>
                                <select name="furnishing_type" id="furnishing_type"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control">
                                    <option value="Furnished" @php if($furnishing_type=="Furnished" ) echo 'selected' ;
                                        @endphp>Furnished</option>
                                    <option value="Un-Furnished" @php if($furnishing_type=="Un-Furnished" )
                                        echo 'selected' ; @endphp>Un-Furnished</option>
                                    <option value="Semi-Furnished" @php if($furnishing_type=="Semi-Furnished" )
                                        echo 'selected' ; @endphp>Semi-Furnished</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                @if($sale_rent == 'Rent')
                <div class=" pb-5 p-5 mt-4 bg-grey-100">
                    <p class="mb-3 text-2xl">AVAILABILITY</p>
                    <div class="grid grid-cols-4">
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Available From:</span>
                                @if($available_from != '0000-00-00')
                                <input type="date" style="border:2px solid lightgrey;" id="availabe_from"
                                    name="available_from" value="{{$available_from}}"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                                @else
                                <input type="date" style="border:2px solid lightgrey;" id="availabe_from"
                                    name="available_from"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                                @endif

                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Security Deposit: </span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="Enter here -----"
                                    id="security_deposit" name="security_deposit" value="{{$security_deposit}}"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                        <div class="p-2">
                            <div class="input-group input-group-outline">
                                <span>Agreement Period: </span>
                                <input type="number" style="border:2px solid lightgrey;" placeholder="In months"
                                    id="agreement_period" name="agreement_period" value="{{$agreement_period}}"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  form-control" />
                            </div>
                        </div>
                    </div>
                </div>
                @endif
            </div>
        </div>
        <a href="{{url('/agent/property/amenities')}}"
            class="text-white bg-neutral-600 hover:bg-neutral-700 focus:ring-4 focus:outline-none focus:ring-neutral-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Prev</a>
        <button type="submit" id="amenitiesForm"
            class="text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:outline-none focus:ring-cyan-900 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">
            Save & Next
        </button>
    </form>
</div>
@stop