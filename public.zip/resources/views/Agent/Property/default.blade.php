@extends('layouts.agents.agent')
@section('title', 'Default URL')

@section('content')
<div class="mb-6">
    <div class="w-full rounded overflow-hidden">
        @if($property->count() > 0)
            <h2 class="text-3xl font-bold">Property Unique URL</h2>
            <div class="mt-8">
                This is the public URL of the property page. You can share it with others on Social media or WhatsApp by clicking on the appropriate sharing icon.<br/>
                Please remember that the public link will work for others only after the property is published.
            </div> 
            <div class="w-full flex border rounded border-inherit p-4 mt-4 default-flex overflow-auto">
                <div class="w-2/3 text-xl default-url">
                    <p id="propertyUrl">{{url('/')}}/{{ $property->unique_url }}</p>
                </div>
                <div class="w-1/3 text-center default-social-icons">
                    <span>share property on - </span>
                    <a href="https://www.facebook.com/sharer.php?u={{url('/')}}/{{ $property->unique_url }}" class="text-2xl">
                        <i class="fa-brands fa-facebook mx-1"></i>
                    </a>
                    <a href="http://api.whatsapp.com/send?text={{url('/')}}/{{ $property->unique_url }}" class="text-2xl">
                        <i class="fa-brands fa-whatsapp mx-1"></i>
                    </a>
                    <a href="https://www.instagram.com/share?url={{url('/')}}/{{ $property->unique_url }}" class="text-2xl">
                        <i class="fa-brands fa-instagram mx-1"></i>
                    </a>
                    <a href="https://twitter.com/share?url={{url('/')}}/{{ $property->unique_url }}" class="text-2xl">
                        <i class="fa-brands fa-twitter mx-1"></i>
                    </a>
                    <a href="mailto:?Subject=TEST&body={{url('/')}}/{{ $property->unique_url }}" class="text-2xl">
                        <i class="fa-solid fa-envelope mx-1"></i>
                    </a>
                    <a href="https://linkedin.com/shareArticle?mini=true&url={{url('/')}}/{{ $property->unique_url }}" class="text-2xl">
                        <i class="fa-brands fa-linkedin mx-1 text-sky"></i>
                    </a>
                    <div class="inline">
                        <span>or copy the URl: </span>
                        <a class="text-2xl cursor-pointer" onclick="copyPropertyUrl()">
                            <i class="fa-solid fa-copy mx-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        @endif
    </div>
</div>
    <div class="">
        <a href="{{url('/agent/video/video')}}" class="text-white bg-neutral-600 hover:bg-neutral-700 focus:ring-4 focus:outline-none focus:ring-neutral-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"> Prev </a>
    </div>
@stop