@include('includes.agents.head')
@include('flash-message')
<div class="container mx-auto px-auto mt-12">
    <div class="my-3">     
        <h4 class="text-center text-2xl m-4">Sign in</h4>
    </div>
    <div class="flex justify-center">
        <form action="{{url('backend/sign-in')}}" method="post">
            @csrf
            <div class="my-3">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" maxlength="255" value="{{ old('email') }}" class="w-full rounded-lg" required/>
            </div>
            <div class="my-3">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" maxlength="255" class="w-full rounded-lg" required/>
            </div>
            <button type="submit" class="m-2 bg-black text-white px-6 py-2 rounded-lg font-semibold">Sign In</button>
        </form>
    </div>
</div>
@include('includes.agents.foot')