@extends('backend.layouts.default')
@section('content')
    <div class="my-3">
        <hr>
        <h2 class="text-center text-2xl m-4">Add / Edit Plan</h2>
        <hr>
    </div>
    <div class="flex justify-center my-8">
        <form action="{{ url('backend/plans/add' . ($plan_details != '' ? '/' . $plan_details->id : '')) }}" method="get">
            <div class="grid grid-cols-2 gap-10">
                @csrf
                <div class="my-3">
                    <label for="plan_name">Plan Name</label>
                    <input type="text" name="plan_name" id="plan_name"
                        value="{{ $plan_details != '' ? $plan_details->name : old('plan_name') }}"
                        class="w-full p-2 rounded-lg my-2" maxlength="50" required />
                </div>
                <div class="my-3">
                    <label for="price">Price</label>
                    <input type="number" name="price" id="price"
                        value="{{ $plan_details != '' ? $plan_details->price : old('price') }}"
                        class="w-full p-2 rounded-lg my-2" required />
                </div>
                <div class="my-3">
                    <label for="credits">Credits</label>
                    <input type="number" name="credits" id="credits"
                        value="{{ $plan_details != '' ? $plan_details->credits : old('credits') }}"
                        class="w-full p-2 rounded-lg my-2" required />
                </div>
                <div class="my-3">
                    <label for="duration">Duration</label>
                    <input type="number" name="duration" id="duration"
                        value="{{ $plan_details != '' ? $plan_details->duration : old('duration') }}"
                        class="w-full p-2 rounded-lg my-2" required />
                </div>
            </div>
            <div class="text-center mt-10 text-white text-lg">
                <button class="bg-red-600 px-5 py-1 rounded hover:bg-red-500">Save</button>
            </div>
        </form>
    </div>
    <div class="my-3">
        <hr>
        <h2 class="text-center text-2xl m-4">Plans</h2>
        <hr>
    </div>

    <table class="w-full table-auto text-center">
        <thead>
            <tr class="ad-border">
                <th>Name</th>
                <th>Price</th>
                <th>Credits</th>
                <th>Duration</th>
                <th>Status</th>
                <th colspan="2">Action</th>
            </tr>
        </thead>
        @foreach ($plans as $plan)
            <tr id="tab_row{{ $plan['id'] }}" class="ad-border">

                <td>{{ $plan['name'] }}</td>

                <td><span style="font-family: DejaVu Sans; sans-serif;">&#8377; {{ $plan['price'] }}</span></td>

                <td>{{ $plan['credits'] }}</td>

                <td>{{ $plan['duration'] }}</td>

                <td>
                    @if ($plan['active'] == 1)
                        <a href="#" class="plan_status text-indigo-700 underline"
                            id="{{ $plan['id'] }}">ENABLE</a>
                    @else
                        <a href="#" class="plan_status text-red-600 underline"
                            id="{{ $plan['id'] }}">DISABLE</a>
                    @endif
                </td>

                <td>
                    <a href="{{ url('/backend/plans/index/' . $plan['id']) }}" class="mx-3 text-lime-600"
                        id="{{ $plan['id'] }}">
                        <i class="fa fa-edit"></i>
                    </a>
                    <a href="#" class="delete-plan mx-3 text-red-700" id="{{ $plan['id'] }}"><i
                            class="fas fa-trash"></i> </a>
                </td>
            </tr>
        @endforeach
    </table>
@stop
