@extends('backend.layouts.default')
@section('content')
    <div class="my-3">
        <hr>
        <h2 class="text-center text-2xl m-4">Add / Edit Blog</h2>
        <hr>
    </div>
    <div class="mx-20 my-10">
        <form action="{{ url('backend/blogs/add')}}@if($blog->slug??'')/{{$blog->slug}}@endif" enctype="multipart/form-data" method="post" id="blog-form">
            <div class="grid gap-10">
                @csrf
                <div class="my-3">
                    <label for="blog_title" class="text-xl font-medium">Blog Title</label>
                    <input type="text" name="blog_title" id="blog_title"
                        value="{{$blog->title ?? ''}}" class="w-full p-2 rounded my-2"
                        maxlength="50" required />
                </div>
                <div>
                    <label for="blog_desc" class="text-xl font-medium">Description</label>
                    <textarea id="blog_desc" 
                        class="w-full p-2 rounded my-2" name="blog_desc"
                        placeholder="Write Description here..." value="" style="min-height: 46vh;" required>{{ $blog->description ?? '' }}</textarea>
                </div>
                <div>
                    <label class="text-xl font-medium" for="blog_image">Upload Image</label>
                    <input type="file"
                        class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50  focus:outline-none "
                        id="blog_image" name="blog_image" >
                </div>
                @if(($blog->image??''))
                <img src="{{url('/files/blogs/')}}/{{$blog->slug ??''}}/{{$blog->image??''}}"
                alt="No Blog image" class="max-w-full max-h-full object-contain object-center my-4">
                @endif
            </div>
            <br>
            <div class="flex justify-evenly mt-10 items-center">
                <div class="text-center text-white text-lg">
                    <a class="bg-red-600 px-10 py-2 rounded hover:bg-red-500" href="{{ url('/backend/blogs')}}">Cancel</a>
                </div>
                <div class="text-center text-white text-lg">
                    <a class="bg-green-600 px-10 py-2 rounded hover:bg-green-500" href="javascript:{}" onclick="document.getElementById('blog-form').submit();">Save</a>
                </div>
            </div>

        </form>
    </div>
@stop
