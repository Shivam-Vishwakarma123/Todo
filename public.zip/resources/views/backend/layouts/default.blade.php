@php
    $property = session('property');
@endphp
<!doctype html>
<html lang="en" dir="ltr">

<head>
    <title>Property Shops Admin Pannel</title>
    @include('backend.includes.head')
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.tailwindcss.min.css">
    <link href="https://cdn.datatables.net/v/dt/dt-1.13.6/af-2.6.0/datatables.min.css" rel="stylesheet">
 
    <script src="https://cdn.datatables.net/v/dt/dt-1.13.6/af-2.6.0/datatables.min.js"></script>
    <script>
        /* Public URL of the website use in JS - web_url */
        @php echo "web_url = \"" . URL::to('/') . "\";"; @endphp
    </script>
</head>


<body class="app sidebar-mini ltr light-mode">
<!-- Flash message -->
@include('flash-message')
    <!-- PAGE -->
    <div class="">   
        <!-- admin dashboard header -->
        @include('backend.includes.header')
        <!-- admin content section -->
        <div class="p-4">
            @yield('content')
        </div> 

    <!-- admin dashboard footer -->
    @include('backend.includes.footer')

    </div>

    <!-- admin dashboard foot -->
    @include('backend.includes.foot')
</body>

</html>