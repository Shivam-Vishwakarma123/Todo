@extends('backend.layouts.default')
@section('content')
<div class="grid grid-cols-2 gap-16">
    <div class="w-full  p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-8 ">
        <h1 class="text-3xl font-bold text-gray-900 mb-6 text-center">Recently Registered User</h1>

        <div class="relative overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500 ">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            Name
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Email
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Phone Number
                        </th>
                        <th scope="col" class="px-6 py-3">
                            SignUp
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @if ($agents->count() >0)
                    @foreach($agents as $row)
        
                    <tr class="bg-white border-b ">
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap ">
                            {{$row->first_name}} {{$row->last_name}}
                        </th>
                        <td class="px-6 py-4">
                            {{$row->email}}
                        </td>
                        <td class="px-6 py-4">
                            {{$row->phone}}
                        </td>
                        <td class="px-6 py-4">
                            {{ \Carbon\Carbon::parse($row->created_at)->format('d-m-Y H:i:s') }}
                        </td>
                    </tr>
                    @endforeach
                    @endif
                </tbody>
            </table>
        </div>
        
    </div>

    <div class="w-full p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-8 ">
        <h1 class="text-3xl font-bold text-gray-900 mb-6 text-center">Recently Received Payments</h1>

        <table class="w-full text-sm text-left text-gray-500 ">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        Name
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Plan
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Price
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Created
                    </th>
                </tr>
            </thead>
            <tbody>
                @if ($payments->count() >0)
                @foreach($payments as $row)
    
                <tr class="bg-white border-b ">
                    <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap ">
                        {{($row->agent)?->first_name}} {{($row->agent)?->last_name}}
                    </th>
                    <td class="px-6 py-4">
                        {{$row->plans?->name}}
                    </td>
                    <td class="px-6 py-4">
                        {{$row->plans?->price}}
                    </td>
                    <td class="px-6 py-4">
                        {{ \Carbon\Carbon::parse($row->created_at)->format('d-m-Y H:i:s') }}
                    </td>
                </tr>
                @endforeach
                @endif
            </tbody>
        </table>
    </div>

    <div class="w-full p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-8 ">
        <h1 class="text-3xl font-bold text-gray-900 mb-6 text-center">Recently Created Properties</h1>

        <div class="relative overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500 ">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            Name
                        </th>
                        <th scope="col" class="px-6 py-3">
                            City
                        </th>
                        <th scope="col" class="px-6 py-3">
                            State
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Created
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @if ($properties->count() >0)
                    @foreach($properties as $row)
        
                    <tr class="bg-white border-b ">
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap ">
                            {{$row->name}}
                        </th>
                        <td class="px-6 py-4">
                            {{($row->city)?->name}}
                        </td>
                        <td class="px-6 py-4">
                            {{($row->state)?->name}}
                        </td>
                        <td class="px-6 py-4">
                            {{ \Carbon\Carbon::parse($row->created_at)->format('d-m-Y H:i:s') }}
                        </td>
                    </tr>
                    @endforeach
                    @endif
                </tbody>
            </table>
        </div>
        
    </div>   
</div>
@stop