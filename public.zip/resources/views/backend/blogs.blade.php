@extends('backend.layouts.default')
@section('content')

    <div class="my-3">
        <hr>
        <h2 class="text-center text-2xl m-4">Blogs</h2>
        <hr>
    </div>
    <br>
    <a href="{{ url('/backend/blogs/edit/') }}" class="bg-red-600 px-5 py-2 text-white font-bold rounded hover:bg-red-500">
        Add new
    </a>
    <br><br>
    <div class="w-full bg-white rounded-lg shadow p-4">
        <table id="backend-table" class="display w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr class="ad-border">
                    <th>
                        Sno.
                    </th>
                    <th>
                        Title
                    </th>
                    <th>
                        Image
                    </th>
                    <th>
                        Created
                    </th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 0; ?>
                @if (count($blogs) > 0)
                    @foreach ($blogs as $row)
                        <tr id="tab_row{{ $row->slug }}" class="bg-white border ad-border">
                            <td><?php $i++;
                            echo $i; ?></td>

                            <td>{{ $row->title }}</td>
                            <td>
                                @if (!is_null($row->image))
                                    <img src="{{ url('/files/blogs/') }}/{{ $row->slug }}/{{ $row->image }}"
                                        alt="No logo image" class="max-w-full max-h-full object-contain object-center my-4">
                                @endif
                            </td>
                            <td>{{ $row->created_at }}</td>
                            <td class="">
                                <div class="flex justify-around">
                                    @if ($row->published == 1)
                                        <a href="#" class="publish_blog underline" style="color: blue"
                                            id="{{ $row->slug }}">Published</a>
                                    @else
                                        <a href="#" class="publish_blog underline" style="color: red;"
                                            id="{{ $row->slug }}">Not Published</a>
                                    @endif
                                    <a href="{{ url('/backend/blogs/edit/' . $row->slug) }}" class="text-lime-600"
                                        id="{{ $row->slug }}">
                                        <i class="fa fa-edit"></i> Edit
                                    </a>
                                    <a href="#" class="delete-blog text-red-700" id="{{ $row->slug }}"><i
                                            class="fas fa-trash"></i> Delete</a>

                                </div>
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>



@stop
