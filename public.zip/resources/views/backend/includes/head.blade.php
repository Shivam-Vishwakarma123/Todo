<!-- META DATA -->
<meta charset="UTF-8">
<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sash – Bootstrap 5  Admin & Dashboard Template">
<meta name="csrf-token" content="{{ csrf_token() }}">       <!-- Adding meta for recieve csrf token in custom js file  -->
<meta name="author" content="Spruko Technologies Private Limited">
<meta name="keywords" content="admin,admin dashboard,admin panel,admin template,bootstrap,clean,dashboard,flat,jquery,modern,responsive,premium admin templates,responsive admin,ui,ui kit.">

<!-- TITLE -->
<title>Laravel - Admin Site Dashboard </title>

<!-- flowbite css -->
<link rel="stylesheet" href="{{url('css/flowbite.min.css')}}" />

<!-- STYLE CSS -->
<link href="{{url('css/backend/custom.css')}}" rel="stylesheet" />
<link href="{{url('css/custom.css')}}" rel="stylesheet" />

<!-- fontawesome link -->
<link href="{{url('css/fontawesome.min.css')}}" rel="stylesheet" />
<script src="{{ url('js/jquery.min.js') }}"></script>
