@extends('backend.layouts.default')
@section('content')

    <div class="my-3">
        <hr>
        <h2 class="text-center text-2xl m-4">Agents Listing</h2>
        <hr>
    </div>

    <div class="w-full bg-white rounded-lg shadow p-4">
        <table id="backend-table" class="display w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr class="ad-border">
                    <th>
                        Name
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        SignUp
                    </th>
                    <th>
                        Status
                    </th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @if (count($agents) > 0)
                    @foreach ($agents as $row)
                        <tr class="bg-white border ad-border" id="agent_data{{ $row->id }}">

                            <td>{{ $row->first_name }} {{ $row->last_name }}</td>

                            <td>{{ $row->email }}</td>

                            <td>{{ \Carbon\Carbon::parse($row->created_at)->format('d-m-Y H:i:s') }}</td>

                            <td>
                                @if ($row->active == 1)
                                    <a href="#" class="save_status text-indigo-700 underline"
                                        id="{{ $row->id }}">ENABLE</a>
                                @else
                                    <a href="#" class="save_status text-red-600 underline"
                                        id="{{ $row->id }}">DISABLE</a>
                                @endif
                            </td>

                            <td>
                                <a href="#" id="{{ $row->id }}" class="delete_agent text-red-800 underline">
                                    Delete
                                </a>
                            </td>

                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>



@stop
