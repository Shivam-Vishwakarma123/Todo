@extends('backend.layouts.default')
@section('content')

    <div class="my-3">
        <hr>
        <h2 class="text-center text-2xl m-4">All Properties Listing</h2>
        <hr>
    </div>
    <br>
    <div class="w-full bg-white rounded-lg shadow p-4">
        <table id="backend-table" class="w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr class="ad-border">
                    <th>
                        Agent Name</th>
                    <th>Property</th>
                    <th>
                       Published</th>
                    <th>Expiry</th>
                    <th>Views</th>
                    <th>
                        Status</th>
                    <th>Property Preview</th>
                </tr>
            </thead>
            @foreach ($properties as $propertie)
                <tr class="bg-white border ad-border">
                    <td >{{ $propertie->agents->first_name }} {{ $propertie->agents->last_name }}</td>

                    <td >{{ $propertie->name }}</td>

                    <td >{{ \Carbon\Carbon::parse($propertie->created_at)->format('d-m-Y H:i:s') }}</td>

                    <td >
                        <form action="{{ url('backend/expiry-due/' . $propertie->id) }}" method="get">
                            @csrf
                            <a class="p-2">
                                {{ \Carbon\Carbon::parse($propertie->expiry_date)->format('d-m-Y') }}
                            </a>
                            <div class="p-2">
                                <input type="date" name="new_expiry_date" value="{{ $propertie->expiry_date }}"
                                    id="new_expiry_date" class="p-1" required />
                                <button type="submit" class="py-2 text-indigo-700 underline">Update</button>
                            </div>
                        </form>
                    </td>

                    <td >{{ $propertie->views }}</td>

                    <td >
                        @if ($propertie->published == 1)
                            <a href="#" class="save_publish text-indigo-700 underline" id="{{ $propertie->id }}">ENABLE</a>
                        @else
                            <a href="#" class="save_publish text-red-600 underline" id="{{ $propertie->id }}">DISABLE</a>
                        @endif
                    </td>

                    <td class="px-6 py-4">
                        <a href="{{ url('/' . $propertie->unique_url) }}" target="_blank" class="underline text-lime-700">
                            Property Preview
                        </a>
                    </td>
                </tr>
            @endforeach
        </table>
    </div>

@stop
