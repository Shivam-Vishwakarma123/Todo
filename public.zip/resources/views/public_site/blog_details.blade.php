@extends('layouts.public')
@section('title', $blog->title)

@section('content')
    <div class="flex flex-col items-center bg-gray-50 h-full py-24 bg-lime-100 justify-center">
        <div class="w-11/12 bg-white rounded-lg shadow p-4 static-page">
            <!-- component -->
            <div class="mx-auto">
                <div class="text-right">
                    <a href="{{ url()->previous() }}"
                        class="inline-flex px-4 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                        Go Back
                    </a>
                </div>
                <main class="mt-10">
                    <div class="mb-4 md:mb-0 w-full mx-auto relative">
                        <div class="px-4 lg:px-0">
                            <h2 class="text-4xl font-semibold text-gray-800 leading-tight">
                                {{ $blog->title }}
                            </h2>
                        </div>
                        @if ($blog->image)
                            <div class="mt-3">
                                <img src="{{ url('/files/blogs/') }}/{{ $blog->slug }}/{{ $blog->image }}"
                                    class="lg:rounded" style="max-height: 500px;max-width:100%;" />
                            </div>
                        @endif
                    </div>
                    <div class="px-3 lg:px-0 mt-3 text-gray-700 text-lg leading-relaxed w-full">
                        <p class="pb-6" style="white-space: pre-wrap">{!! html_entity_decode($blog->description) !!}</p>
                    </div>
                    <div class="mt-3">
                        <p class="text-gray-500"><b>Published:</b>
                            {{ date('j M, Y h:m', strtotime($blog->published_at)) }} IST,
                            <b>Views:</b> {{ $blog->views }}
                        </p>
                    </div>
                </main>
                <!-- main ends here -->
            </div>
        </div>
        <div class="flex w-11/12 mt-12 {{ is_null($previous) ? 'justify-end' : 'justify-between' }}">
            @if (!is_null($previous))
                <a type="button" href="{{ url('blog') }}/{{ $previous->slug }}"
                    class="bg-gray-800 text-white rounded-l-md border-r border-gray-100 py-2 hover:bg-gray-900 hover:text-white px-3">
                    <div class="flex flex-row align-middle">
                        <svg class="w-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M7.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l2.293 2.293a1 1 0 010 1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="ml-2">Prev</span>
                    </div>
                </a>
            @endif
            @if (!is_null($next))
                <a type="button" href="{{ url('blog') }}/{{ $next->slug }}"
                    class="bg-gray-800 text-white rounded-r-md py-2 border-l border-gray-200 hover:bg-gray-900 hover:text-white px-3">
                    <div class="flex flex-row align-middle">
                        <span class="mr-2" >Next</span>
                        <svg class="w-5 ml-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                    </div>
                </a>
            @endif
        </div><br><br>
        <div class="text">
            <a href="{{ url()->previous() }}"
                class="inline-flex px-4 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                Go Back
            </a>
        </div>
    </div>
@stop
