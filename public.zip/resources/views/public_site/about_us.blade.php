@extends('layouts.public')
@section('title', 'About Us')

@section('content')
<div class="flex bg-gray-50 h-full py-24 bg-lime-100 justify-center">
    <div class="w-5/6 bg-white rounded-lg shadow p-4">
        <h1 class="text-center mb-10 text-2xl">About Us</h1>
        <p>PropertyShops.in is created as a platform for Indian "Real Estate Agents" better known as "Property Dealers".</p>
        <p>
            While many platforms strive to avoid property dealers in the search & negotiations of a property. 
            We understand that they are the most integral part of it, and if you ignore them then you are missing something.
        </p>
        <p>
            There are many platforms where you can list your properties for free or after payment. But those platforms are 
            not specifically built for Real Estate Agents. Some of the drawback of existing platforms:
            <ul class="list-disc ml-10">
                <li>Not built for Agents.</li>
                <li>Use Cross promotion for properties from other agents also.</li>
                <li>Show sponsored listings which require additional expenses for agent, or no one will see your listing.</li>
                <li>Provide leads based on the membership plan. The more you pay, more the chances to get leads.</li>
                <li>Interface is too cluttered making hard to read the information.</li>
                <li>Do not promote listings from individual agernt.</li>
                <li>Require monthly membership.</li>
                <li>Charge huge amount of money.</li>
            </ul>
        </p>
        <p>
            A property dealer is a professional with in-depth knowledge of the real estate market in their locality. 
            They know what issues or legal requirements to look for, when buying or renting a property. They know their locality in great details 
            and they can suggest you the best possible option for your requirements and budget. 
            Most of the dealers charge nominal fee for their effoerts. And they are also ready to negotiate the amount. 
        </p>
        <p>
            PropertyShops.in aims to fill this gap in the market so that the consumers get best deal for their money. 
            We want to become preferred property publishing platform for real estate agents. 
            We have developed our payment plans based on the requirements of a property dealer, and tried to make it as simple as it can be. 
        </p>
        <p>
            If you want to ask any questions then please feel free to email us at <a class="font-bold" href="mailto:cs@propertyshops.in">cs@propertyshops.in</a>, or 
            call at <a class="font-bold" href="tel:+918130248912">+91 81302 48912</a>.
        </p>
        <p>
            If you like to join as an Agent then <a class="font-bold" href="{{url('agent/sign-in')}}">Register Here</a>.
        </p>
    </div>
</div>
@stop