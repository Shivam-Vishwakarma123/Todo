@extends('layouts.public')
@section('title', 'Home')

@section('content')
    <section id="saerch_bar_section">
        <div class="relative" style="height: 720px;">
            <img src="{{ url('/images/home-top-banner.jpg') }}" class="h-full object-cover w-full"
                alt="Property Shops Top banner">
            <div class="absolute bottom-0 w-full overflow-hidden">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#ecfccb" viewBox="0 0 1000 100" preserveAspectRatio="none">
                    <path class="" d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z">
                    </path>
                </svg>
            </div>
            <form method="get" action="{{ route('property.search') }}" id="searchForm">
                {{ csrf_field() }}
                <div>
                    <h1 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-white text-center font-bold">Find
                        properties to buy or rent near you.</h1>
                    <br />
                    <ul class="grid w-full gap-6 grid-cols-2 place-items-center">
                        <li class="md:1/2 lg:w-2/5">
                            <input type="radio" id="buy" name="buy_rent" value="Buy" class="hidden peer" checked>
                            <label for="buy"
                                class="inline-flex items-center justify-between w-full p-3 text-gray-500 bg-white border border-gray-200 rounded-lg cursor-pointer peer-checked:border-2 peer-checked:border-cyan-600 peer-checked:bg-lime-100 peer-checked:text-cyan-600 hover:text-gray-600 hover:bg-gray-100">
                                <span class="flex w-full justify-between items-center">
                                    <span class="block flex flex-col">
                                        <span class="w-full text-lg font-semibold">Buy</span>
                                        <span class="hidden sm:inline w-full">I Want to Buy</span>
                                    </span>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                    </span>
                                </span>
                            </label>
                        </li>
                        <li class="md:1/2 lg:w-2/5 ">
                            <input type="radio" id="rent" name="buy_rent" value="Rent" class="hidden peer">
                            <label for="rent"
                                class="inline-flex items-center justify-between w-full p-3 text-gray-500 bg-white border border-gray-200 rounded-lg cursor-pointer peer-checked:border-2 peer-checked:border-cyan-600 peer-checked:bg-lime-100 peer-checked:text-cyan-600 hover:text-gray-600 hover:bg-gray-100">
                                <span class="flex w-full justify-between items-center">
                                    <span class="block flex flex-col">
                                        <span class="w-full text-lg font-semibold">Rent</span>
                                        <span class="hidden sm:inline w-full">I want to Rent</span>
                                    </span>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                    </span>
                                </span>
                            </label>
                        </li>
                    </ul>
                    <div class="mt-12 text-center">
                        <label for="search_text"
                            class="mb-2 text-sm font-medium text-gray-900 sr-only ">Search</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <svg aria-hidden="true" class="w-5 h-5 text-gray-500 " fill="none"
                                    stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                </svg>
                            </div>
                            <input type="search" id="search_text" name="search_text"
                                class="w-full p-4 pl-10 border border-gray-300 rounded-lg bg-gray-50 focus:ring-cyan-900 focus:border-cyan-800"
                                placeholder="Enter location or area name" required>
                            <input type="text" hidden id="city_id_search" name="city_id" value="">
                            <div class="suggestion absolute ui-front text-left capitalize">
                            </div>
                        </div>
                        <button type="submit"
                            class="text-gray-900 bg-lime-300 text-xl mt-8 right-2.5 bottom-1.5 hover:bg-lime-400 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-4 py-2">Search</button>
                    </div>
                </div>
                <br><br><br>
                <div class="container mx-auto text-center">
                    <a href="{{ url('/advance-search') }}"
                        class="inline-flex px-5 py-2 text-base rounded-md font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                        Advance Search
                    </a>
                </div>
            </form>

        </div>
    </section>
    <section id="our_properties" class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="px-2 md:px-10">
                <h2 class="text-2xl text-center font-bold mt-2 mb-6">Available Properties</h2>
            </div>
            <div class="my-3">
                <ul class="flex flex-wrap text-sm font-medium float-right md:mt-4" id="myTab"
                    data-tabs-toggle="#myTabContent" role="tablist">
                    <li class="mr-2" role="presentation">
                        <button class="inline-block p-4 border-b-2 rounded-t-lg text-2xl" id="profile-tab"
                            data-tabs-target="#profile" type="button" role="tab" aria-controls="profile"
                            aria-selected="false">Buy</button>
                    </li>
                    <li class="mr-2" role="presentation">
                        <button
                            class="inline-block p-4 border-b-2 rounded-t-lg hover:text-gray-600 hover:border-gray-300 text-2xl"
                            id="dashboard-tab" data-tabs-target="#dashboard" type="button" role="tab"
                            aria-controls="dashboard" aria-selected="false">Rent</button>
                    </li>
                </ul>
            </div>
            <br>
            <div id="myTabContent" class="mt-24">
                <div class="hidden p-2 md:p-4 rounded-lg justify-center" id="profile" role="tabpanel"
                    aria-labelledby="profile-tab">
                    <div class="overflow-x-auto w-full">
                        <div class="inline-flex h-full">
                            @if ($properties_sale->count() > 0)
                                @foreach ($properties_sale as $property)
                                    @php $width = 'index'; @endphp
                                    {{-- component called to show property details cards --}}
                                    <x-property-card :property="$property" :width="$width"></x-property-card>
                                @endforeach
                            @else
                                No properties found for sale.
                            @endif
                        </div>
                    </div>
                    @if ($properties_sale->count() > 0)
                        <div class="container mx-auto text-center">
                            <a href="{{ url('/properties/listing/Sale?sort=Recent&direction=asc') }}"
                                class="inline-flex px-5 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                                View All Properties for Sale
                            </a>
                        </div>
                    @endif
                </div>
                <div class="hidden p-2 md:p-4 rounded-lg justify-center" id="dashboard" role="tabpanel"
                    aria-labelledby="dashboard-tab">
                    <div class="overflow-x-auto w-full">
                        <div class="inline-flex h-full">
                            @if ($properties_rent->count() > 0)
                                @foreach ($properties_rent as $property)
                                    @php $width = 'index'; @endphp
                                    {{-- component called to show property details cards --}}
                                    <x-property-card :property="$property" :width="$width"></x-property-card>
                                @endforeach
                            @else
                                No properties found for rent.
                            @endif
                        </div>
                    </div>
                    @if ($properties_rent->count() > 0)
                        <div class="container mx-auto text-center">
                            <a href="{{ url('/properties/listing/Rent?sort=Recent&direction=asc') }}"
                                class="inline-flex px-5 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                                View All Properties to Rent
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
    {{-- new code for our products ends --}}
    <!-- section our properties end -->

    <!-- section why us start -->
    <section id="why_us_2" class="py-12 px-3 bg-white sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="grid lg:grid-cols-1">
                <div class="px-2 md:px-10">
                    <h3 class="text-2xl text-center font-bold mt-2 mb-6">Why PropertyShops.in?</h3>
                    <div class="">
                        <p class="mb-4">
                            We have built this platform from ground up keeping the needs and requirements of agents in mind.
                            Here are few key differences we are providing when compared to other platforms:
                        <ul class="list-decimal ml-10">
                            <li>Built specifically for real estate agents.</li>
                            <li>Agent specific property listing with NO ADs or Cross Promotions.</li>
                            <li>Clean and uncluttered interface.</li>
                            <li>QR Codes for property listing sharing.</li>
                            <li>No monthly, half yearly or annual commitments.</li>
                            <li>Pay as you go with NO memberships.</li>
                            <li>Simple and easy pricing.</li>
                        </ul>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section why us end -->
    <!-- section why us start -->
    <section id="why_us" class="py-12 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="grid lg:grid-cols-1">
                <div class="px-2 md:px-10">
                    <h3 class="text-2xl text-center font-bold mt-2 mb-6">Trust the Experts</h3>
                    <div class="">
                        <p class="mb-4">
                            A professional real estate agent can save you a lot of time wasted in studying the township or
                            locality. They know what is the advantages and/or disadvantages
                            are of a particular location. This information can help you readily select your preferred
                            location for buying your dream home or commercial space.
                        </p>
                        <p class="mb-4">
                            A real estate agent also helps you in completing all the paperwork, formalities and works with
                            you during the complete process starting from selecting a property
                            to actually get it registered in your name. They invest thier time and expertise for a price,
                            and that is worth it.
                        </p>
                        <p class="mb-4">
                            A good real estate agent can help you in:
                        </p>
                        <ul>
                            <li>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline mr-1">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Getting Best Deal
                            </li>
                            <li>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline mr-1">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Good value for your money
                            </li>
                            <li>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline mr-1">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Vsiting the available properties
                            </li>
                            <li>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-5 h-5 inline mr-1">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Complete the formalities
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section why us end -->

    <!-- section our agents start -->
    <section id="our_agents" class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="px-2 md:px-10">
                <h3 class="text-2xl text-center font-bold mt-2 mb-8">Our Featured Agents</h3>
            </div>
            <div class="text-center">
                <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    @foreach ($agents as $agent)
                        <x-agent-card :agent="$agent"> </x-agent-card>
                    @endforeach
                </div>
                <br><br>
                <a href="{{ url('/agents/listing?sort=Recent&direction=asc') }}"
                    class="inline-flex px-5 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                    View All Agents
                </a>
            </div>
        </div>
    </section>
    <!-- section our agents end -->

    <!-- section banner start -->
    <section id="banner"
        class="content-center justify-center py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-cyan-200">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="col-span-2 md:col-span-1 my-4">
                <div class="text-center p-3">
                    <div class="rounded-full mx-auto bg-white w-20 p-3">
                        <svg xmlns="http:/url/www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="w-18">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-.941-3.197m0 0A5.995 5.995 0 0012 12.75a5.995 5.995 0 00-5.058 2.772m0 0a3 3 0 00-4.681 2.72 8.986 8.986 0 003.74.477m.94-3.197a5.971 5.971 0 00-.94 3.197M15 6.75a3 3 0 11-6 0 3 3 0 016 0zm6 3a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-13.5 0a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z" />
                        </svg>
                    </div>
                    <div class="p-2">
                        <h1 class="sm:text-lg md:text-xl lg:text-2xl xl:text-3xl">Agents, Register or Login</h1>
                        <h2 class="text-xs xl:text-sm">Click on the below button to login or register</h2>
                    </div>
                    <a href="{{ url('agent/sign-in') }}"
                        class="inline-flex px-5 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                        Sign In / Sign up
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- section banner end -->

    {{-- section blog start --}}
    <section id="blogs">
        <div class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
            <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
                <h1
                    class="mb-10 text-center pt-3 text-3xl font-extrabold leading-none tracking-tight text-gray-900 md:text-5xl lg:text-4xl">
                    Recent <mark class="px-2 text-white rounded" style="background: #84cc16">Blogs</mark></h1>
                <br>
                <div class="px-2 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-2 gap-10">
                    {{-- card --}}
                    @if (count($blogs) > 0)
                        @foreach ($blogs as $blog)
                            <div class="w-full bg-white max-w-full flex border border-gray-400 pl-2">
                                @if ($blog->image ?? '')
                                    <div class="bg-center m-0 h-auto w-48 bg-contain text-center overflow-hidden blog-image"
                                        style="background-image: url({{ url('/files/blogs/') }}/{{ $blog->slug }}/{{ $blog->image }});background-repeat: no-repeat; 
                            ">
                                    </div>
                                @endif
                                <div class="w-full lg:max-w-full bg-white rounded-b p-4 flex flex-col justify-between leading-normal"
                                    style="min-height: 230px;">
                                    <div class="mb-4">
                                        <div class="text-gray-900 font-bold text-xl mb-2"><a
                                                href="{{ url('/blog' . '/' . $blog->slug) }}">{{ $blog->title }}</a>
                                        </div>
                                        <p class="text-gray-700 text-base"style="
                                                            overflow: hidden;
                                                            text-overflow: ellipsis;
                                                            display: -webkit-box;
                                                            -webkit-line-clamp: 4;
                                                            -webkit-box-orient: vertical;
                                                            ">
                                            {{ strip_tags($blog->description) }}</p>
                                    </div>
                                    <div class="flex flex-col items-start gap-2">
                                        <a href='{{ url('/blog' . '/' . $blog->slug) }}'
                                            class="inline-flex items-center font-medium text-gray-700 hover:underline">Read
                                            More<svg class="ml-2 w-4 h-4" fill="currentColor" viewBox="0 0 20 20"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd"
                                                    d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                                                    clip-rule="evenodd"></path>
                                            </svg></a>
                                        <div class="px-0 text-xs flex mt-2">
                                            <p class="text-gray-500">
                                                <b>Published:</b> {{ date('j M, Y h:m', strtotime($blog->published_at)) }}
                                                IST,
                                                <b>Views:</b> {{ $blog->views }}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>
            <br><br>
            <div class="text-center">
                <a href="{{ url('/blog') }}"
                    class="inline-flex px-5 py-2 text-base font-medium text-center text-white bg-lime-500 rounded-sm hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 m-2">
                    View All Posts
                </a>
            </div>
        </div>
    </section>
    {{-- section blog end --}}

    {{-- Popular links start --}}
    <section id="blogs">
        <div class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-gray-200">
            <h3 class="text-4xl text-center font-bold mt-2 mb-6">Popular Searches</h3>
            <br>
            <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
                <div class="px-2 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-3 xl:grid-cols-3 gap-10"> 
                    <div
                        class="flex flex-col pr-2 border-r-0 lg:border-r lg:border-gray-500 xl:border-r xl:border-gray-500">
                        @foreach ($popular_cities as $pc)
                            <a class="font-normal text-gray-700  underline mb-4" href="{{url('/matched-data')}}?sort=Recent&direction=asc&sale_rent=Any&city={{$pc->city->id}}&via=link">Properties in
                                 {{ $pc->city->name }}, {{ $pc->state->name }}.</a>  
                        @endforeach
                    </div>
                    <div
                        class="flex flex-col pr-2 border-r-0 lg:border-r lg:border-gray-500 xl:border-r xl:border-gray-500">
                        @foreach ($popular_types as $pc)
                            <a class="font-normal text-gray-700  underline mb-4" href="{{url('/matched-data')}}/?sort=Recent&direction=asc&sale_rent=Any&city={{$pc->city->id}}&property_type={{$pc->property_type}}&via=link" >{{$pc->property_type}} in
                                {{ $pc->city->name }}, {{ $pc->state->name }}.</a>
                        @endforeach
                    </div>
                    <div
                        class="flex flex-col">
                        @foreach ($propular_sale_rent as $pc)
                            <a class="font-normal text-gray-700  underline mb-4" href="{{url('/matched-data')}}/?sort=Recent&direction=asc&sale_rent={{$pc->sale_rent}}&city={{$pc->city->id}}&via=link">Properties on {{$pc->sale_rent}}
                                {{ $pc->city->name }}, {{ $pc->state->name }}.</a>
                        @endforeach
                    </div>
                </div>
            </div>

        </div>
    </section>
    {{-- Popular links end --}}
    @stop
