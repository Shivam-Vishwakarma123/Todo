@extends('layouts.public')
@section('title', 'Refund Terms')

@section('content')
    <div class="flex bg-gray-50 h-full py-24 bg-lime-100 justify-center">
        <div class="w-5/6 bg-white rounded-lg shadow p-4 static-page">
            <h1 class="text-center text-2xl">Refund Terms</h1>
            <p>You can purchase credits on PropertyShops.in via online payments only. One credit will be used to publish One property, and the
                purchased credits will <b>NEVER Expire</b>.</p>
            <p>Credits once purchased cannot be cancelled or redeemed to get any refund in bank/card account. The credits
                are at present non transferrable also. They will be stored in your account until your account is closed or
                disabled.</p>
            <p>When closing/disabling your account any credits in balance will expire.</p>
        </div>
    </div>
@stop
