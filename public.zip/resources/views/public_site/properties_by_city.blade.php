@extends('layouts.public')
@section('title', 'Properties at '. $propertie[0]->city->name )

@section('content')
    <section class="py-8 px-3 sm:py-10 sm:px-5 xl:py-20 lg:py-16 xl:px-10 lg:px-8 bg-lime-100">
        <div class="w-full sm:w-5/6 md:w-3/4 lg:5/6 mx-auto">
            <div class="flex gap-4 flex-wrap mb-10">
                <p class="ap-pricesort flex gap-2">
                    @sortablelink('Price')
                </p>
                <p class="ap-pricesort flex gap-2">
                    @sortablelink('Popularity')
                </p>
                <p class="ap-pricesort flex gap-2">
                    @sortablelink('Recent')
                </p>
                <div class="flex flex-wrap">
                    <div class="relative w-32 mr-2">
                        <?php  if(!(isset($_GET['sale_rent']))){?>
                        <!-- Dropdown menu -->
                        <select data-te-select-init class="rounded-md w-32 p-2 ap-pricesort pl-4"
                            style="border:none;text-align:start;font-size:15px;" id="type" name="type"
                            onChange="window.open(this.value, '_parent')">
                            <option value="{{ url('/properties/listing/All?sort=Recent&direction=asc') }}"
                                {{ $type == 'All' ? 'selected' : '' }}>All</option>
                            <option value="{{ url('/properties/listing/Rent?sort=Recent&direction=asc') }}"
                                {{ $type == 'Rent' ? 'selected' : '' }}>Rent</option>
                            <option value="{{ url('/properties/listing/Sale?sort=Recent&direction=asc') }}"
                                {{ $type == 'Sale' ? 'selected' : '' }}>Sale</option>
                        </select>
                        <?php }?>
                    </div>
                </div>
            </div>
            <h1 class="text-xl md:text-2xl" >
                Properties listed in <u>{{ $propertie[0]->city->name }}</u>
            </h1>
            <div class="my-3 mt-3">Total <b>{{ $count }}</b> Properties Found</div>
            <div class="grid gap-2 property_listing">
                @foreach ($propertie as $property)
                    {{-- to set the width of each card on display --}}
                    @php $width = ''; @endphp
                    {{-- component called to show property details cards --}}
                    <x-property-card :property="$property" :width="$width"></x-property-card>
                @endforeach
            </div>

            <div class="row">
                <div class="col-md-12">
                    {{ $propertie->appends(request()->query())->links() }}
                </div>
            </div>
        </div>

    </section>
@stop
