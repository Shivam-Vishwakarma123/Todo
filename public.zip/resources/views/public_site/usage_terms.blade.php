@extends('layouts.public')
@section('title', 'Usage Terms')

@section('content')
    <div class="flex bg-gray-50 h-full py-24 bg-lime-100 justify-center">
        <div class="w-5/6 bg-white rounded-lg shadow p-4 static-page">
            <h1 class="text-center text-2xl">Usage Terms</h1>
            <br>
            <div class="mb-10">
                <ul class="menu-inner flex justify-center items-center text-xl flex-col gap-10">
                    <li class="menu-item"><a href="{{ url('/about-us') }}"
                            class="menu-link font-medium pb-1 hover:text-black underline">About Us</a></li>
                    <li class="menu-item"><a href="{{ url('/terms-conditions') }}"
                            class="menu-link font-medium pb-1 hover:text-black underline">Terms of Use</a></li>
                    <li class="menu-item"><a href="{{ url('/privacy-policy') }}"
                            class="menu-link font-medium pb-1 hover:text-black underline">Privacy Policy</a></li>
                    <li class="menu-item"><a href="{{ url('/refund-terms') }}"
                            class="menu-link font-medium pb-1 hover:text-black underline">Refund Terms</a></li>
                </ul>
            </div>
        </div>
    </div>
@stop
