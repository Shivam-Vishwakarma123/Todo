<h3>Hello,</h3>
<p>Contact Us Form Submitted By :{!! $user['name'] !!}</p>

<p>You can contact with the following dtails:</p>
<table style="text-align: left">
    <tr><th style="padding:5px;">Phone number: </th><td>{!! $user['phone'] !!}</td></tr>
    <tr><th style="padding:5px;">Email Id: </th><td>{!! $user['email'] !!}</td></tr>
    <tr><th style="padding:5px;">Message: </th><td>{!! $user['message'] !!}</td></tr>
</table>
<p>Thanks!</p>
<p>PropertyShops Team</p>