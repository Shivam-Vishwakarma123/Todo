@extends('layouts.property')
@section('content')
@section('title',($property->sale_rent == 'Sale' ?'Buy': 'Rent').' property at '.$property->name)


    @php
        $i = 1;
        $y = 1;
        $floorplan_i = 1;
        $floorplan_tab = 1;
        $img = 1;
    @endphp


    {{-- div to show images from property images colums in header section  --}}
    @if ($property_images != '')

        <div class="mx-auto justify-center bg-slate-100 overflow-hidden" >
            @if ($property->published == 0 || $property->active == 0)
                <div class="bg-yellow-200 p-3 text-center">
                    <p class="text-black text-sm" style="margin-bottom: 0px !important;">You are previewing a not published/active property. It is visible to the
                        property owner (you) only.</p>
                </div>
            @endif
            <div id="controls-carousel" class="relative w-full" data-carousel="slide">
                <!-- Carousel wrapper -->
                <div class="relative overflow-hidden" style="height: 500px;"id="property-carousel-div" >
                    <!-- Item 1 -->
                    @if ($property_images->count() != 0)
                        @foreach ($property_images as $image)
                            <div class="hidden duration-700 ease-in-out bg-black snap-x" data-carousel-item>
                                <img src="{{ url('/files/property_images/') }}/{{ $image->property_id }}/{{ $image->file_name }}"
                                    class="absolute block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                    alt="Property Image">
                            </div>
                        @endforeach
                    @else
                        <div class="duration-700 ease-in-out bg-black">
                            <img src="{{ url('images/default_image-500.png') }}"
                                class="absolute block -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                alt="Property Image" style="height: auto;">
                        </div>
                    @endif
                </div>
                <!-- Slider controls -->
                <button type="button" id="carousel-prev-btn"
                    class="absolute left-6 z-30 flex items-center justify-center px-4 cursor-pointer group focus:outline-none" style="top:45%;height: auto"
                    data-carousel-prev>
                    <span
                        class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30  group-hover:bg-white/50  group-focus:ring-4 group-focus:ring-white  group-focus:outline-none">
                        <svg class="w-4 h-4 text-white " aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M5 1 1 5l4 4" />
                        </svg>
                        <span class="sr-only">Previous</span>
                    </span>
                </button>
                <button type="button" id="carousel-next-btn"
                    class="absolute top-0 right-6 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                    data-carousel-next style="top:45%;height: auto">
                    <span
                        class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30  group-hover:bg-white/50  group-focus:ring-4 group-focus:ring-white  group-focus:outline-none">
                        <svg class="w-4 h-4 text-white " aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="sr-only">Next</span>
                    </span>
                </button>
            </div>
        </div>



    @endif
    {{-- div to show images from property images colums in header section ends --}}

    {{-- property description and details section code starts  --}}
    <div class="container mx-auto p-3">
        <div class="grid grid-cols-3">
            <div class="col-span-2 details-div">
                <div class=" my-7 description-container">
                    <h1 class="border-underline text-2xl font-bold my-4 text-center">Property description</h1>
                    <div class="flex text-xl justify-center">
                        @if ($property->description != '')
                            {!! $property->description !!}
                        @else
                            <p>No Description Available</p>
                        @endif
                    </div>
                </div>
                <div class="photos-container">
                    <h2 class="border-underline text-2xl font-bold my-7 text-center">Photos</h2>
                    @if (count($property_images) > 0)
                        <div class="grid gap-3 grid-cols-2 md:grid-cols-5 mx-5">
                            {{-- for now only we will show images from property images table (property gallery table is blank) --}}
                            {{-- @if (count($property_galleries) > 0)
                            @foreach ($property_gallery_details as $key => $property_detail)
                            <img src="{{url('/files/property_thumbs/')}}/{{$property_detail['property_id']}}/{{$property_detail['random_file_name']}}"
                    class="w-100" alt="">
                    @if (isset($property_detail['short_description']))
                    <div class="property-gallery-description">
                        <p>{{$property_detail['short_description']}}</p>
                    </div>
                    @endif
                    @foreach ($property_detail['images'] as $property_images_detial)
                    <img class="lightboxed mx-1 rounded-1 shadow property_gallery_images h-60" rel="group1"
                        src="{{url('/files/property_thumbs/')}}/{{$property_detail['property_id']}}/{{$property_images_detial['file_name']}}"
                        data-link="{{url('/files/property_thumbs/')}}/{{$property_detail['property_id']}}/{{$property_images_detial['file_name']}}"
                        alt="Image Could't load">
                    @endforeach
                    @endforeach
                    @endif --}}
                            @foreach ($property_images as $image)
                                {{-- <img src="{{url('/files/property_thumbs/')}}/{{$image->property_id}}/{{$image->file_name}}"
                    class="w-36 h-36" alt="Property Image"/>
                    --}}
                                <a class="elem"
                                    href="{{ url('/files/property_images/') }}/{{ $image->property_id }}/{{ $image->file_name }}"
                                    title="Property Image" data-lcl-txt="lorem ipsum dolor sit amet"
                                    data-lcl-author="someone"
                                    data-lcl-thumb="{{ url('/files/property_thumbs/') }}/{{ $image->property_id }}/{{ $image->file_name }}">
                                    <span
                                        style="background-image: url('{{ url('/files/property_thumbs/') }}/{{ $image->property_id }}/{{ $image->file_name }}');"></span>
                                </a>
                            @endforeach
                        </div>
                    @else
                        <p class="text-center text-xl py-6">No Photos Available</p>
                    @endif
                </div>
                <div class="video-container">
                    <h2 class="border-underline text-2xl font-bold my-7 text-center">Videos</h2>
                    @if (count($property_videos))
                        <div class="grid gap-3 px-4 grid-cols-1 md:grid-cols-3">
                            @foreach ($property_videos as $property_video)
                                <div class="w-auto pb-0  inline-block relative gallery-image"
                                    name="{{ $property_video->video_type }}">
                                    @if ($property_video->video_url == '')
                                        <video width="285" height="100%" controls>
                                            <source
                                                src="{{ url('/files/property_videos/') }}/{{ $property_video->property_id }}/{{ $property_video->file_name }}"
                                                type="video/mp4">
                                            <source
                                                src="{{ url('/files/property_videos/') }}/{{ $property_video->property_id }}/{{ $property_video->file_name }}"
                                                type="video/ogg" />
                                            Your browser does not support the video tag.col-span-3 lg:col-span-3
                                            xl:col-span-3
                                            md:col-span-3 sm:col-span-2 xs:col-span-2
                                        </video>
                                    @else
                                        <x-embed url="{{ $property_video->video_url }}" />
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    @else
                        <br><br>
                        <p class="text-center text-xl py-6">No Video Available</p>
                    @endif
                </div>
                <div class=" my-7 location-container">
                    <h2 class="border-underline text-2xl font-bold my-4 text-center">Location</h2>
                    <div class="flex text-xl justify-center flex-wrap">
                        <span class="justify-center">{!! $property->address_line_1 !!}, {!! $city?->name !!},
                            {!! $state?->name !!} - {!! $property->zip !!}</span>
                    </div>
                </div>
            </div>

            <div class="details-container">
                <div class="details-ammenities text-left">
                    <h2 class="border-underline text-2xl font-bold">Ammenities</h2>
                    <div class="flex flex-col">
                        <ul>
                            @foreach ($property_amenities as $items)
                                @if ($items->Amenities != '')
                                    <li><i class="fa fa-caret-right mr-4" aria-hidden="true"></i>
                                        {{ $items->Amenities->name }}</li>
                                @endif
                            @endforeach
                        </ul>
                    </div>
                </div>
                <div class="details-features text-left">

                    <h2 class="border-underline text-2xl font-bold mb-3">Features</h2>
                    <div class="flex flex-col features-container">
                        <table class="shadow-sm bg-white border-collapse">
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Property Type</b></td>
                                <td class="border px-8 py-2">{{ $property->property_type }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Property Condition</b></td>
                                <td class="border px-8 py-2">{{ $property->property_condition }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Property Age</b></td>
                                <td class="border px-8 py-2">{{ $property->property_age }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Bedrooms</b></td>
                                <td class="border px-8 py-2">{{ $property->bedroom }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Bathrooms</b></td>
                                <td class="border px-8 py-2">{{ $property->bathroom }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Property Type</b></td>
                                <td class="border px-8 py-2">{{ $property->property_type }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Balconies</b></td>
                                <td class="border px-8 py-2">{{ $property->balconies }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>On Floor</b></td>
                                <td class="border px-8 py-2">{{ $property->floor_no }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Total Floors</b></td>
                                <td class="border px-8 py-2">{{ $property->total_floors }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Furnishing Type</b></td>
                                <td class="border px-8 py-2">{{ $property->furnishing_type }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Open Parkings</b></td>
                                <td class="border px-8 py-2">{{ $property->open_parkings }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Covered Parkings</b></td>
                                <td class="border px-8 py-2">{{ $property->covered_parkings }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Carpet Area</b></td>
                                <td class="border px-8 py-2">{{ $property->carpet_area }}</td>
                            </tr>
                            <tr class="bg-gray-50">
                                <td class="border px-8 py-2"><b>Super Area</b></td>
                                <td class="border px-8 py-2">{{ $property->super_area }}</td>
                            </tr>
                            @if ($property->sale_rent == 'Rent')
                                <tr class="bg-gray-50">
                                    <td class="border px-8 py-2"><b>Available From</b></td>
                                    <td class="border px-8 py-2">{{ $property->available_from }}</td>
                                </tr>
                                <tr class="bg-gray-50">
                                    <td class="border px-8 py-2"><b>Security Deposit</b></td>
                                    <td class="border px-8 py-2">{{ $property->security_deposit }}</td>
                                </tr>
                                <tr class="bg-gray-50">
                                    <td class="border px-8 py-2"><b>Agreement Period</b></td>
                                    <td class="border px-8 py-2">{{ $property->agreement_period }}</td>
                                </tr>
                            @endif

                        </table>

                    </div>
                </div>


            </div>
            {{-- Section 2 agent profile end --}}
        </div>
    </div>
    {{-- contact form in footer section starts --}}
    <div class="grid contact-form">
        <div class="agent-container">
            <div class="bg-grey my-4">
                <h3 class="text-xl font-bold my-7">About Agent</h3>
                <!-- Dispaly Agent logo here -->
                @if ($agents->logo_image != '')
                    <div class="flex overflow-hidden w-20">
                        <img src="{{ url('/files/agents/') }}/{{ $agents->id }}/{{ $agents->logo_image }}"
                            class="max-w-full max-h-full object-contain rounded-lg" alt="">
                    </div>
                @else
                    <div class="flex overflow-hidden w-20">
                        <img src="{{ url('./images/default_image.png') }}"
                            class="max-w-full max-h-full object-contain rounded-lg" alt="">
                    </div>
                @endif
                <div class="grid grid-cols-2 gap-6">
                    <div class="agent-contact">
                        <!-- Dispaly Aent Name here -->
                        <div class="pb-2 agent_name font-bold capitalize">{{ $agents->first_name }}
                            {{ $agents->last_name }}</div>
                        <!-- Dispaly Agent phone number here -->
                        @if ($agent_address != '')
                            @if (!$agents->dummy_record)
                                @if (!is_null($agent_address->phone))
                                    <p class="text-uppercase fs-1 my-3 icon-text">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor"
                                            class="w-5 h-5 inline text-lime-500 p-px">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                                        </svg>
                                        +91 {{ $agent_address->phone }}
                                    </p>
                                @endif
                            @endif
                            @if (
                                !is_null($agent_address->address) &&
                                    !is_null($agent_address->city) &&
                                    !is_null($agent_address->state) &&
                                    !is_null($agent_address->zip))
                                <p class="text-capitalize lh-lg icon-text">
                                    <i class="fas fa-map-marker-alt mr-2"></i>
                                    {{ $agent_address->address }}<br />{{ $agent_address->city->name }} -
                                    {{ $agent_address->zip }}
                                    {{ isset($agent_address->state) ? $agent_address->state->name : '' }}
                                </p>
                            @endif
                        @endif
                    </div>
                    <div class="profile-img">
                        @if ($agents->profile_image != '')
                            <div class="flex overflow-hidden max-w-lg my-3" style ="max-width:165px">
                                <img class="max-w-full max-h-full object-contain rounded-lg"
                                    src="{{ url('/files/agents/') }}/{{ $agents->id }}/{{ $agents->profile_image }}"
                                    alt="">
                            </div>
                        @else
                            <div class="flex overflow-hidden my-3" style ="max-width:165px">
                                <img class="max-w-full max-h-full object-contain rounded-lg"
                                    src="{{ url('/images/logo1.png') }}" alt="">
                            </div>
                        @endif
                    </div>
                </div>
                <div class="view-properties mt-2">
                    @if ($agents->property_count != 0)
                        <a href="{{ url('agents') }}/{{ $agents->handle }}/All?sort=recent-asc&direction=desc"
                            class="font-medium text-lime-500 hover:underline">
                            View {{ $agents->property_count }} properties
                        </a>
                    @else
                        <p class="font-medium text-white">No Properties added</p>
                    @endif
                </div>
                <div class="property-social-media">

                    <ul class="gap-2">
                        @if (!is_null($agents->facebook_profile))
                            <li>
                                <a href="{{ $agents->facebook_profile }}" class="facebook cursor-pointer"
                                    target="_blank">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                            </li>
                        @endif

                        @if (!is_null($agents->instagram_profile))
                            <li>
                                <a href="{{ $agents->instagram_profile }}" class="instagram cursor-pointer"
                                    target="_blank">
                                    <i class="fab fa-instagram"></i>
                                </a>
                            </li>
                        @endif

                        @if (!is_null($agents->twitter_profile))
                            <li>
                                <a href="{{ $agents->twitter_profile }}" class="twitter cursor-pointer" target="_blank">
                                    <i class="fab fa-twitter"></i>
                                </a>
                            </li>
                        @endif
                        @if (!is_null($agents->linkedin_profile))
                            <li>
                                <a href="{{ $agents->linkedin_profile }}" class="linkedin cursor-pointer"
                                    target="_blank">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                            </li>
                        @endif
                        @if (!is_null($agents->whatsapp_no))
                            <li>
                                <a href="https://wa.me/+91{{ $agents->whatsapp_no }}" class="whatsapp cursor-pointer"
                                    target="_blank">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                            </li>
                        @endif
                    </ul>
                </div>

            </div>
        </div>
        <div class="col-span-2 md:col-span-1 contact-form-container">
            <h3 class="text-xl font-bold my-5">Send Enquiry to Agent</h3>
            <div class="form-message" style="display: none"></div>
            <form id="myform">
                <input type="hidden" name="property" id="property_url" class="my-3 border-2 border-grey-200 w-full"
                    value="{{ $property->unique_url }}">
                <div class="my-4">
                    <label for="contact_name" class="my-3">Name</label>
                    <input type="text" name="contact_name" id="contact_name" placeholder="Enter Your Name"
                        required />
                </div>
                <div class="my-4">
                    <label for="contact_email" class="my-3">Email</label>
                    <input type="email" name="contact_email" id="contact_email" placeholder="Enter Your Email Id" />
                </div>
                <div class="my-4">
                    <label for="contact_phone" class="my-3">Phone Number</label>
                    <input type="tel" maxlength="10" name="contact_phone" id="contact_phone"
                        placeholder="Enter Your Phone Number" required />
                    <p id ="verifiedPhone" class="text-lime-600 text-lg mt-1 font-bold"></p>
                    <button id="verifyPhone" type="button"
                        class="my-1 bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Verify</button>
                </div>
                <!-- For checking purpose phone is verified or not -->
                <input type="hidden" class="status" name="status" value="0">

                {{-- input box for otp send on mobile number --}}
                <div id="otp_section" class="hidden">
                    <label for="contOtp" class="my-3">OTP</label>
                    <div class="my-4">
                        <input type="text" id="contOtp" name="otp" maxlength="4"
                            placeholder="Please enter otp sent on your mobile number">
                    </div>
                </div>

                {{-- to show countdown to resend otp button --}}
                <span class="countdown px-4 hidden"></span>

                {{-- resend otp button --}}
                <button type="button" id="resendOtp"
                    class="hidden bg-lime-500 mb-10 hover:bg-lime-600 focus:ring-4 focus:outline-none focus:ring-lime-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Resend
                    OTP</button>

                <div class="my-4">
                    <label for="contact_message" class="my-3">Message</label>
                    <textarea name="contact_message" id="contact_message" rows="5" placeholder="Type Message" required></textarea>
                </div>
                <div class="pb-5">
                <button type="button" onclick="contactFormSubmit()"
                    class="text-white bg-blue-700 hover:bg-blue-800 rounded-lg px-5 py-2.5 text-center contactFormSubmit">Submit</button>
                </div>
            </form>
            {{-- loading indiacator on clcik in submit button --}}
            <div role="status" class="form_loader" style="display: none">
                <svg aria-hidden="true" class="w-8 h-8 mr-2 text-gray-200 animate-spin  fill-blue-600"
                    viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                        fill="currentColor" />
                    <path
                        d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                        fill="currentFill" />
                </svg>
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
    @if ($property->published == 0 || $property->active == 0)
    <div class="fixed-footer">
        <div class="container mx-auto py-1 px-2 flex justify-end">
            <a href="{{ url('/agent/property/publish/' . $property['unique_url']) }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Publish Property
            </a>
        </div>
    </div>
    @endif
    {{-- contact section in footer section code ends --}}

    {{-- property description and details section code ends  --}}
@stop
