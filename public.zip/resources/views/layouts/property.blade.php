@php
    $property = session('property');
@endphp
<!doctype html>
<html lang="en" dir="ltr">

<head>
    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
  
    <!-- TITLE -->
    <title>@yield('title') - Property Shops</title>

    <!-- FAVICON -->
    <link rel="icon" href="{{url('/images/favicon-48x48.ico')}}">
    <!-- Jquery link -->
    <script src="{{ url('js/jquery.min.js') }}"></script>
    <!-- add style for emded youtube video -->
    <x-embed-styles />
    <link rel="stylesheet" href="{{url('css/fontawesome.min.css')}}" />
    <!-- custom css -->
    <link rel="stylesheet" href="{{url('css/custom.css')}}">    
    {{-- image carousal on header links --}}
    <link rel="stylesheet" href="{{url('css/jsdeliver.min.css')}}">    
    {{-- lightbox affect css --}}
    <link rel="stylesheet" href="{{url('css/lc_lightbox.min.css')}}" />
    
    <!-- Custom css and js-->
    <link rel="stylesheet" href="{{url('css/public-custom.css')}}" />
    <?php 
    if($_SERVER["SERVER_NAME"] != "localhost" && strpos($_SERVER["SERVER_NAME"], "192.168") === false && $_SERVER["REMOTE_ADDR"] != "61.247.238.175") {
        ?>
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-9347CDELHT"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());

            gtag('config', 'G-9347CDELHT');
        </script>
    <?php 
    }
    ?>
    <script>
        /* Public URL of the website use in JS - web_url */
        @php echo "web_url = \"" . URL::to('/') . "\";"; @endphp
    </script>
</head>
<body>
    @include('flash-message')
    <div class="container-fluid p-0">

        <!-- Display Content -->
        @yield('content')
         <!-- Fontawesome link -->
    <script src="{{url('js/fontawesome.min.js')}}"></script>
    <!-- tailwind js -->
    <script src="{{ url('js/tailwind.min.js') }}"></script>
    <script src="{{ url('js/jsdeliver.min.js') }}"></script>
    <!-- flowbite js -->
    <script src="{{ url('js/flowbite.min.js') }}"></script>
    <!-- function js -->
    <script src="{{url('js/functions.js')}}?t=123"></script>
    <!-- CUSTOM JS -->
    <script src="{{url('js/custom.js')}}?t=123"></script>
    <script src="{{url('js/public-custom.js')}}?t=123" ></script>
    
    {{-- light box js to add lightbox affect --}}
    <script src="{{url('js/lc_lightbox.lite.min.js')}}"></script>
    

    </div>
</body>

</html>